# Lumi Words iOS（自用）

纯 WKWebView + 原生 AVAudioSession 音频桥的应用外壳，加载 https://zhaozihao2752405105.github.io 。

- 编译：GitHub Actions `macos-14`（`build-unsigned-ipa`），产物是 **unsigned ipa**。
- 安装：Windows 上用 AltStore / SideStore + 免费 Apple ID 签名（7 天有效期，到期重签）。
- 音频：`AVAudioSession(.playAndRecord, .voiceChat, allowBluetooth|defaultToSpeaker|mixWithOthers)`，
  网页侧通过 `window.LumiNative.start()/stop()` 调用，保证静音拨片下仍能听到媒体音频。
