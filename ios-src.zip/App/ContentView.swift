import SwiftUI
import UIKit
import WebKit
import AVFoundation
import Network

// MARK: - 音频会话桥

/// 原生音频会话桥：网页通过 window.webkit.messageHandlers.lumiAudio.postMessage({cmd:...}) 调用。
/// 目的：由 iOS 原生 AVAudioSession(.playAndRecord, .voiceChat) 接管音频路由，
/// 避免耳机/蓝牙切换时听不到声音、麦克风被静音，并在音频中断后恢复。
final class AudioBridge: NSObject, WKScriptMessageHandler {
    static let shared = AudioBridge()
    private var active = false

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let cmd = body["cmd"] as? String else { return }
        switch cmd {
        case "start": startSession()
        case "stop": stopSession()
        case "route": reportRoute()
        default: break
        }
    }

    func startSession() {
        let audio = AVAudioSession.sharedInstance()
        do {
            try audio.setCategory(.playAndRecord,
                                  mode: .voiceChat,
                                  options: [.allowBluetooth, .allowBluetoothA2DP, .defaultToSpeaker, .mixWithOthers])
            try audio.setActive(true, options: [])
            active = true
            reportRoute()
        } catch {
            NSLog("LumiAudio start failed: \(error)")
        }
    }

    func stopSession() {
        guard active else { return }
        active = false
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        } catch {
            NSLog("LumiAudio stop failed: \(error)")
        }
    }

    private func reportRoute() {
        let audio = AVAudioSession.sharedInstance()
        let route = audio.currentRoute.outputs.first?.portType.rawValue ?? "unknown"
        let msg = "window.LumiNative && window.LumiNative.onRoute && window.LumiNative.onRoute(\"\(route)\")"
        DispatchQueue.main.async {
            guard let web = WebHolder.shared.webView else { return }
            web.evaluateJavaScript(msg, completionHandler: nil)
        }
    }
}

final class WebHolder {
    static let shared = WebHolder()
    weak var webView: WKWebView?
}

// MARK: - 外壳状态

final class ShellState: ObservableObject {
    @Published var offline = false
    @Published var message = ""
    @Published var retryToken = 0
}

// MARK: - 代理

final class WebCoordinator: NSObject, WKUIDelegate, WKNavigationDelegate, WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        guard message.name == "lumiMigrate" else { return }
        // 迁移已收敛（成功/超时/失败回退）后，迟到的回调不允许再改迁移标记：
        // 超时后页面可能恢复并回传 ok=true，此时本地界面已经在用，不能再把"待迁移"抹掉。
        guard migrating else {
            NSLog("LumiShell: late migrate callback ignored")
            return
        }
        let body = message.body as? [String: Any] ?? [:]
        let remaining = (body["remaining"] as? NSNumber)?.intValue ?? -1
        let ok = (body["ok"] as? Bool) ?? false
        NSLog("LumiShell: migrate report ok=\(ok) remaining=\(remaining)")
        finishMigration(ok: ok, remaining: remaining)
    }

    static let remoteHome = "https://zhaozihao2752405105.github.io/today.html?native=1"
    /// 过渡迁移页：只在新装/升级后第一次启动时访问旧 Origin，把旧 Origin 里排队的
    /// 待补交记录补交完，再切到本地资源。切换前必须确认服务器已受理。
    static let remoteMigrate = "https://zhaozihao2752405105.github.io/migrate.html?native=1"
    static let migratedKey = "lumi.migrated.local.v1"
    static let pendingMigrateKey = "lumi.migrate.pending.v1"
    let state: ShellState
    private weak var webView: WKWebView?
    private var usingRemoteFallback = false
    private var migrating = false
    var lastRetry = 0

    init(state: ShellState) {
        self.state = state
    }

    func attach(_ web: WKWebView) {
        self.webView = web
    }

    func loadEntry(into web: WKWebView, retry: Bool = false) {
        if retry { usingRemoteFallback = false }
        // 第一次切到本地 Origin 前，先去旧 Origin 把待补交记录交完（失败不阻塞启动）。
        if !retry && !UserDefaults.standard.bool(forKey: WebCoordinator.migratedKey) && !migrating,
           let url = URL(string: WebCoordinator.remoteMigrate) {
            migrating = true
            NSLog("LumiShell: migrate via remote origin")
            web.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12))
            return
        }
        if let base = LocalWebServer.shared.start() {
            let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0"
            let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0"
            var comps = URLComponents(url: base.appendingPathComponent("today.html"), resolvingAgainstBaseURL: false)
            comps?.queryItems = [
                URLQueryItem(name: "native", value: "ios"),
                URLQueryItem(name: "app", value: version),
                URLQueryItem(name: "build", value: build)
            ]
            if let url = comps?.url {
                NSLog("LumiShell: local \(url.absoluteString)")
                web.load(URLRequest(url: url))
                return
            }
        }
        // 本地资源不可用时才回退远程，保证不是白屏。
        usingRemoteFallback = true
        if let url = URL(string: WebCoordinator.remoteHome) {
            NSLog("LumiShell: fallback remote \(url.absoluteString)")
            web.load(URLRequest(url: url))
        }
    }

    func webView(_ webView: WKWebView,
                 requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo,
                 type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        // 只放行麦克风（实时语音）；摄像头没有用途说明，直接拒绝。
        decisionHandler(type == .microphone ? .grant : .deny)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        completionHandler()
    }

    /// 迁移页回报：done=true 且 remaining=0 才记“已迁移”；否则下次启动再试。
    func finishMigration(ok: Bool, remaining: Int) {
        guard migrating else { return }
        migrating = false
        if ok && remaining == 0 {
            UserDefaults.standard.set(true, forKey: WebCoordinator.migratedKey)
            UserDefaults.standard.removeObject(forKey: WebCoordinator.pendingMigrateKey)
        } else {
            // 失败/超时：不清旧 Origin 数据、不写迁移完成标记，把条数留在本地用于提示
            let left = remaining >= 0 ? remaining : 0
            UserDefaults.standard.set(left, forKey: WebCoordinator.pendingMigrateKey)
            state.message = left > 0
                ? "还有 \(left) 条旧记录没补交，联网后会自动重试（旧数据仍在）"
                : "旧记录补交未完成，联网后会自动重试（旧数据仍在）"
            state.offline = true
        }
        if let web = webView { loadEntry(into: web) }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if migrating, webView.url?.absoluteString.contains("migrate.html") == true {
            // 页面自己会调用 lumiMigrate；这里只做超时兜底。
            DispatchQueue.main.asyncAfter(deadline: .now() + 15) { [weak self] in
                guard let self = self, self.migrating else { return }
                NSLog("LumiShell: migrate timeout,继续本地启动")
                self.finishMigration(ok: false, remaining: -1)
            }
        }
        state.offline = false
        state.message = ""
        AudioBridge.shared.reportRouteIfNeeded()
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        handleFailure(error)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        handleFailure(error)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        // 系统回收渲染进程后不能留白，直接重载当前入口。
        if usingRemoteFallback, let url = URL(string: WebCoordinator.remoteHome) {
            webView.load(URLRequest(url: url))
        } else {
            loadEntry(into: webView)
        }
    }

    private func handleFailure(_ error: Error) {
        let ns = error as NSError
        // -999 是主动取消（例如页面切换），不是错误。
        if ns.code == NSURLErrorCancelled { return }
        NSLog("LumiShell: navigation failed \(ns.code) \(ns.localizedDescription)")
        // 迁移页打不开（离线/超时）不能挡住启动：直接进本地资源，标记留到下次再试。
        if migrating {
            NSLog("LumiShell: migrate page unavailable, skip migration")
            finishMigration(ok: false, remaining: -1)
            return
        }
        if !usingRemoteFallback {
            usingRemoteFallback = true
            if let url = URL(string: WebCoordinator.remoteHome) {
                state.offline = false
                state.message = "本地资源加载失败，已切换到在线模式"
                webView?.load(URLRequest(url: url))
                return
            }
        }
        state.offline = true
        state.message = "网络不可用，且本地资源未能加载"
    }
}

extension AudioBridge {
    func reportRouteIfNeeded() {
        reportRoute()
    }
}

// MARK: - SwiftUI 外壳

struct ContentView: View {
    @StateObject private var state = ShellState()

    var body: some View {
        ZStack {
            WebShell(state: state)
                .ignoresSafeArea(.all)
            if state.offline {
                VStack(spacing: 14) {
                    Image(systemName: "wifi.slash")
                        .font(.system(size: 34))
                        .foregroundColor(Color(red: 0.36, green: 0.25, blue: 0.84))
                    Text("当前无法加载学习内容")
                        .font(.system(size: 17, weight: .semibold))
                    Text(state.message)
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                    Button("重试") {
                        state.retryToken += 1
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Color(red: 0.36, green: 0.25, blue: 0.84))
                }
                .padding(24)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .padding(28)
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didEnterBackgroundNotification)) { _ in
            AudioBridge.shared.stopSession()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            if let web = WebHolder.shared.webView {
                web.evaluateJavaScript("window.LumiNative && window.LumiNative.onForeground && window.LumiNative.onForeground()", completionHandler: nil)
            }
        }
    }
}

struct WebShell: UIViewRepresentable {
    let state: ShellState

    func makeCoordinator() -> WebCoordinator {
        WebCoordinator(state: state)
    }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.allowsPictureInPictureMediaPlayback = true
        // 持久化存储：绝不能用 nonPersistent，否则升级或重启会丢登录态与本地学习数据。
        cfg.websiteDataStore = .default()
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        cfg.defaultWebpagePreferences = prefs
        cfg.userContentController.add(AudioBridge.shared, name: "lumiAudio")
        cfg.userContentController.add(context.coordinator, name: "lumiMigrate")

        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0"
        let js = """
        window.LumiNative = window.LumiNative || {
          call: function(body) { try { window.webkit.messageHandlers.lumiAudio.postMessage(body); } catch (e) {} },
          start: function() { this.call({cmd:'start'}); },
          stop: function() { this.call({cmd:'stop'}); },
          onRoute: function(r) { window.LumiAudioRoute = r; },
          appVersion: "\(version)",
          appBuild: "\(build)",
          platform: "ios",
          localAssets: \(LocalWebServer.shared.isAvailable)
        };
        """
        cfg.userContentController.addUserScript(WKUserScript(source: js, injectionTime: .atDocumentStart, forMainFrameOnly: false))

        let web = WKWebView(frame: .zero, configuration: cfg)
        web.uiDelegate = context.coordinator
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .clear
        // 安全区域由网页 CSS 统一负责（viewport-fit=cover + env(safe-area-inset-*)），
        // 原生层不再叠加，避免双重内边距。
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = true
        WebHolder.shared.webView = web
        context.coordinator.attach(web)
        context.coordinator.loadEntry(into: web)
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        if context.coordinator.lastRetry != state.retryToken {
            context.coordinator.lastRetry = state.retryToken
            context.coordinator.loadEntry(into: uiView, retry: true)
        }
    }
}
