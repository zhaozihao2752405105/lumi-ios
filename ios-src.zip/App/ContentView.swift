import SwiftUI
import UIKit
import WebKit
import AVFoundation

/// 原生音频会话桥：网页通过 window.webkit.messageHandlers.lumiAudio.postMessage({cmd:...}) 调用。
/// 目的：在 iOS 上用 AVAudioSession(.playAndRecord, .voiceChat) 接管音频路由，
/// 让「静音拨片打开时也能听到声音」「蓝牙/听筒切换」「音频中断恢复」由原生负责，
/// 而不是只依赖 WKWebView 的默认行为。
final class AudioBridge: NSObject, WKScriptMessageHandler {
    static let shared = AudioBridge()

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let cmd = body["cmd"] as? String else { return }
        switch cmd {
        case "start": startSession()
        case "stop": stopSession()
        case "route": reportRoute()
        default: break
        }
    }

    private func startSession() {
        let audio = AVAudioSession.sharedInstance()
        do {
            try audio.setCategory(.playAndRecord,
                                  mode: .voiceChat,
                                  options: [.allowBluetooth, .allowBluetoothA2DP, .defaultToSpeaker, .mixWithOthers])
            try audio.setActive(true, options: [])
            reportRoute()
        } catch {
            NSLog("LumiAudio start failed: \(error)")
        }
    }

    private func stopSession() {
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        } catch {
            NSLog("LumiAudio stop failed: \(error)")
        }
    }

    private func reportRoute() {
        let audio = AVAudioSession.sharedInstance()
        let route = audio.currentRoute.outputs.first?.portType.rawValue ?? "unknown"
        let msg = "window.LumiNative && window.LumiNative.onRoute && window.LumiNative.onRoute(\"\(route)\")"
        DispatchQueue.main.async {
            guard let web = WebHolder.shared.webView else { return }
            web.evaluateJavaScript(msg, completionHandler: nil)
        }
    }
}

final class WebHolder {
    static let shared = WebHolder()
    weak var webView: WKWebView?
}

/// 关键：WKWebView 默认拒绝网页的麦克风/摄像头请求，
/// 必须实现 WKUIDelegate 的这个方法并 grant，否则 a4-voice 页的 getUserMedia 会直接失败。
final class WebCoordinator: NSObject, WKUIDelegate {
    func webView(_ webView: WKWebView,
                 requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo,
                 type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.grant)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        completionHandler()
    }

    /// 站内继续用内嵌浏览器；外部链接（GitHub、邮箱等）交给系统 Safari，避免 App 里出不来。
    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { return decisionHandler(.allow) }
        let internalHosts = ["zhaozihao2752405105.github.io", "ajyvmcqrttcalhliagnr.supabase.co"]
        if navigationAction.navigationType == .linkActivated,
           !internalHosts.contains(url.host ?? "") {
            UIApplication.shared.open(url)
            return decisionHandler(.cancel)
        }
        decisionHandler(.allow)
    }

    /// WebKit 内容进程被系统回收时（内存吃紧/长时间后台），自动把页面要回来，避免白屏。
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }
}

struct ContentView: UIViewRepresentable {
    func makeCoordinator() -> WebCoordinator { WebCoordinator() }
    static let home = "https://zhaozihao2752405105.github.io/chat.html?native=1"

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.allowsPictureInPictureMediaPlayback = true
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        cfg.defaultWebpagePreferences = prefs
        cfg.userContentController.add(AudioBridge.shared, name: "lumiAudio")

        // 页面加载前注入：把 LumiNative 暴露给网页，语音页会先调 start() 再建 WebRTC。
        let js = """
        window.LumiNative = window.LumiNative || {
          call: function(body) { try { window.webkit.messageHandlers.lumiAudio.postMessage(body); } catch (e) {} },
          start: function() { this.call({cmd:'start'}); },
          stop: function() { this.call({cmd:'stop'}); },
          onRoute: function(r) { window.LumiAudioRoute = r; }
        };
        """
        cfg.userContentController.addUserScript(WKUserScript(source: js, injectionTime: .atDocumentStart, forMainFrameOnly: false))

        let web = WKWebView(frame: .zero, configuration: cfg)
        web.uiDelegate = context.coordinator
        web.isOpaque = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = true
        web.scrollView.keyboardDismissMode = .interactive
        web.allowsLinkPreview = false
        web.scrollView.showsVerticalScrollIndicator = false
        web.backgroundColor = UIColor(red: 0.953, green: 0.945, blue: 0.969, alpha: 1)
        WebHolder.shared.webView = web
        if let url = URL(string: ContentView.home) {
            web.load(URLRequest(url: url))
        }
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
