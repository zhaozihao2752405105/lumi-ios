import Foundation
import Network

/// 本地资源服务器：把 App 内置的 web/ 目录通过 127.0.0.1 回环 HTTP 提供给 WKWebView。
///
/// 为什么不用 loadFileURL / 自定义 scheme：
/// - file:// 与自定义 scheme 都不是 Secure Context，getUserMedia / RTCPeerConnection 会被拒绝，
///   直接破坏已完成的 Lumi 实时语音。
/// - http://127.0.0.1 被浏览器视为潜在可信来源（Potentially Trustworthy），
///   既能拿到 Secure Context，又能保留 IndexedDB / localStorage / fetch / Service Worker 语义。
///
/// 只监听回环地址，不对外网暴露；只读，不允许目录穿越。
final class LocalWebServer {
    static let shared = LocalWebServer()

    private(set) var port: UInt16 = 0
    private var listener: NWListener?
    private let rootDirectory: URL
    private let queue = DispatchQueue(label: "com.lumiwords.localweb")

    private init() {
        if let res = Bundle.main.resourceURL {
            rootDirectory = res.appendingPathComponent("web", isDirectory: true)
        } else {
            rootDirectory = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("web", isDirectory: true)
        }
    }

    var isAvailable: Bool {
        FileManager.default.fileExists(atPath: rootDirectory.appendingPathComponent("today.html").path)
    }

    var baseURL: URL? {
        guard port > 0 else { return nil }
        return URL(string: "http://127.0.0.1:\(port)/")
    }

    /// WebKit 的 localStorage/IndexedDB 按 origin（scheme+host+port）隔离。
    /// 端口每次随机会让用户"看起来丢失"本地缓存与登录态，因此优先使用固定端口，
    /// 只有在固定端口都被占用时才回退到系统分配端口。
    static let preferredPorts: [UInt16] = [51820, 51821]

    /// 同步等待启动结果，最多约 3 秒；失败返回 nil，调用方回退远程入口。
    @discardableResult
    func start(timeout: TimeInterval = 3.0) -> URL? {
        if port > 0, let url = baseURL { return url }
        guard isAvailable else {
            NSLog("LumiWeb: bundled web/ missing at \(rootDirectory.path)")
            return nil
        }

        for candidate in Self.preferredPorts where attemptStart(port: candidate, timeout: timeout / 2) {
            return baseURL
        }
        if attemptStart(port: 0, timeout: timeout / 2) {
            NSLog("LumiWeb: fell back to an ephemeral port \(port); local storage origin changed")
        }
        return baseURL
    }

    /// port 传 0 表示由系统分配。
    private func attemptStart(port candidate: UInt16, timeout: TimeInterval) -> Bool {
        let params = NWParameters.tcp
        let endpointPort: NWEndpoint.Port = candidate == 0 ? .any : (NWEndpoint.Port(rawValue: candidate) ?? .any)
        params.requiredLocalEndpoint = .hostPort(host: .ipv4(.loopback), port: endpointPort)
        params.allowLocalEndpointReuse = true

        do {
            let listener = try NWListener(using: params)
            self.listener?.cancel()
            self.listener = listener
            self.port = 0
            let deadline = Date().addingTimeInterval(timeout)

            listener.stateUpdateHandler = { [weak self, weak listener] state in
                guard let self = self, let listener = listener else { return }
                switch state {
                case .ready:
                    if let p = listener.port { self.port = p.rawValue }
                case .failed(let error):
                    NSLog("LumiWeb: listener failed on \(candidate): \(error)")
                    self.port = 0
                default:
                    break
                }
            }
            listener.newConnectionHandler = { [weak self] connection in
                self?.handle(connection)
            }
            listener.start(queue: queue)

            while port == 0 && Date() < deadline {
                RunLoop.current.run(until: Date().addingTimeInterval(0.05))
            }
            if port > 0 { return true }
            listener.cancel()
            return false
        } catch {
            NSLog("LumiWeb: cannot start on \(candidate): \(error)")
            return false
        }
    }

    // MARK: - Connection handling

    private func handle(_ connection: NWConnection) {
        connection.start(queue: queue)
        receiveHeader(connection, buffer: Data())
    }

    private func receiveHeader(_ connection: NWConnection, buffer: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 16 * 1024) { [weak self] data, _, isComplete, error in
            guard let self = self else { return }
            if let error = error {
                NSLog("LumiWeb: recv error \(error)")
                connection.cancel()
                return
            }
            var acc = buffer
            if let data = data { acc.append(data) }
            if let range = acc.range(of: Data("\r\n\r\n".utf8)) {
                let head = acc.subdata(in: 0..<range.lowerBound)
                if let text = String(data: head, encoding: .utf8) {
                    self.respond(connection, requestHeader: text)
                } else {
                    self.sendStatus(connection, code: 400, reason: "Bad Request")
                }
                return
            }
            if acc.count > 64 * 1024 || isComplete {
                self.sendStatus(connection, code: 431, reason: "Request Header Fields Too Large")
                return
            }
            self.receiveHeader(connection, buffer: acc)
        }
    }

    private func respond(_ connection: NWConnection, requestHeader: String) {
        let lines = requestHeader.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else {
            sendStatus(connection, code: 400, reason: "Bad Request")
            return
        }
        let parts = requestLine.split(separator: " ")
        guard parts.count >= 2 else {
            sendStatus(connection, code: 400, reason: "Bad Request")
            return
        }
        let method = String(parts[0])
        var target = String(parts[1])
        if method != "GET" && method != "HEAD" {
            sendStatus(connection, code: 405, reason: "Method Not Allowed")
            return
        }
        if let q = target.firstIndex(of: "?") { target = String(target[..<q]) }
        if let h = target.firstIndex(of: "#") { target = String(target[..<h]) }
        var rel = target
        while rel.hasPrefix("/") { rel.removeFirst() }
        if rel.isEmpty { rel = "today.html" }
        let decoded = rel.removingPercentEncoding ?? rel
        if decoded.contains("..") {
            sendStatus(connection, code: 403, reason: "Forbidden")
            return
        }

        let fileURL = rootDirectory.appendingPathComponent(decoded)
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: fileURL.path, isDirectory: &isDir), !isDir.boolValue else {
            sendStatus(connection, code: 404, reason: "Not Found")
            return
        }

        let attrs = (try? FileManager.default.attributesOfItem(atPath: fileURL.path)) ?? [:]
        let fileSize = (attrs[.size] as? NSNumber)?.int64Value ?? 0
        let contentType = LocalWebServer.mimeType(for: fileURL.pathExtension)

        // Range 支持：音视频拖动与 WKWebView 媒体加载都依赖 206。
        var start: Int64 = 0
        var end: Int64 = fileSize - 1
        var isPartial = false
        for line in lines.dropFirst() {
            let lower = line.lowercased()
            if lower.hasPrefix("range:") {
                let spec = line.dropFirst("range:".count).trimmingCharacters(in: .whitespaces)
                if spec.hasPrefix("bytes=") {
                    let body = spec.dropFirst("bytes=".count)
                    let comps = body.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false)
                    if comps.count == 2 {
                        let a = Int64(comps[0].trimmingCharacters(in: .whitespaces)) ?? 0
                        if comps[1].isEmpty {
                            start = a
                        } else if let b = Int64(comps[1].trimmingCharacters(in: .whitespaces)) {
                            start = a
                            end = min(b, fileSize - 1)
                        }
                        if start < 0 { start = 0 }
                        if start > end { start = end }
                        isPartial = true
                    }
                }
                break
            }
        }

        let length = max(0, end - start + 1)
        var head = "HTTP/1.1 \(isPartial ? "206 Partial Content" : "200 OK")\r\n"
        head += "Content-Type: \(contentType)\r\n"
        head += "Content-Length: \(length)\r\n"
        head += "Accept-Ranges: bytes\r\n"
        if isPartial {
            head += "Content-Range: bytes \(start)-\(end)/\(fileSize)\r\n"
        }
        head += "Cache-Control: no-cache\r\n"
        head += "Connection: close\r\n\r\n"

        guard method != "HEAD" else {
            connection.send(content: Data(head.utf8), completion: .contentProcessed { _ in connection.cancel() })
            return
        }

        guard let handle = try? FileHandle(forReadingFrom: fileURL) else {
            sendStatus(connection, code: 500, reason: "Internal Server Error")
            return
        }
        connection.send(content: Data(head.utf8), completion: .contentProcessed { error in
            if error != nil {
                try? handle.close()
                connection.cancel()
                return
            }
            do {
                try handle.seek(toOffset: UInt64(start))
            } catch {
                try? handle.close()
                connection.cancel()
                return
            }
            self.stream(handle: handle, remaining: length, connection: connection)
        })
    }

    private func stream(handle: FileHandle, remaining: Int64, connection: NWConnection) {
        if remaining <= 0 {
            try? handle.close()
            connection.send(content: nil, contentContext: .defaultMessage, isComplete: true,
                            completion: .contentProcessed { _ in connection.cancel() })
            return
        }
        let chunkSize = Int(min(64 * 1024, remaining))
        let data = handle.readData(ofLength: chunkSize)
        if data.isEmpty {
            try? handle.close()
            connection.send(content: nil, contentContext: .defaultMessage, isComplete: true,
                            completion: .contentProcessed { _ in connection.cancel() })
            return
        }
        connection.send(content: data, completion: .contentProcessed { [weak self] error in
            if error != nil {
                try? handle.close()
                connection.cancel()
                return
            }
            self?.stream(handle: handle, remaining: remaining - Int64(data.count), connection: connection)
        })
    }

    private func sendStatus(_ connection: NWConnection, code: Int, reason: String) {
        let body = "\(code) \(reason)"
        let head = "HTTP/1.1 \(code) \(reason)\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: \(body.utf8.count)\r\nConnection: close\r\n\r\n"
        var payload = Data(head.utf8)
        payload.append(Data(body.utf8))
        connection.send(content: payload, completion: .contentProcessed { _ in connection.cancel() })
    }

    private static func mimeType(for ext: String) -> String {
        switch ext.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json", "webmanifest": return "application/json; charset=utf-8"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "webp": return "image/webp"
        case "svg": return "image/svg+xml"
        case "ico": return "image/x-icon"
        case "mp3": return "audio/mpeg"
        case "m4a": return "audio/mp4"
        case "wav": return "audio/wav"
        case "mp4", "m4v": return "video/mp4"
        case "webm": return "video/webm"
        case "woff2": return "font/woff2"
        case "ttf": return "font/ttf"
        case "txt": return "text/plain; charset=utf-8"
        default: return "application/octet-stream"
        }
    }
}