/* ============================================================
 * assets/test.js —— 每周测试：从「学过的词」里抽 10 个做四选一
 * 成绩写 weekly_tests（unique(user_id, week_start)，先查后改/插）
 * 答错的词写 mistakes(kind='word')，同一题当天只记一次
 * ============================================================ */
(function () {
  'use strict';

  // 「对象不存在」专用判定：只有 PostgREST 明确说表/列不存在时才回退旧结构，
  // 权限、网络、JWT 等异常必须原样抛出（不能伪装成兼容性问题）。
  function schemaObjectMissing(e) {
    var m = String((e && (e.message || e.error_description || e.hint)) || e || '');
    return /PGRST205|42703|Could not find the table|schema cache|column .* does not exist|relation .* does not exist/i.test(m);
  }
  var S = { phase: 'home', user: null, items: [], idx: 0, correct: 0, wrong: [], weekStart: '', existing: null, err: null, aiMode: false };
  var TOTAL = 10;
  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function ymd(d) { return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
  function mondayOf(d) {
    var x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    var w = x.getDay(); var off = (w === 0 ? 6 : w - 1);
    return ymd(new Date(x.getTime() - off * 86400000));
  }
  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function toast(msg) {
    var t = el('toast'); if (!t) return alert(msg);
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  function renderHome() {
    var h = [];
    h.push('<div class="v2-pagehead"><p class="v2-eyebrow">Weekly check</p><h1 class="v2-h1">每周测试</h1><p>用最近学过的词做一次小测，看看这一周真正记住了多少。答错自动进错题本。</p></div>');
    h.push('<div class="card"><div class="rowline"><h2 style="margin:0">本周安排</h2><span class="muted small">' + esc(S.weekStart) + ' 这周</span></div>');
    if (S.existing) {
      h.push('<p class="mt8">本周已经测过：<b>' + S.existing.score + ' 分</b>' + (S.existing.detail && S.existing.detail.total ? '（' + S.existing.detail.total + ' 题）' : '') + '。再测一次会覆盖本周成绩。</p>');
    } else {
      h.push('<p class="mt8 muted">按你最近学的词出 ' + TOTAL + ' 道题，四选一（AI 出题；AI 不可用时自动从学过的单词里抽）。答错的题会自动进错题本。每周测一次，周日复盘用。</p>');
    }
    h.push('<div class="row mt16"><button class="btn block" data-act="start">' + (S.existing ? '再测一次' : '开始本周测试') + '</button></div>');
    h.push('<div class="row mt8"><a class="btn ghost block" href="today.html">先去学几个词</a></div>');
    h.push('</div>');
    h.push('<div class="note mt12">测试范围：你已有学习记录的单词（word_progress）。如果提示词不够，先回「今日」学一组。</div>');
    el('view').innerHTML = h.join('');
  }

  function catLabel(c) {
    if (c === 'grammar') return '语法';
    if (c === 'vocab') return '词汇';
    if (c === 'reading') return '阅读';
    return '综合';
  }
  function questionText(it) { return it.kind === 'ai' ? it.question : it.word; }
  function correctText(it) { return it.kind === 'ai' ? (it.options[it.answerIndex] || '') : it.correct; }

  function renderQuiz() {
    var it = S.items[S.idx];
    var h = [];
    h.push('<div class="study-head"><div class="rowline"><span class="muted small">第 ' + (S.idx + 1) + ' / ' + S.items.length + ' 题</span><span class="muted small">答对 ' + S.correct + '</span></div>');
    h.push('<div class="bar"><span style="width:' + Math.round(S.idx * 100 / S.items.length) + '%"></span></div></div>');
    if (it.kind === 'ai') {
      h.push('<div class="card"><div class="rowline"><span class="pill">AI 出题</span><span class="muted small">' + esc(catLabel(it.category)) + '</span></div>');
      h.push('<div class="qtext">' + esc(it.question) + '</div>');
      h.push('<p class="muted small mt8">选出正确答案</p></div>');
    } else {
      h.push('<div class="card center"><div class="big">' + esc(it.word) + '</div>');
      if (it.ipa) h.push('<div class="muted">' + esc(it.ipa) + '</div>');
      h.push('<p class="muted small mt8">选出正确的中文意思</p></div>');
    }
    h.push('<div class="card">');
    it.options.forEach(function (o, i) {
      h.push('<button class="opt block mt8" data-act="pick:' + i + '"><span class="k">' + 'ABCD'.charAt(i) + '</span><span>' + esc(o) + '</span></button>');
    });
    h.push('</div>');
    el('view').innerHTML = h.join('');
    // 「问问 AI」只在作答之后出现，避免还没答题就能看答案。
  }

  // 周测题目上下文：只传题干/选项/正确答案/解析（白名单），不传词表与其它数据。
  // 题目下方「问问 AI」和写进错题本的快照共用这一段，保证两处看到的是同一份内容。
  function askText(it, answered) {
    var parts = ['模块: 周测(' + catLabel(it.category) + ')', '题干: ' + String(it.question || '')];
    (it.options || []).forEach(function (o, i) { parts.push('ABCD'.charAt(i) + '. ' + String(o)); });
    parts.push('正确答案: ' + String((it.options || [])[it.answerIndex] || ''));
    if (answered && it.explain) parts.push('解答: ' + String(it.explain).slice(0, 220));
    return parts.join('\n').slice(0, 1500);
  }

  // 阶段 1：周测题目下方「问问 AI」。
  function mountAsk(answered) {
    if (!window.AskUI || !window.AskUI.mount) return;
    var it = S.items[S.idx];
    if (!it || it.kind !== 'ai') return;
    try {
      window.AskUI.mount(el('view'), {
        kind: 'test',
        ref: String(S.weekStart || '') + ':test:' + (S.idx + 1),
        title: '周测第 ' + (S.idx + 1) + ' 题',
        context: askText(it, answered)
      });
    } catch (e) {}
  }

  function renderFeedback(picked) {
    var it = S.items[S.idx];
    var ok = picked === it.answerIndex;
    var h = [];
    if (it.kind === 'ai') {
      h.push('<div class="card"><div class="muted small">' + esc(catLabel(it.category)) + '</div><div class="qtext">' + esc(it.question) + '</div></div>');
    } else {
      h.push('<div class="card center"><div class="big">' + esc(it.word) + '</div><div class="muted">' + esc(it.ipa || '') + '</div></div>');
    }
    h.push('<div class="fb ' + (ok ? 'ok' : 'bad') + '">');
    h.push('<div><b>' + (ok ? '答对了' : '答错了') + '</b></div>');
    h.push('<div class="mt8">正确答案：' + esc(correctText(it)) + '</div>');
    if (it.kind === 'ai' && it.explain) h.push('<div class="muted small mt8">' + esc(it.explain) + '</div>');
    if (!ok && it.exampleEn) h.push('<div class="muted small mt8">' + esc(it.exampleEn) + (it.exampleZh ? '　' + esc(it.exampleZh) : '') + '</div>');
    h.push('</div>');
    h.push('<div class="row mt12"><button class="btn block" data-act="next">' + (S.idx + 1 < S.items.length ? '下一题' : '看结果') + '</button></div>');
    el('view').innerHTML = h.join('');
    mountAsk(true);
  }

  function renderDone() {
    var score = Math.round(S.correct * 100 / S.items.length);
    var h = [];
    h.push('<div class="card center"><h2>本周测试完成</h2>');
    h.push('<div class="clock">' + score + ' 分</div>');
    h.push('<p class="muted">答对 ' + S.correct + ' / ' + S.items.length + ' 题</p></div>');
    if (S.wrong.length) {
      h.push('<div class="card"><h3 style="margin:0 0 8px">这次错的 ' + S.wrong.length + (S.aiMode ? ' 道题' : ' 个词') + '</h3><div class="plainlist">');
      S.wrong.forEach(function (w) {
        h.push('<div class="kwrow"><div><b>' + esc(questionText(w)) + '</b> ' + esc(w.ipa || '') + '<div class="muted small">' + esc(correctText(w)) + '</div></div></div>');
      });
      h.push('</div><p class="muted small mt8">已记入错题本，去「统计」页可以看到。</p></div>');
    } else {
      h.push('<div class="card center"><p>全对，厉害。</p></div>');
    }
    h.push('<div class="row mt12"><button class="btn block" data-act="again">再测一次</button></div>');
    h.push('<div class="row mt8"><a class="btn ghost block" href="stats.html">看统计</a></div>');
    el('view').innerHTML = h.join('');
  }

  function render() {
    if (S.phase === 'home') return renderHome();
    if (S.phase === 'quiz') return renderQuiz();
    if (S.phase === 'done') return renderDone();
    if (S.phase === 'loading') {
      el('view').innerHTML = '<div class="card"><p class="muted">正在准备题目…</p><p class="muted small mt8">会先让 AI 按你最近学过的词出题；如果 AI 生成失败，会自动改用本机从学过的单词里抽题，不影响继续测试。</p></div>';
      return;
    }
    if (S.phase === 'empty') {
      el('view').innerHTML = '<div class="card"><h2 style="margin-top:0">还没有可以测试的单词</h2><p class="muted">测试范围是你已经学过的词。先去「今日」学一组单词，再回来。</p><div class="row mt12"><a class="btn block" href="today.html">去今日学习</a></div></div>';
      return;
    }
    if (S.phase === 'error') {
      el('view').innerHTML = '<div class="card"><p class="warn-text">出题失败：' + esc(S.err || '未知错误') + '</p><div class="row mt8"><button class="btn ghost block" data-act="start">重试</button></div></div>';
      return;
    }
  }

  async function loadHome() {
    try {
      S.user = await window.AppAuth.requireLogin();
      if (!S.user) return;
      el('userName').textContent = (window.AppAuth.displayName(S.user) || '') + ' · 已登录';
      S.weekStart = mondayOf(new Date());
      var rows = await window.DB.select('weekly_tests', { user_id: S.user.id, week_start: S.weekStart, limit: 1 });
      S.existing = (rows && rows[0]) || null;
      S.phase = 'home';
      render();
    } catch (err) {
      S.phase = 'error'; S.err = (err && err.message) || String(err); render();
    }
  }

  // AI 优先：让 AI 按最近学的词出一套题（混合词汇与语法）。
  // 任何一步不满足就返回 null，走原来的「学过的词抽 10 个」本地出题，不影响测试。
  function aiDbg(s) { try { localStorage.setItem('eng45.ai_test_dbg', String(s)); } catch (e) {} }

  async function aiTest(wp) {
    try {
      var on = window.APP_CONFIG && APP_CONFIG.FEATURES && APP_CONFIG.FEATURES.AI_GENERATE === true;
      if (!on) { aiDbg('flag_off'); return null; }
      if (!window.AI || !window.DB || typeof window.AI.invoke !== 'function') { aiDbg('ai_or_db_missing'); return null; }
      if (typeof navigator !== 'undefined' && navigator.onLine === false) { aiDbg('offline'); return null; }
      var scope = [];
      var ids = (wp || []).slice(0, 6).map(function (r) { return r.word_id; }).filter(Boolean);
      for (var i = 0; i < ids.length && scope.length < 6; i++) {
        try {
          var ws = await window.DB.select('words', { id: ids[i], limit: 1 });
          if (ws && ws[0] && ws[0].word) scope.push(ws[0].word);
        } catch (e) {}
      }
      var r = await window.AI.invoke('test', {
        level: 1, count: TOTAL, scope: scope
      }, { requestId: window.AI.newRequestId() });
      if (!r || !r.ok || !r.data || !Array.isArray(r.data.items)) { aiDbg('invoke_fail status=' + (r && r.status) + ' code=' + (r && r.code) + ' msg=' + (r && r.message)); return null; }
      var items = [];
      (r.data.items || []).forEach(function (it) {
        if (items.length >= TOTAL) return;
        if (!it || !it.question || !Array.isArray(it.options) || it.options.length < 2) return;
        var ai = parseInt(it.answer_index, 10);
        if (!isFinite(ai) || ai < 0 || ai >= it.options.length) ai = 0;
        items.push({
          kind: 'ai',
          question: String(it.question).slice(0, 300),
          options: it.options.slice(0, 4).map(function (o) { return String(o == null ? '' : o).slice(0, 200); }),
          answerIndex: ai,
          explain: it.explain_zh ? String(it.explain_zh).slice(0, 300) : '',
          category: it.category ? String(it.category).slice(0, 20) : ''
        });
      });
      if (items.length < 3) { aiDbg('too_few items=' + items.length); return null; }
      aiDbg('ok items=' + items.length);
      return items;
    } catch (e) { aiDbg('exception ' + ((e && e.message) || e)); return null; }
  }

  async function start() {
    S.phase = 'loading'; render();
    try {
      // v52 compat: the 027 view may not exist yet; fall back ONLY when the schema
      // object is provably absent. Permission / network / JWT errors must surface.
      var wp;
      try { wp = await window.DB.select('active_word_progress', { user_id: S.user.id, order: 'last_reviewed_at.desc', limit: 600 }); }
      catch (e) {
        if (!schemaObjectMissing(e)) throw e;
        wp = await window.DB.select('word_progress', { user_id: S.user.id, order: 'last_reviewed_at.desc', limit: 600 });
      }
      wp = (wp || []).filter(function (r) { return r.word_id; });
      if (!wp.length) { S.phase = 'empty'; render(); return; }

      // 先试 AI 出题（要花极少的钱，失败就退回本地出题）
      var aiItems = await aiTest(wp);
      if (aiItems) {
        S.aiMode = true;
        S.items = aiItems; S.idx = 0; S.correct = 0; S.wrong = [];
        S.phase = 'quiz'; render();
        return;
      }
      S.aiMode = false;

      var picked = shuffle(wp.slice()).slice(0, Math.min(TOTAL, wp.length));
      // v52 compat: words.is_retired arrives with 027;只有确认列不存在时才退到全量查询。
      var pool;
      try { pool = await window.DB.select('words', { is_retired: false, limit: 80 }); }
      catch (e) {
        if (!schemaObjectMissing(e)) throw e;
        pool = await window.DB.select('words', { limit: 80 });
      }
      pool = pool || [];
      var items = [];
      for (var i = 0; i < picked.length; i++) {
        var wid = picked[i].word_id;
        var ws = await window.DB.select('words', { id: wid, limit: 1 });
        var w = ws && ws[0];
        if (!w) continue;
        var wrongs = [];
        for (var j = 0; j < pool.length && wrongs.length < 3; j++) {
          if (pool[j].id === w.id) continue;
          if (!pool[j].meaning || pool[j].meaning === w.meaning) continue;
          if (wrongs.indexOf(pool[j].meaning) >= 0) continue;
          wrongs.push(pool[j].meaning);
        }
        var opts = shuffle(wrongs.concat([w.meaning]));
        items.push({
          word: w.word, ipa: w.ipa || '', correct: w.meaning,
          exampleEn: w.example_en || '', exampleZh: w.example_zh || '',
          options: opts, answerIndex: opts.indexOf(w.meaning)
        });
      }
      if (!items.length) { S.phase = 'empty'; render(); return; }
      S.items = items; S.idx = 0; S.correct = 0; S.wrong = [];
      S.phase = 'quiz'; render();
    } catch (err) {
      S.phase = 'error'; S.err = (err && err.message) || String(err); render();
    }
  }

  function mistakeKind(it) {
    if (it.kind !== 'ai') return 'word';
    if (it.category === 'grammar') return 'grammar';
    if (it.category === 'reading') return 'reading';
    return 'word';
  }

  async function saveMistake(it, chosen) {
    try {
      var q = (it.kind === 'ai' ? it.question : (it.word + ' ' + (it.ipa || ''))).trim();
      // 确定性 id = 同一题只留一行；离线时入队，联网后自动补交
      // 阶段 2：AI 题同时存原题快照（周测题刷新后会重新生成，不存快照错题本里就无法追问）
      var mctx = it.kind === 'ai' ? {
        text: askText(it, true),
        title: '周测第 ' + (S.idx + 1) + ' 题',
        kind: 'test',
        ref: String(S.weekStart || '') + ':test:' + (S.idx + 1)
      } : null;
      await window.Learn.saveMistakeRow({
        id: window.Learn.mistakeId(S.user.id, mistakeKind(it), null, q),
        user_id: S.user.id, kind: mistakeKind(it), question: q,
        user_answer: chosen, correct_answer: correctText(it), explain_zh: it.explain || '',
        context: mctx
      });
    } catch (e) { /* 错题记录失败不影响测试成绩 */ }
  }

  async function finish() {
    var score = Math.round(S.correct * 100 / S.items.length);
    try {
      // 错题摘要：单词题记单词，AI 题记题干（截短），保证统计页能看懂
      var detail = { total: S.items.length, correct: S.correct, wrong: S.wrong.map(function (w) {
        return w.kind === 'ai' ? String(w.question || '').slice(0, 80) : (w.word || '');
      }) };
      var out = await window.Learn.saveWeeklyTest({ week_start: S.weekStart, score: score, detail: detail });
      if (out.status === 'queued') toast('成绩先存在本机，联网后自动补交');
      if (out.status === 'failed' || out.status === 'dead') toast('成绩保存失败，但本次结果仍可查看');
    } catch (e) { toast('成绩保存失败，但本次结果仍可查看'); }
    S.phase = 'done'; render();
  }

  function pick(i) {
    var it = S.items[S.idx];
    if (it._answered) return;
    it._answered = true;
    var chosen = it.options[i];
    if (i === it.answerIndex) { S.correct += 1; }
    else { S.wrong.push(it); saveMistake(it, chosen); }
    renderFeedback(i);
  }

  function next() {
    if (S.idx + 1 < S.items.length) { S.idx += 1; renderQuiz(); }
    else { finish(); }
  }

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'start') return start();
    if (act === 'next') return next();
    if (act === 'again') { S.weekStart = mondayOf(new Date()); return start(); }
    if (act.indexOf('pick:') === 0) return pick(Number(act.slice(5)));
  });
  var btnLogout = document.getElementById('btnLogout');
  if (btnLogout) btnLogout.addEventListener('click', function () { window.AppAuth.logout(); });
  window.addEventListener('error', function (e) { toast('页面脚本错误：' + (e && e.message ? e.message : '未知')); });

  function boot() { loadHome(); }
  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();
})();