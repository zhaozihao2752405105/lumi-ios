/* ============================================================
 * assets/study.js —— 今日学习 / 到期复习 共享控制器
 * 依赖：app.css、config.js、supabase CDN、db.js、auth.js、queue.js、learning.js
 * 页面用法：<body data-mode="today"> ... StudyUI.boot()
 * 本阶段零 AI 调用：内容全部来自 get_or_create_daily_task 返回的任务条目。
 * 记录三态：提交成功后显示 sent/dead，离线排队显示 queued（不得显示成已保存）。
 * ============================================================ */
window.StudyUI = (function () {
  'use strict';

  var MODE = 'today';           // 'today' | 'review'
  var S = {
    user: null,
    sessionId: 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    status: 'loading',          // loading|error|home|study|done
    error: '',
    task: null,
    allItems: [],               // 当前模块（new/review）的全部条目
    queue: [],                  // 待学习条目
    doneInitial: 0,           // 加载时已完成
    skippedInit: 0,           // 加载时已跳过
    idx: 0,
    done: 0,
    skipped: 0,
    phase: 'card',              // card|quiz|quiz_fb|spell|spell_fb|retry|retry_fb|saving|item_done
    firstResult: null,          // 'correct'|'incorrect' 首次作答（决定 SM-2 调度）
    zUnit: '',                  // 本会话难度反馈的 unit_key
    zStats: { independent: 0, correct: 0, hints: 0, repeated: 0 }, // 本会话作答统计（只给难度反馈用）
    attemptNo: 0,
    itemStart: 0,
    retry: [],                  // 07-H 错词延迟重测队列：{item, due, tries}
    retestItem: null,           // 当前正在延迟重测的词
    retestOk: null,
    retestTyped: '',
    retestTries: 0,
    groupStart: 0,              // 07-C 当前组在 queue 中的起点
    groupSpell: null,           // 07-F 集中默写状态 {order,pos,typed,ok,right,wrong}
    options: [],
    picked: null,
    lastSave: null,             // {status,message}
    busy: false,
    elapsed: 0,
    lastTickSec: 0,
    lastState: '',
    starting: false,
    pending: 0,
    levels: { adaptive: 1, listening: 1, reading: 1 },
    mode: 'read',               // read 认知 | follow 跟写 | dictate 听写 | recall 默写
    hintUsed: false,            // 默写/听写里是否用过提示（影响调度计分）
    typed: '',                  // 当前输入（跟写实时比对用）
    offlineView: false,      // 当前显示的是本机缓存快照（断网）
    cacheDate: '',           // 快照对应的日期
    cachePreview: false,     // 联网时先显示同日本地快照，等待后台水合
    syncError: false,        // 预览期间后台同步失败（保留可学内容，不白屏）
    offlineStudy: false,     // 无网络时继续学：记录先存本机，联网后补交
    combo: 0,               // 连续答对（只用于反馈，不参与调度/掌握）
    soundKey: '',           // 同一反馈只播一次
    rememberOnce: false,    // 本次自评“认识”用 remember 音替代答对音
    localTimer: null
  };

  var view = null;
  var toastTimer = null;

  // ---------- 小工具 ----------
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function $(id) { return document.getElementById(id); }
  // 真实学习状态开关：只有进入学习页且会话确实要用时才允许「回前台自动建会话」
  function setAuto(on) {
    try { if (window.Learn && window.Learn.Session) window.Learn.Session.autoStart = !!on; } catch (e) { }
  }
  function toast(msg, ms) {
    var el = $('toast');
    if (!el) return;
    el.textContent = msg;
    el.className = 'toast on';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.className = 'toast'; }, ms || 2400);
  }
  function fmt(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var m = Math.floor(sec / 60), s = sec % 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  function normSpell(v) {
    return String(v || '').toLowerCase().replace(/[\s\-']/g, '');
  }
  function pct(a, b) { return b > 0 ? Math.round(a * 100 / b) : 0; }
  function todayStr() {
    var d = new Date();
    var m = d.getMonth() + 1, dd = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (dd < 10 ? '0' : '') + dd;
  }
  // 学习日（yyyy-mm-dd）转成中文短日期：11月26日 周四；解析失败时原样返回
  function cnDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
    if (!m) return String(s || '');
    var d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    if (isNaN(d.getTime())) return String(s || '');
    var w = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][d.getDay()];
    return Number(m[2]) + '月' + Number(m[3]) + '日 ' + w;
  }

  // ---------- 选项生成 ----------
  var FALLBACK_MEANINGS = [
    'n. 时间', 'n. 朋友', 'n. 机会', 'n. 方向',
    'v. 选择', 'v. 理解', 'n. 习惯', 'n. 计划'
  ];
  function buildOptions(item) {
    var pool = [], seen = {};
    S.allItems.forEach(function (it) {
      if (!it || !it.meaning) return;
      if (it.word_id === item.word_id) return;
      if (seen[it.meaning]) return;
      seen[it.meaning] = true;
      pool.push(it.meaning);
    });
    for (var i = 0; i < FALLBACK_MEANINGS.length && pool.length < 3; i++) {
      if (!seen[FALLBACK_MEANINGS[i]]) { seen[FALLBACK_MEANINGS[i]] = true; pool.push(FALLBACK_MEANINGS[i]); }
    }
    // 洗牌后取 3 个干扰项，再和正确项混合
    for (var j = pool.length - 1; j > 0; j--) {
      var k = Math.floor(Math.random() * (j + 1)); var t = pool[j]; pool[j] = pool[k]; pool[k] = t;
    }
    var opts = [item.meaning].concat(pool.slice(0, 3));
    for (var m = opts.length - 1; m > 0; m--) {
      var n = Math.floor(Math.random() * (m + 1)); var tmp = opts[m]; opts[m] = opts[n]; opts[n] = tmp;
    }
    return opts;
  }

  // ---------- 页面骨架 ----------
  function renderTopbar() {
    var name = $('userName');
    if (name && S.user) name.textContent = window.AppAuth.displayName(S.user) + ' · 已登录';
  }

  function renderShell(inner, screen, phase, feedback) {
    // 仅展示状态，不参与学习状态机；每次渲染清除旧状态样式。
    view.setAttribute('data-screen', screen || 'status');
    if (phase) view.setAttribute('data-phase', phase); else view.removeAttribute('data-phase');
    if (feedback) view.setAttribute('data-feedback', feedback); else view.removeAttribute('data-feedback');
    view.innerHTML = inner;
    fillPhrases();
  }

  function targetLabel() {
    try {
      if (!window.LumiGoals) return '';
      var g = window.LumiGoals.get();
      return ' · 目标 ' + g.newWords + ' 词';
    } catch (e) { return ''; }
  }
  function progress() {
    var total = S.allItems.length;
    var done = S.doneInitial + S.done;
    var skipped = S.skippedInit + S.skipped;
    return { total: total, done: done, skipped: skipped, pct: pct(done, total) };
  }

  function itemLabel(item) { return item.task_type === 'review' ? '复习' : '新词'; }
  function domainLabel(d) {
    var map = { gen: '通用', work: '职场', mech: '机械', med: '医疗', test: '测试' };
    return map[d] || '';
  }

  // ---------- 渲染：加载 / 错误 ----------
  function renderLoading() {
    // 首访不空壳：先给真实导航和模块，只有今日计划区在等待数据。
    // 返回用户会优先走同日本地快照，见 startHome()。
    var aiOn = !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.AI_CHAT);
    var ic = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">';
    var h = '<div class="v2-home v2-home-next v2-home-loading" aria-busy="true">';
    h += '<section class="v2-welcome v2-welcome-new"><div class="v2-welcome-copy"><div class="v2-welcome-date">' + esc(cnDate(todayStr())) + ' · 正在同步</div><h1>欢迎回来。</h1><p>今天想学什么？内容马上就到。</p></div><div class="v2-welcome-orb" aria-hidden="true"><span>L</span></div></section>';
    h += '<section class="card v2-hero v2-hero-skel"><div class="v2-hero-head"><div class="hero-txt"><div class="v2-hero-kicker"><span></span> 单词计划</div><h2 class="hero-title">正在同步今日计划</h2><div class="hero-sub">学习模块可以先打开</div></div><div class="v2-progress-orb"><div class="ring" style="--p:0"><span>…</span></div><small>新词进度' + targetLabel() + '</small></div></div><div class="v2-hero-actions"><button type="button" class="btn block" disabled>正在准备…</button></div></section>';
    h += '<section class="v2-modules" aria-labelledby="v2-mod-title"><div class="v2-section-head"><h2 id="v2-mod-title">学习模块</h2><a href="lesson.html">全部课程 ›</a></div><div class="v2-module-grid">';
    h += '<span class="v2-module v2-module--word"><span class="v2-module-icon">' + ic + '<path d="M4 19V5a2 2 0 0 1 2-2h14v18H6a2 2 0 0 1 0-4h14"/><path d="m9 12 2.5-6L14 12M10 10h3"/></svg></span><b>单词</b><small>同步中</small></span>';
    [['grammar','语法','规则','<path d="M4 5h16M4 10h10M4 15h7M4 20h6"/><path d="m14 17 3 3 4-6"/>'],
     ['listening','听力','听懂','<path d="M3 13v-2a9 9 0 0 1 18 0v2"/><rect x="3" y="12" width="5" height="8" rx="2"/><rect x="16" y="12" width="5" height="8" rx="2"/>'],
     ['reading','阅读','理解','<path d="M12 6c-3-3-7-3-10-2v15c4-1 7-1 10 2 3-3 6-3 10-2V4c-3-1-7-1-10 2v15"/>'],
     ['speaking','口语','表达','<rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11v1a7 7 0 0 0 14 0v-1M12 19v3m-4 0h8"/>']
    ].forEach(function (m) {
      h += '<a class="v2-module v2-module--' + m[0] + '" href="lesson.html?module=' + m[0] + '"><span class="v2-module-icon">' + ic + m[3] + '</svg></span><b>' + m[1] + '</b><small>' + m[2] + '</small></a>';
    });
    h += '</div></section>';
    h += renderQuickLinks(aiOn);
    h += '</div>';
    renderShell(h, 'home');
  }
  function renderError() {
    var off = S.offline;
    renderShell(
      '<div class="card">' +
      '<h3>' + (off ? '现在没有网络' : '加载失败') + '</h3>' +
      '<p class="small muted">' + esc(S.error || '未知错误') + '</p>' +
      (off ? '<p class="small muted">今天的学习内容需要联网才能打开。你之前没交上去的学习记录还在本机，联网后会自己补交，不会丢。</p>' +
        '<div class="ex-line"><span>本机待补交</span><span class="zh" id="pendingCount">— 条</span></div>' : '') +
      '<div class="row mt12"><button class="btn" data-act="reload">重试</button>' +
      '<a class="btn ghost" href="books.html">词书中心</a>' +
      '<button class="btn ghost" data-act="logout">重新登录</button></div>' +
      '</div>');
    if (off) refreshPending();
  }

  // ---------- 渲染：首页（Lavender Future 展示层，2026-11-26） ----------
  // 今日页与复习页共享材质、进度和操作组件。
  function renderQuickLinks(aiOn) {
    var h = '<div class="v2-quicklist">';
    if (aiOn) {
      h += '<a class="card aicoach v2-quick v2-coach" href="chat.html?v=20261129perf35"><span class="v2-coach-orb" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M5 10v4m4-7v10m6-12v14m4-9v4"/></svg></span><span class="aicoach-txt"><b>AI 英语老师</b><i>自由提问 · 双语文字交流</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    }
    h += '<a class="card aicoach v2-quick v2-voice" href="chat.html?mode=voice&v=20261129perf8"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3Z"/><path d="M5 11a7 7 0 0 0 14 0"/><path d="M12 18v3"/></svg></span><span class="aicoach-txt"><b>实时对话</b><i>开口说英语 · 可以随时打断</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    h += '<a class="card aicoach v2-quick v2-books" href="books.html?v=20261129perf35"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 19V5a2 2 0 0 1 2-2h14v18H6a2 2 0 0 1 0-4h14"/><path d="m9 12 2.5-6L14 12M10 10h3"/></svg></span><span class="aicoach-txt"><b>词书中心</b><i>选词书 · 调整每日词量</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    h += '<a class="card aicoach v2-quick v2-mistakes" href="word-mistakes.html?v=20261129perf35"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3 2 20h20L12 3Z"/><path d="M12 9v5m0 3v.5"/></svg></span><span class="aicoach-txt"><b>错词本</b><i>写错的词 · 收藏的词</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    h += '<a class="card aicoach v2-quick" href="practice.html?v=20261129perf35"><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></span><span class="aicoach-txt"><b>自由练习</b><i>错词 / 收藏 / 当前词书 · 跟写、听写、默写</i></span><span class="aicoach-go" aria-hidden="true">›</span></a>';
    h += '<a class="card aicoach v2-quick" id="kpQuick" href="knowledge.html?v=20261129perf35"><span class="kp-quick-badge" id="kpQuickBadge" hidden></span><span class="aicoach-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9"/><path d="M9.2 9.3a2.9 2.9 0 0 1 5.6 1c0 1.9-2.8 2.2-2.8 4"/><path d="M12 17.4v.4"/></svg></span><span class="aicoach-txt"><b>知识点掌握</b><i>语法 · 拼写 · 搭配的状态与证据</i></span><span class="aicoach-go" aria-hidden="true">›</span></a></div>';
    return h;
  }

  // ---------- 学习模式（认知 / 跟写 / 听写 / 默写） ----------
  var MODES = {
    read: { name: '认知', tip: '看一眼单词，选词义，再拼一遍。' },
    follow: { name: '跟写', tip: '照着单词逐字敲，敲错的字母会立刻标红。' },
    dictate: { name: '听写', tip: '只给发音，不看拼写，把听到的词写出来。' },
    recall: { name: '默写', tip: '只给中文意思，凭记忆写出英文。' },
    selftest: { name: '自测', tip: '快速自评：认识、有点印象、不认识。凭第一感觉点，别纠结。' }
  };
  function modeName(m) { return (MODES[m] || MODES.read).name; }

  function loadMode() {
    if (!window.DB || typeof window.DB.rpc !== 'function') return Promise.resolve();
    return window.DB.rpc('list_wordbooks', {}).then(function (res) {
      var p = (res && res.study_prefs) || {};
      var m = String(p.word_mode || '');
      if (MODES[m]) S.mode = m;
    }).catch(function () { /* 读不到就用上次的 */ });
  }

  function saveMode(m) {
    S.mode = MODES[m] ? m : 'read';
    if (!window.DB || typeof window.DB.rpc !== 'function') return Promise.resolve(S.mode);
    return window.DB.rpc('set_study_prefs', { p_patch: { word_mode: S.mode } }).then(function (res) {
      var p = (res && res.study_prefs) || {};
      if (MODES[p.word_mode]) S.mode = p.word_mode;
      return S.mode;
    }).catch(function () { return S.mode; });
  }

  function modeChipsHtml() {
    var h = '<div class="v2-seg v2-modes">';
    var keys = ['read', 'follow', 'dictate', 'recall', 'selftest'];
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      h += '<button class="v2-seg-btn" data-act="mode" data-mode="' + k + '" aria-pressed="' + (S.mode === k ? 'true' : 'false') + '">' + MODES[k].name + '</button>';
    }
    return h + '</div>';
  }

  // 跟写：把已输入的字母和目标词逐字比对
  function followHtml(word) {
    var w = String(word || ''), t = String(S.typed || '');
    var h = '<div class="fw-word" id="fwWord" aria-live="polite">';
    for (var i = 0; i < w.length; i++) {
      var ch = w.charAt(i);
      var cls = 'fw-ch';
      if (i < t.length) cls += (t.charAt(i).toLowerCase() === ch.toLowerCase() ? ' ok' : ' bad');
      else if (i === t.length) cls += ' cur';
      h += '<span class="' + cls + '">' + esc(ch === ' ' ? ' ' : ch) + '</span>';
    }
    return h + '</div>';
  }

  function typeInputHtml(item, placeholder) {
    return '<div class="field mt8"><input id="typeInput" aria-label="输入英文单词" type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done" placeholder="' + esc(placeholder || '输入英文单词') + '"></div>';
  }

  // ---------- 031 模块难度：听力 / 阅读各自一档，写进 study_prefs，AI 生成按此档位出题
  function levelCardHtml() { return '<section id="lumi-home-difficulty"></section>'; }

  function loadLevels() {
    const node = document.getElementById('lumi-home-difficulty');
    if (node && window.Difficulty) return window.Difficulty.mount(node, ['words', 'listening', 'reading']);
  }

  // B2 学习教练卡：首屏先占位，渲染完再异步补真实数据；读不到就明说读不到，不显示假进度。
  function coachLevelLabel(n) { return ['', 'L1 基础', 'L2 进阶', 'L3 挑战'][n] || 'L1 基础'; }
  function coachHref(h) { return /^[a-z0-9][a-z0-9?=&._-]*$/i.test(String(h || '')) ? h : 'memory.html'; }
  function coachCardHtml(p) {
    if (!p) {
      return '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>暂时读不到你的学习记录</small></div></div>' +
        '<p class="v2-coach-advice">现在可能是离线，或数据还没同步。先按计划学习，记录会保存在本机；联网后再看建议。</p>' +
        '<a class="v2-coach-link" href="memory.html">查看学习档案 ›</a>';
    }
    if (p.enabled === false) {
      return '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>学习档案已关闭</small></div></div>' +
        '<p class="v2-coach-advice">你关闭了「学习档案与教学记忆」，AI 老师和今日建议都不会读取你的学习记录。</p>' +
        '<a class="v2-coach-link" href="memory.html">去重新开启 ›</a>';
    }
    var lv = p.level || {};
    var sm = p.sample || {};
    var sample = sm.units ? '近 14 天 ' + sm.units + ' 题 · 正确率 ' + Math.round((sm.accuracy || 0) * 100) + '%' : '样本还少';
    var h = '<div class="v2-coach-head"><span class="v2-coach-orb" aria-hidden="true">✦</span><div><b>今日建议</b><small>' + esc(coachLevelLabel(lv.suggested || lv.base || 1)) + ' · ' + esc(sample) + '</small></div></div>';
    h += '<p class="v2-coach-advice">' + esc(p.advice || '按计划完成今天的学习。') + '</p>';
    var focus = (p.focus || []).slice(0, 3);
    if (focus.length) {
      h += '<div class="v2-coach-focus">';
      focus.forEach(function (f) {
        h += '<a class="v2-coach-chip" href="' + esc(coachHref(f.href)) + '">' + esc(f.label || '继续') + '<span aria-hidden="true">›</span></a>';
      });
      h += '</div>';
    }
    h += '<a class="v2-coach-link" href="memory.html">学习档案与教学记忆 ›</a>';
    return h;
  }
  /* ---------- AI 学习建议（learning_context → 网关 plan，服务端按天缓存） ---------- */
  var PLAN_MOD_ZH = { words: '单词', grammar: '语法', listening: '听力', reading: '阅读', speaking: '口语' };
  var PLAN_ICO = { words: 'Aa', grammar: 'G', listening: '♪', reading: 'R', speaking: 'M' };

  function planCardHtml(data) {
    var list = (data && data.suggestions) || [];
    if (!list.length) return '';
    var goal = (window.LumiPlan && window.LumiPlan.goal && window.LumiPlan.goal()) || '';
    var h = '<details class="v2-plan-details"><summary><span>接着学这些</span><span class="v2-plan-count">' + list.length + ' 条建议 · 展开</span></summary>' +
      '<div class="v2-plan-head"><span class="small muted">按你的真实记录推荐</span>' +
      '<button type="button" class="v2-plan-refresh" data-act="planRefresh">换一批</button></div>' +
      '<div class="v2-plan-goal">' +
        (goal ? '<b>目标</b><span>' + esc(goal) + '</span>' : '<span class="small muted">还没设学习目标，设一个建议会更贴你</span>') +
        '<button type="button" class="v2-plan-goal-btn" data-act="planGoal">' + (goal ? '改' : '设目标') + '</button>' +
      '</div>';
    h += '<div class="v2-plan-list">';
    list.forEach(function (s) {
      var mod = String(s.module || 'words');
      var words = mod === 'words';
      var open = words ? '<button type="button" class="v2-plan-item" data-act="planStart"'
        : '<a class="v2-plan-item" href="lesson.html?module=' + encodeURIComponent(mod) + '"';
      var close = words ? '</button>' : '</a>';
      h += open + '>' +
        '<span class="v2-plan-ico v2-plan-' + esc(mod) + '" aria-hidden="true">' + (PLAN_ICO[mod] || '·') + '</span>' +
        '<span class="v2-plan-body"><b>' + esc(s.title || '') + '</b>' +
        '<small>' + esc(s.reason || '') + (s.focus_words && s.focus_words.length ? ' · 重点词 ' + esc(s.focus_words.slice(0, 3).join(' / ')) : '') + '</small></span>' +
        '<span class="v2-plan-meta">' + esc(PLAN_MOD_ZH[mod] || mod) + ' · L' + (Number(s.level) || 4) + ' · ' + (Number(s.estimated_minutes) || 10) + '′</span>' +
        close;
    });
    h += '</div><div class="v2-plan-foot"><button type="button" class="link-btn" data-act="planSkip">今天不看了</button>' +
      '<span class="small muted">建议仅供参考，时间不必照做</span></div></details>';
    return h;
  }

  // ---------- 自适应学习引擎（真实记录决定下一步，零 AI） ----------
  var ADAPT = null;
  var ADAPT_KEY = 'lumi.adapt.v1';
  var adaptLoad = null;
  function readAdaptCache() {
    try {
      var o = JSON.parse(window.localStorage.getItem(ADAPT_KEY) || 'null');
      if (!o || o.day !== todayStr() || !o.data) return null;
      return o;
    } catch (e) { return null; }
  }
  function writeAdaptCache(data) {
    try { window.localStorage.setItem(ADAPT_KEY, JSON.stringify({ day: todayStr(), at: Date.now(), data: data })); } catch (e) { }
  }

  function adaptHref(item) {
    if (!item) return 'today.html';
    if (item.action === 'article') return 'article.html';
    if (item.action === 'write') return 'write.html';
    if (item.action === 'voice') return 'chat.html?mode=voice';
    if (item.action === 'drill' && item.kp) return 'drill.html?kp=' + encodeURIComponent(item.kp);
    return 'lesson.html?module=' + encodeURIComponent(item.module || 'listening');
  }

  function adaptItemHtml(item, i, primary) {
    var modZh = item.module === 'words' ? '单词' : item.module === 'listening' ? '听力' : item.module === 'reading' ? '阅读'
      : item.module === 'writing' ? '写作' : item.module === 'speaking' ? '口语' : item.module;
    var meta = modZh + ' · L' + item.level + ' · ' + (item.est_minutes || item.estimated_minutes || 6) + ' 分钟';
    var tag = item.due ? '<span class="v2-adapt-tag">该复查了</span>' : '';
    var label = '<b>' + tag + esc(item.title || '练一会儿') + '</b><i>' + esc(item.reason || '') + '</i><small>' + meta + '</small>';
    var go = primary ? '<span class="v2-adapt-go" aria-hidden="true">开始 ›</span>' : '';
    if (item.action === 'study') {
      return '<button type="button" class="' + (primary ? 'v2-adapt-main' : 'v2-adapt-side') + '" data-act="adapt" data-i="' + i + '">' + label + go + '</button>';
    }
    return '<a class="' + (primary ? 'v2-adapt-main' : 'v2-adapt-side') + '" href="' + adaptHref(item) + '" data-act="adaptgo" data-i="' + i + '">' + label + go + '</a>';
  }

  function adaptCardHtml(data) {
    var h = '<div class="v2-adapt-head"><h2>接下来这样练</h2>';
    if (data && data.ready) h += '<button type="button" class="v2-adapt-refresh" data-act="adaptRefresh">换个安排</button>';
    h += '</div>';
    if (!data || !data.ready) {
      h += '<p class="v2-adapt-note">' + esc((data && data.note) || '先随便练几项，这里就会按你的记录安排。') + '</p>';
      return h;
    }
    var items = (data.items || []).slice(0, 3);
    if (!items.length) {
      h += '<p class="v2-adapt-note">' + esc(data.note || '今天没有特别需要补的，随便挑一个练。') + '</p>';
      return h;
    }
    h += adaptItemHtml(items[0], 0, true);
    if (items.length > 1) {
      h += '<div class="v2-adapt-row">';
      for (var i = 1; i < items.length; i++) h += adaptItemHtml(items[i], i, false);
      h += '</div>';
    }
    var adj = (data.adjust || [])[0];
    if (adj) {
      h += '<p class="v2-adapt-adj">' + esc(adj.why) + ' <button type="button" class="v2-adapt-adj-btn" data-act="adaptLevel" data-mod="' + esc(adj.module) + '" data-lv="' + (adj.to || 0) + '">调到 L' + adj.to + '</button></p>';
    }
    var basis = data.basis || {};
    var bits = [];
    if (basis.attempts) bits.push('近 30 天作答 ' + basis.attempts + ' 次');
    if (basis.listening_accuracy != null) bits.push('听力正确率 ' + Math.round(basis.listening_accuracy * 100) + '%');
    if (basis.articles != null) bits.push('读文章 ' + basis.articles + ' 篇');
    if (basis.spelling) bits.push('错词 ' + basis.spelling + ' 个');
    if (bits.length) h += '<details class="v2-adapt-more"><summary>依据与调整</summary><p>依据：' + esc(bits.join(' · ')) + (data.goal ? ' · 目标「' + esc(data.goal) + '」' : '') + '</p></details>';
    return h;
  }

  function hydrateAdaptive(force) {
    var box = document.getElementById('adaptCard');
    if (!box || !window.DB || typeof window.DB.rpc !== 'function') return;
    if (ADAPT && !force) { box.innerHTML = adaptCardHtml(ADAPT); box.hidden = false; return; }
    var cached = !force ? readAdaptCache() : null;
    var shown = false;
    if (cached) {
      ADAPT = cached.data;
      box.innerHTML = adaptCardHtml(ADAPT);
      box.hidden = false;
      shown = true;
      // 10 分钟内的安排直接复用；更久的先显示，再静默刷新，不闪“正在看”。
      if (Date.now() - Number(cached.at || 0) < 10 * 60e3) return;
    }
    if (adaptLoad) return adaptLoad;
    if (!shown) {
      box.innerHTML = '<p class="v2-adapt-note">正在看你的学习记录…</p>';
      box.hidden = false;
    }
    adaptLoad = window.DB.rpc('adaptive_plan', {}).then(function (res) {
      ADAPT = res || null;
      writeAdaptCache(ADAPT);
      box.innerHTML = adaptCardHtml(ADAPT);
      box.hidden = false;
    }).catch(function () {
      if (!shown) box.innerHTML = '<p class="v2-adapt-note">暂时读不到学习记录，先按自己的节奏练。</p>';
    }).then(function () { adaptLoad = null; });
    return adaptLoad;
  }

  function adaptLevel(mod, lv) {
    if (!window.Difficulty || !lv) return;
    window.Difficulty.read().then(function (res) {
      var rev = (res && res.revision) || 0;
      return window.Difficulty.set({ module: mod, mode: 'manual', level: lv, revision: rev });
    }).then(function () {
      toast('已把' + (mod === 'words' ? '单词' : mod === 'listening' ? '听力' : '阅读') + '难度调到 L' + lv);
      ADAPT = null;
      hydrateAdaptive(true);
    }).catch(function () { toast('改难度失败，稍后再试'); });
  }

  // 到期复查提醒：首页顶部一条固定提示（可「今天先不提醒」）
  var KP_SNOOZE_KEY = 'lumi.kp.snooze.v1';
  function kpSnoozedToday() {
    try {
      var v = window.localStorage.getItem(KP_SNOOZE_KEY);
      return v === todayStr();
    } catch (e) { return false; }
  }
  // 计划卡里先插一条「先复查」，保证到期复查不会被学新词挤掉
  function injectPlanReview(n) {
    var list = document.querySelector('#planCard .v2-plan-list');
    if (!list || list.querySelector('[data-kp-plan]')) return false;
    var mins = Math.max(2, Math.round(n * 1.2));
    var a = document.createElement('a');
    a.className = 'v2-plan-item';
    a.href = 'knowledge.html';
    a.setAttribute('data-kp-plan', '1');
    a.innerHTML = '<span class="v2-plan-ico v2-plan-review" aria-hidden="true">!</span>' +
      '<span class="v2-plan-body"><b>先复查 ' + n + ' 个知识点</b>' +
      '<small>到期了，先复查再学新词，记得更牢</small></span>' +
      '<span class="v2-plan-meta">复查 · 约 ' + mins + '′</span>';
    list.insertBefore(a, list.firstChild);
    return true;
  }

  function showKpBanner(n) {
    if (!n || kpSnoozedToday()) return;
    if (injectPlanReview(n)) return;
    var host = document.querySelector('.v2-quicklist');
    if (!host || document.getElementById('kpDueBanner')) return;
    var mins = Math.max(2, Math.round(n * 1.2));
    var el = document.createElement('div');
    el.id = 'kpDueBanner';
    el.className = 'kp-due-banner';
    el.innerHTML = '<span class="kp-due-ico" aria-hidden="true">!</span>' +
      '<span class="kp-due-txt"><b>今天有 ' + n + ' 个知识点该复查</b><i>约 ' + mins + ' 分钟，按你之前的错题排的</i></span>' +
      '<a class="btn sm" href="knowledge.html">去复查</a>' +
      '<button type="button" class="kp-due-snooze" data-kp-snooze="1">今天先不提醒</button>';
    host.parentNode.insertBefore(el, host.nextSibling);
    var btn = el.querySelector('[data-kp-snooze]');
    if (btn) btn.addEventListener('click', function () {
      try { window.localStorage.setItem(KP_SNOOZE_KEY, todayStr()); } catch (e) {}
      el.remove();
    });
  }

  var kpDueInFlight = null;
  var KP_DUE_KEY = 'lumi.kpdue.v1';
  function applyKpDue(n) {
    var badge = document.getElementById('kpQuickBadge');
    n = Number(n) || 0;
    if (badge) {
      if (!n) { badge.hidden = true; }
      else { badge.textContent = n + ' 个待复查'; badge.hidden = false; }
    }
    S.kpDueCount = n;
    if (!badge) showKpBanner(n); // 首页已有知识点角标，不再重复占一条横幅
  }
  function readKpDueCache() {
    try {
      var o = JSON.parse(window.localStorage.getItem(KP_DUE_KEY) || 'null');
      return o && o.day === todayStr() ? o : null;
    } catch (e) { return null; }
  }
  function hydrateKpDue() {
    if (!window.DB || typeof window.DB.rpc !== 'function') return;
    var c = readKpDueCache();
    if (c) applyKpDue(c.count);
    if (kpDueInFlight || (c && Date.now() - Number(c.at || 0) < 60e3)) return;
    kpDueInFlight = window.DB.rpc('kp_due', { p_limit: 5 }).then(function (r) {
      var d = r && (r.data || r);
      var n = d && Number(d.count || 0);
      applyKpDue(n || 0);
      try { window.localStorage.setItem(KP_DUE_KEY, JSON.stringify({ day: todayStr(), at: Date.now(), count: n || 0 })); } catch (e) { }
    }).catch(function () { /* 保留缓存角标，不打扰 */ }).then(function () { kpDueInFlight = null; });
  }

  async function hydratePlan() {
    var node = document.getElementById('planCard');
    if (!node || !window.LumiPlan || !window.AI) return;
    if (window.LumiPlan.skippedToday()) { node.hidden = true; return; }
    var r = null;
    try { r = await window.LumiPlan.suggestions(false); } catch (e) { r = null; }
    var data = r && r.data;
    if (!data) {
      node.hidden = false;
      node.innerHTML = '<details class="v2-plan-details"><summary><span>接着学这些</span><span class="v2-plan-count">本地建议 · 展开</span></summary>' +
        '<div class="v2-plan-list"><a class="v2-plan-item" href="review.html"><span class="v2-plan-ico v2-plan-words" aria-hidden="true">Aa</span><span class="v2-plan-body"><b>先把到期复习做完</b><small>按你现有的复习安排</small></span><span class="v2-plan-meta">复习</span></a>' +
        '<a class="v2-plan-item" href="lesson.html?module=listening"><span class="v2-plan-ico v2-plan-listening" aria-hidden="true">♪</span><span class="v2-plan-body"><b>听一段短文</b><small>离线也能做</small></span><span class="v2-plan-meta">听力</span></a></div></details>';
      return;
    }
    var html = planCardHtml(data);
    node.hidden = !html;
    node.innerHTML = html;
    if (S.kpDueCount) injectPlanReview(S.kpDueCount);
  }

  async function hydrateCoachCard() {
    var node = document.getElementById('coachCard');
    if (!node || !window.DB || !window.DB.learnerProfile) return;
    var p = null;
    try { p = await window.DB.learnerProfile(); } catch (e) { p = null; }
    if (!node.isConnected) return;
    node.innerHTML = coachCardHtml(p);
    node.hidden = false;
    node.classList.add('is-ready');
  }

  function renderTodayHome() {
    var p = progress();
    var items = (S.task && S.task.items) || [];
    var rev = items.filter(function (i) { return i.task_type === 'review'; });
    var revDone = rev.filter(function (i) { return i.status === 'completed'; }).length;
    var canStart = S.queue.length > 0;
    var aiOn = !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.AI_CHAT);
    var iconPaths = {
      word: '<path d="M4 19V5a2 2 0 0 1 2-2h14v18H6a2 2 0 0 1 0-4h14"/><path d="m9 12 2.5-6L14 12M10 10h3"/>',
      grammar: '<path d="M4 5h16M4 10h10M4 15h7M4 20h6"/><path d="m14 17 3 3 4-6"/>',
      listening: '<path d="M3 13v-2a9 9 0 0 1 18 0v2"/><rect x="3" y="12" width="5" height="8" rx="2"/><rect x="16" y="12" width="5" height="8" rx="2"/>',
      reading: '<path d="M12 6c-3-3-7-3-10-2v15c4-1 7-1 10 2 3-3 6-3 10-2V4c-3-1-7-1-10 2v15"/>',
      speaking: '<rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11v1a7 7 0 0 0 14 0v-1M12 19v3m-4 0h8"/>'
    };
    function ico(key) {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + iconPaths[key] + '</svg>';
    }
    var h = '<div class="v2-home v2-home-next' + (S.offlineView ? ' v2-home-offline' : '') + '">';
    h += '<section class="v2-welcome v2-welcome-new"><div class="v2-welcome-copy"><div class="v2-welcome-date">' + esc(cnDate(S.task && S.task.study_date)) + (S.offlineView ? ' · 缓存任务' : (S.cachePreview ? ' · 同步中' : (S.syncError ? ' · 未同步' : ''))) + '</div><h1>欢迎回来。</h1><p>今天想学什么？按自己的节奏开始。</p>' + (aiOn ? '<a class="v2-welcome-cta" href="chat.html">和 AI 老师聊聊 <span aria-hidden="true">›</span></a>' : '<a class="v2-welcome-cta" href="books.html">选择学习内容 <span aria-hidden="true">›</span></a>') + '</div><div class="v2-welcome-orb" aria-hidden="true"><span>L</span></div></section>';
    if (S.offlineView) {
      var stale = S.cacheDate && S.cacheDate !== todayStr();
      h += '<div class="card v2-offline"><b>离线查看</b><p class="small muted mt8">' + (stale ? '显示 ' + esc(S.cacheDate) + ' 的内容，联网后刷新。' : '显示上次同步的内容，联网后刷新。') + ' 学习记录会先存在本机，联网后自动补交。</p></div>';
    }
    h += '<section class="card v2-hero" id="today-word" aria-labelledby="v2-word-title"><div class="v2-hero-head"><div class="hero-txt"><div class="v2-hero-kicker"><span></span> 单词计划</div><h2 class="hero-title" id="v2-word-title">' + (canStart ? '今日新词' : (p.total === 0 ? '暂无待学新词' : (p.skipped === p.total ? '本轮新词已跳过' : (p.skipped ? '本轮新词学习结束' : '今日新词已完成')))) + '</h2>';
    h += '<div class="hero-sub">已完成 <b>' + p.done + ' / ' + p.total + '</b> 个' + (canStart ? ' · 剩余 ' + S.queue.length + ' 个' : '') + (p.skipped ? ' · 跳过 ' + p.skipped + ' 个' : '') + '</div></div>';
    h += '<div class="v2-progress-orb"><div class="ring" style="--p:' + p.pct + '" role="img" aria-label="新词完成率 ' + p.pct + '%"><span>' + (p.total ? p.pct + '%' : '—') + '</span></div><small>新词进度' + targetLabel() + '</small></div></div>';
    h += '<div class="v2-hero-actions">';
    if (canStart) h += '<button type="button" class="btn block" data-act="start">' + (p.done + p.skipped > 0 ? '继续学习' : '开始学习') + '<span aria-hidden="true">›</span></button>';
    else h += '<a class="btn block" href="lesson.html">继续其他课程<span aria-hidden="true">›</span></a><button type="button" class="btn ghost sm v2-refresh" data-act="reload">刷新任务</button>';
    h += '</div></section>';
    h += '<section class="card v2-adapt" id="adaptCard" aria-live="polite" hidden></section>';
    h += '<section class="v2-modules" aria-labelledby="v2-mod-title"><div class="v2-section-head"><h2 id="v2-mod-title">学习模块</h2><a href="lesson.html">全部课程 ›</a></div><div class="v2-module-grid">';
    h += (canStart ? '<button type="button" class="v2-module v2-module--word" data-act="start">' : '<a class="v2-module v2-module--word" href="#today-word">') + '<span class="v2-module-icon">' + ico('word') + '</span><b>单词</b><small>词汇</small>' + (canStart ? '</button>' : '</a>');
    [['grammar','语法','规则'],['listening','听力','听懂'],['reading','阅读','理解'],['speaking','口语','表达']].forEach(function (m) {
      h += '<a class="v2-module v2-module--' + m[0] + '" href="lesson.html?module=' + m[0] + '"><span class="v2-module-icon">' + ico(m[0]) + '</span><b>' + m[1] + '</b><small>' + m[2] + '</small></a>';
    });
    h += '</div></section>';
    h += renderQuickLinks(aiOn);
    h += '<section class="card v2-plan-card" id="planCard" aria-live="polite" hidden></section>';
    h += '<section class="card v2-overview" aria-labelledby="v2-overview-title"><div class="v2-section-head"><h2 id="v2-overview-title">今日概览</h2><a href="stats.html">学习统计 ›</a></div><div class="v2-metrics">';
    h += '<div class="v2-metric"><b>' + p.done + ' / ' + p.total + '</b><span>新词</span></div><div class="v2-metric"><b>' + revDone + ' / ' + rev.length + '</b><span>到期复习</span></div><div class="v2-metric"><b id="pendingCount">' + S.pending + ' 条</b><span>待补交</span></div></div>';
    h += '<div class="v2-actions"><button type="button" class="btn ghost sm" data-act="flush">补交本机记录</button><a class="btn ghost sm" href="review.html">去到期复习</a></div></section>';
    h += levelCardHtml();
    h += '</div>';
    renderShell(h, 'home');
    hydrateAdaptive();
    hydratePlan();
    hydrateKpDue();
  }

  function renderHome() {
    if (MODE === 'today') return renderTodayHome();
    var p = progress();
    var canStart = S.queue.length > 0;
    var aiOn = !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.AI_CHAT);
    var newAll = ((S.task && S.task.items) || []).filter(function (i) { return i.task_type === 'new'; });
    var newDone = newAll.filter(function (i) { return i.status === 'completed'; }).length;
    var html = '<div class="v2-home v2-review-home' + (S.offlineView ? ' v2-review-offline' : '') + '">';
    html += '<section class="v2-welcome"><div class="v2-welcome-date">' + esc(cnDate(S.task && S.task.study_date)) + (S.offlineView ? ' · 缓存任务' : (S.cachePreview ? ' · 同步中' : (S.syncError ? ' · 未同步' : ''))) + '</div><h1>温故，知新。</h1><p>复习已经学过的单词，让记忆更牢固。</p></section>';
    if (S.offlineView) {
      var staleTip = S.cacheDate && S.cacheDate !== todayStr() ? '显示 ' + esc(S.cacheDate) + ' 的内容，联网后刷新。' : '显示上次同步的内容，联网后刷新。';
      html += '<div class="card v2-offline"><b>离线查看</b><p class="small muted mt8">' + staleTip + ' 学习记录会先存在本机，联网后自动补交。</p></div>';
    }
    html += '<section class="card v2-hero" aria-labelledby="v2-review-title"><div class="v2-hero-head"><div class="hero-txt"><div class="v2-hero-kicker"><span></span> 复习计划</div><h2 class="hero-title" id="v2-review-title">到期单词</h2><div class="hero-sub">已完成 <b>' + p.done + ' / ' + p.total + '</b> 个' + (canStart ? ' · 剩余 ' + S.queue.length + ' 个' : '') + (p.skipped ? ' · 跳过 ' + p.skipped + ' 个' : '') + '</div></div>';
    html += '<div class="v2-progress-orb"><div class="ring" style="--p:' + p.pct + '" role="img" aria-label="复习完成率 ' + p.pct + '%"><span>' + (p.total ? p.pct + '%' : '—') + '</span></div><small>复习进度</small></div></div>';
    html += '<div class="v2-hero-actions"><button class="btn block" data-act="' + (canStart ? 'start' : 'reload') + '">' + (canStart ? (p.done + p.skipped > 0 ? '继续复习' : '开始复习') : '刷新任务') + '</button></div></section>';
    html += '<section class="card v2-overview"><div class="v2-section-head"><h2>今日概览</h2><a href="stats.html">学习统计 ›</a></div><div class="v2-metrics"><div class="v2-metric"><b>' + newDone + ' / ' + newAll.length + '</b><span>新词</span></div><div class="v2-metric"><b>' + p.done + ' / ' + p.total + '</b><span>到期复习</span></div><div class="v2-metric"><b id="pendingCount">' + S.pending + ' 条</b><span>待补交</span></div></div><div class="v2-actions"><button class="btn ghost sm" data-act="flush">补交本机记录</button><a class="btn ghost sm" href="today.html">去今日新词</a></div></section>';
    html += '<section class="card v2-tools"><div class="v2-section-head"><h2>复习工具</h2><a href="stats.html">统计 ›</a></div><div class="v2-tool-row">' +
      '<a class="v2-tool" href="mistakes.html">错题本</a>' +
      '<a class="v2-tool" href="word-mistakes.html">单词错题</a>' +
      '<a class="v2-tool" href="practice.html">自由练习</a>' +
      '<a class="v2-tool" href="drill.html">专项训练</a>' +
      '<a class="v2-tool" href="test.html">每周测试</a>' +
      '</div></section>';
    html += renderQuickLinks(aiOn) + '</div>';
    renderShell(html, 'home');
  }

  // ---------- 渲染：学习流 ----------
  function currentItem() { return S.queue[S.idx] || null; }

  // ---------- 07-H 错词延迟重测：答错后隔几道题再测，不当场复现，也不重复提交完成记录
  var RETRY_GAP = 4, RETRY_MAX = 2;
  function scheduleRetry(item) {
    if (!item || item.__retryQueued) return;
    item.__retryQueued = true;
    S.retry.push({ item: item, due: S.idx + RETRY_GAP, tries: 1 });
  }
  function dueRetry(atIdx, ignoreDue) {
    for (var i = 0; i < S.retry.length; i++) {
      if (ignoreDue || S.retry[i].due <= atIdx) return S.retry.splice(i, 1)[0];
    }
    return null;
  }
  // ---------- 07-C/07-F 分组集中默写：先学完一组，再统一默写这一组
  var GROUP_SIZE = 10;
  function groupEnd() { return Math.min(S.groupStart + GROUP_SIZE, S.queue.length); }
  function needsGroupSpell() {
    return !S.groupSpell && S.idx + 1 >= groupEnd() && groupEnd() > S.groupStart;
  }
  function startGroupSpell() {
    var order = [], i;
    for (i = S.groupStart; i < groupEnd(); i++) order.push(i);
    for (i = order.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = order[i]; order[i] = order[j]; order[j] = t;
    }
    S.groupSpell = { order: order, pos: 0, typed: '', ok: null, right: 0, wrong: [] };
    S.phase = 'gspell';
    renderStudy();
  }
  function groupSpellItem() {
    if (!S.groupSpell || !S.groupSpell.order) return null;
    return S.queue[S.groupSpell.order[S.groupSpell.pos]] || null;
  }
  function startRetest(entry) {
    S.retestItem = entry.item;
    S.retestTries = entry.tries;
    S.retestOk = null;
    S.retestTyped = '';
    S.phase = 'retest';
    renderStudy();
  }

  function studyHead(item) {
    var p = progress();
    var html = '<div class="study-head">';
    html += '<div class="row" style="align-items:center">';
    html += '<span class="pill">' + itemLabel(item) + '</span>';
    var posBase = S.done + S.doneInitial + S.skipped + S.skippedInit;
    var posNow = Math.max(1, Math.min(p.total, posBase + (S.phase === 'item_done' ? 0 : 1)));
    html += '<span class="muted small">第 ' + posNow + ' / ' + p.total + ' 个</span>';
    if (S.offlineStudy) html += '<span class="pill">离线</span>';
    html += '<span class="spacer"></span>';
    html += '<span class="badge" id="timer">' + fmt(S.elapsed) + '</span>';
    html += '</div>';
    html += '<div class="bar mt8" role="progressbar" aria-label="已完成比例" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + p.pct + '"><i style="width:' + p.pct + '%"></i></div>';
    html += '</div>';
    return html;
  }

  // 发音按钮：英美双音，都在同一个点击手势里朗读（iPhone Safari 要求），播放期间按钮显示「朗读中」
  function sayBtn(word, where) {
    var w = esc(word || '');
    var svg = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9h4l5-4v14l-5-4H3zM16 9a4 4 0 0 1 0 6m3-9a8 8 0 0 1 0 12"/></svg>';
    if (where === 'example') {
      return '<div class="say-row">' +
        '<button class="say-btn" data-act="say" data-w="' + w + '" data-where="example" data-lang="en-US" title="朗读英文例句">' + svg + '<span class="say-txt">听例句</span></button>' +
        '<button class="say-btn ghost" data-act="say" data-w="' + w + '" data-where="example" data-lang="en-US" data-rate="0.72" title="慢速朗读例句">' + svg + '<span class="say-txt">慢速</span></button>' +
        '</div>';
    }
    return '<div class="say-row">' +
      '<button class="say-btn" data-act="say" data-w="' + w + '" data-where="word" data-lang="en-US" title="美式发音">' + svg + '<span class="say-txt">美音</span></button>' +
      '<button class="say-btn ghost" data-act="say" data-w="' + w + '" data-where="word" data-lang="en-GB" title="英式发音">' + svg + '<span class="say-txt">英音</span></button>' +
      '</div>';
  }

  // 单词详情：只显示数据库里真实存在的字段（词性 / 词形变化 / 常用度 / 柯林斯星级 / 英文释义），缺失就不显示
  // 详情 RPC 结果缓存：卡片上的固定搭配和详情折叠共用一次请求
  var DETAIL_CACHE = {};
  function getDetail(id) {
    if (!id) return Promise.resolve(null);
    if (DETAIL_CACHE[id]) return Promise.resolve(DETAIL_CACHE[id]);
    return window.DB.rpc('word_detail', { p_word_id: id }).then(function (d) {
      if (d && d.ok !== false) DETAIL_CACHE[id] = d;
      return d;
    });
  }

  // 卡片上的固定搭配：只显示数据库里真实存在的短语，最多 3 条
  function phrasesHtml(list) {
    if (!list || !list.length) return '';
    var out = [];
    for (var i = 0; i < list.length && i < 3; i++) {
      var p = list[i] || {};
      if (!p.phrase) continue;
      out.push('<div class="phr"><b>' + esc(p.phrase) + '</b><span>' + esc(p.meaning || '') + '</span></div>');
    }
    return out.length ? '<div class="word-phr-box"><div class="wd-k">固定搭配</div>' + out.join('') + '</div>' : '';
  }

  // 卡片上只露「搭配名」（一行小字），完整释义放详情折叠里，避免卡片太满
  function phrasesTeaser(list) {
    if (!list || !list.length) return '';
    var out = [];
    for (var i = 0; i < list.length && i < 3; i++) {
      var p = list[i] || {};
      if (p.phrase) out.push('<span class="phr-chip">' + esc(p.phrase) + '</span>');
    }
    if (!out.length) return '';
    return '<div class="word-phr-line"><span class="wd-k">搭配</span>' + out.join('') + '</div>';
  }

  function fillPhrases() {
    var nodes = view ? view.querySelectorAll('[data-phr]') : [];
    for (var i = 0; i < nodes.length; i++) {
      (function (node) {
        var id = node.getAttribute('data-phr');
        var teaser = node.classList && node.classList.contains('word-phr');
        getDetail(id).then(function (d) {
          var list = d && d.phrases;
          node.innerHTML = teaser ? phrasesTeaser(list) : phrasesHtml(list);
          if (!node.innerHTML) node.innerHTML = '';
        }).catch(function () { node.innerHTML = ''; });
      })(nodes[i]);
    }
  }

  function wordDetailBtn(item) {
    if (!item || !item.word_id) return '';
    var id = esc(item.word_id);
    return '<div class="wd-wrap"><button class="wd-more" data-act="wd" data-id="' + id + '" aria-expanded="false">词性 · 词形 · 常用度</button>' +
      '<div class="wd-box hide" id="wd-' + id + '"></div></div>';
  }

  function freqLabel(rank) {
    var n = parseInt(rank, 10);
    if (!(n > 0)) return '';
    if (n <= 1000) return '最常用（约前 ' + n + ' 位）';
    if (n <= 3000) return '常用（约前 ' + n + ' 位）';
    if (n <= 8000) return '一般（约前 ' + n + ' 位）';
    return '较少见（约前 ' + n + ' 位）';
  }

  function wordDetailHtml(d, id) {
    if (!d || d.ok === false) return '<p class="small muted">没有更多资料。</p>';
    var rows = [];
    function row(k, v) {
      if (v == null || v === '') return;
      rows.push('<div class="wd-row"><span class="wd-k">' + esc(k) + '</span><span class="wd-v">' + v + '</span></div>');
    }
    row('词性', d.pos ? esc(d.pos) : '');
    row('词形变化', d.forms ? esc(d.forms) : '');
    row('常用度', freqLabel(d.freq_rank));
    if (d.misses > 0) row('写错次数', d.misses + ' 次' + (d.mastered ? '（已标记为掌握）' : ''));
    if (d.favorited || d.mastered) {
      var flags = [];
      if (d.favorited) flags.push('已收藏');
      if (d.mastered) flags.push('已掌握');
      rows.push('<div class="wd-row"><span class="wd-k">状态</span><span class="wd-v">' + esc(flags.join(' · ')) + '</span></div>');
    }
    if (d.phrases && d.phrases.length) {
      var pl = [];
      for (var j = 0; j < d.phrases.length; j++) {
        var ph = d.phrases[j] || {};
        if (!ph.phrase) continue;
        pl.push('<p class="wd-def"><b>' + esc(ph.phrase) + '</b> ' + esc(ph.meaning || '') + '</p>');
      }
      if (pl.length) rows.push('<div class="wd-row col"><span class="wd-k">固定搭配</span><div class="wd-v">' + pl.join('') + '</div></div>');
    }
    row('柯林斯星级', d.collins ? new Array(Math.max(1, Math.min(5, d.collins)) + 1).join('★') : '');
    if (d.definition_en) {
      var def = String(d.definition_en).split(/\n+/).filter(function (x) { return x.trim(); }).slice(0, 4);
      var dl = [];
      for (var i = 0; i < def.length; i++) dl.push('<p class="wd-def">' + esc(def[i].trim()) + '</p>');
      rows.push('<div class="wd-row col"><span class="wd-k">英文释义</span><div class="wd-v">' + dl.join('') + '</div></div>');
    }
    if (id) {
      var favLabel = (d && d.favorited) ? '取消收藏' : '收藏这个词';
      var mstLabel = (d && d.mastered) ? '移出错词本（重新学）' : '标为已掌握';
      rows.push('<div class="wd-acts">' +
        '<button type="button" class="btn ghost sm" data-act="fav" data-id="' + esc(id) + '">' + favLabel + '</button>' +
        '<button type="button" class="btn ghost sm" data-act="master" data-id="' + esc(id) + '" data-on="' + ((d && d.mastered) ? '1' : '0') + '">' + mstLabel + '</button>' +
        '</div>');
    }
    if (!rows.length) return '<p class="small muted">没有更多资料。</p>';
    return rows.join('');
  }

  function wordCard(item, compact) {
    var html = '<div class="wordcard">';
    html += '<div class="hero-date">' + esc(domainLabel(item.domain)) + (item.difficulty ? ' · 难度 ' + esc(item.difficulty) : '') + '</div>';
    html += '<div class="word-en">' + esc(item.word) + '</div>';
    html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
    html += sayBtn(item.word, 'word');
    html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
    if (item.word_id) html += '<div class="word-phr" data-phr="' + esc(item.word_id) + '"></div>';
    html += wordDetailBtn(item);
    if (!compact) {
      if (item.example_en) {
        html += '<div class="word-ex"><b>' + esc(item.example_en) + '</b>' + sayBtn(item.example_en, 'example');
        if (item.example_zh) html += '<div class="mt8">' + esc(item.example_zh) + '</div>';
        html += '</div>';
      }
    }
    html += '</div>';
    return html;
  }

  function optionsHtml(item, picked, reveal) {
    var html = '';
    for (var i = 0; i < S.options.length; i++) {
      var opt = S.options[i];
      var cls = 'opt';
      if (reveal) {
        if (opt === item.meaning) cls += ' right';
        else if (picked != null && i === picked) cls += ' wrong';
      }
      html += '<button class="' + cls + '" data-act="pick" data-i="' + i + '"' + (reveal ? ' disabled' : '') + '>';
      html += '<span class="k">' + String.fromCharCode(65 + i) + '</span><span>' + esc(opt) + '</span></button>';
    }
    return html;
  }

  // 跟写：输入时实时刷新逐字比对
  function onTypeInput(ev) {
    S.typed = ev && ev.target ? ev.target.value : '';
    if (S.mode !== 'follow') return;
    var item = currentItem();
    var box = $('fwWord');
    if (!item || !box) return;
    box.innerHTML = followHtml(item.word).replace(/^<div class="fw-word" id="fwWord"[^>]*>/, '').replace(/<\/div>$/, '');
  }

  function renderStudy() {
    scheduleSnapshot();
    var item = (S.phase === 'gspell' || S.phase === 'gspell_fb') ? groupSpellItem() : currentItem();
    if (!item) {
      if (S.phase === 'group_done') { renderGroupDone(); return; }
      renderDone(); return;
    }
    var html = studyHead(item);
    var stage = { card:'认识单词', quiz:'词义选择', quiz_fb:'词义反馈', spell:'拼写练习', spell_fb:'拼写反馈', retry:'当轮复现', retry_fb:'复现反馈',
      type: modeName(S.mode), type_fb: '模式反馈', retest:'错词再测', retest_fb:'再测反馈',
      gspell:'集中默写', gspell_fb:'默写反馈',
      saving:'保存记录', item_done:'本词结果' };
    html += '<div class="v2-study-stage">' + stage[S.phase] + '</div>';

    if (S.phase === 'card') {
      html += wordCard(item, false);
      html += '<div class="card tight">';
      html += '<p class="small muted">学习模式</p>';
      html += modeChipsHtml();
      html += '<p class="small muted mt8">' + esc((MODES[S.mode] || MODES.read).tip) + '</p>';
      var startAct = S.mode === 'read' ? 'toquiz' : 'totype';
      var startLabel = S.mode === 'read' ? '开始答题' : '开始' + modeName(S.mode);
      html += '<div class="row mt8"><button class="btn block" data-act="' + startAct + '"' + (S.busy ? ' disabled' : '') + '>' + startLabel + '</button></div>';
      html += '<div class="row mt8"><button class="btn ghost sm" data-act="skip"' + (S.busy ? ' disabled' : '') + '>跳过这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'type') {
      html += '<div class="card tight"><h3>' + esc(modeName(S.mode)) + '</h3>';
      if (S.mode === 'selftest') {
        html += '<p class="small muted">先在心里回忆这个中文对应的英文，然后老实自评。</p>';
        html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
        html += '<div class="row mt12"><button class="btn block" data-act="selfrate" data-r="known"' + (S.busy ? ' disabled' : '') + '>认识，能直接写出来</button></div>';
        html += '<div class="row mt8"><button class="btn ghost block" data-act="selfrate" data-r="fuzzy"' + (S.busy ? ' disabled' : '') + '>有点印象，但要想想</button></div>';
        html += '<div class="row mt8"><button class="btn ghost block" data-act="selfrate" data-r="unknown"' + (S.busy ? ' disabled' : '') + '>不认识</button></div>';
      } else if (S.mode === 'follow') {
        html += '<p class="small muted">照着敲一遍，敲错的字母会标红。</p>';
        html += followHtml(item.word);
        html += '<div class="mt8">' + sayBtn(item.word, 'word') + '</div>';
        html += typeInputHtml(item, '照着上面的单词输入');
      } else if (S.mode === 'dictate') {
        html += '<p class="small muted">听发音，写出你听到的单词。可以反复重听。</p>';
        html += '<div class="mt8">' + sayBtn(item.word, 'word') + '</div>';
        html += '<p class="small muted mt8">提示默认关闭；实在听不出可点下面的按钮。</p>';
        html += '<div class="mt8"><button type="button" class="btn ghost sm" data-act="typehint" aria-expanded="' + (S.hintUsed ? 'true' : 'false') + '">' + (S.hintUsed ? '已给出首字母和长度' : '给一点提示') + '</button>';
        if (S.hintUsed) html += '<p class="muted small mt8" id="typeHint">首字母 ' + esc(String(item.word).charAt(0)) + '，共 ' + String(item.word).length + ' 个字母</p>';
        html += '</div>';
        html += typeInputHtml(item, '听到什么就写什么');
      } else {
        html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
        if (item.pos) html += '<p class="small muted mt8">词性 ' + esc(item.pos) + '</p>';
        html += '<div class="mt8"><button type="button" class="btn ghost sm" data-act="typehint" aria-expanded="' + (S.hintUsed ? 'true' : 'false') + '">' + (S.hintUsed ? '已给出首字母和长度' : '给一点提示') + '</button>';
        if (S.hintUsed) html += '<p class="muted small mt8" id="typeHint">首字母 ' + esc(String(item.word).charAt(0)) + '，共 ' + String(item.word).length + ' 个字母</p>';
        html += '</div>';
        html += typeInputHtml(item, '写出对应的英文单词');
      }
      if (S.mode !== 'selftest') html += '<div class="row mt8"><button class="btn block" data-act="typesubmit"' + (S.busy ? ' disabled' : '') + '>提交</button></div>';
      html += '</div>';
    } else if (S.phase === 'type_fb') {
      var tok = S.typeOk;
      html += '<div class="card tight">';
      html += '<h3>' + (tok ? modeName(S.mode) + '正确' : modeName(S.mode) + '有误') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += sayBtn(item.word, 'feedback');
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (S.mode === 'selftest') {
        html += '<div class="note mt12">' + (tok ? '自评认识：复习间隔会拉长。' : (S.selfFuzzy ? '自评「有点印象」：这个词会更快再出现一次。' : '自评不认识：按未掌握重新安排复习。')) + '</div>';
      } else if (!tok) html += '<div class="note mt12">你写的是「' + esc(S.typed || '（空）') + '」。这个词会按未掌握重新安排复习。</div>';
      if (tok && S.hintUsed) html += '<div class="note mt12">这次用了提示，按「提示后答对」记录，复习间隔会比独立答对短一些。</div>';
      if (tok && !S.hintUsed) html += '<div class="note mt12">独立写对了，复习间隔会拉长。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="save">完成这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'quiz' || S.phase === 'retry') {
      html += '<div class="card tight"><h3>' + (S.phase === 'retry' ? '当轮复现：再选一次' : '选出正确的中文意思') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += sayBtn(item.word, 'quiz');
      html += optionsHtml(item, null, false);
      html += '</div>';
      html += wordExSmall(item);
    } else if (S.phase === 'quiz_fb') {
      var ok = S.pickedMeaningOk;
      html += '<div class="card tight">';
      html += '<h3>' + (ok ? '答对了' : '答错了') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += sayBtn(item.word, 'feedback');
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (!ok) html += '<div class="note mt12">这个词会在本轮再练一次；最终复习安排只按这次（第一次）的作答计算。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="tospell">继续：拼写这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'spell') {
      html += '<div class="card tight"><h3>拼写这个词</h3>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      html += '<div class="mt8"><button type="button" class="btn ghost sm" data-act="spellhint" aria-expanded="false" aria-controls="spellHint">查看提示</button><p class="muted small mt8" id="spellHint" aria-live="polite" hidden></p></div>';
      html += '<div class="field mt8"><input id="spellInput" aria-label="输入英文单词" type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="在这里输入英文单词"></div>';
      html += '<div class="row"><button class="btn block" data-act="spell"' + (S.busy ? ' disabled' : '') + '>提交拼写</button></div>';
      html += '</div>';
    } else if (S.phase === 'spell_fb') {
      var sok = S.spellOk;
      html += '<div class="card tight">';
      html += '<h3>' + (sok ? '拼写正确' : '拼写有误') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (!sok) html += '<div class="note mt12">你输入的是「' + esc(S.spellInput || '（空）') + '」。拼写不计入复习安排，但仍会记入学习记录。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="save">完成这个词</button></div>';
      if (!sok) html += '<p class="small muted mt8">这个词已排进延迟重测：隔几道题后会再测一次。</p>';
      html += '</div>';
    } else if (S.phase === 'retry_fb') {
      html += '<div class="card tight">';
      html += '<h3>' + (S.retryOk ? '复现答对了' : '复现又答错了') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      html += '<div class="note mt12">本轮复现只用于巩固，不会改变按第一次作答计算的复习间隔。这个词明天会再次出现。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="save">完成这个词</button></div>';
      html += '</div>';
    } else if (S.phase === 'retest') {
      var rt = S.retestItem || item;
      html += '<div class="card tight"><h3>错词再测</h3>';
      html += '<p class="small muted">这是刚才答错的词，隔了几道题再测一次。只用于巩固，不影响复习安排。</p>';
      html += '<div class="word-cn">' + esc(rt.meaning || '') + '</div>';
      if (rt.pos) html += '<p class="small muted mt8">词性 ' + esc(rt.pos) + '</p>';
      html += '<div class="field mt8"><input id="retestInput" aria-label="输入英文单词" type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done" placeholder="写出对应的英文单词"></div>';
      html += '<div class="row mt8"><button class="btn block" data-act="retestsubmit"' + (S.busy ? ' disabled' : '') + '>提交</button></div>';
      html += '</div>';
    } else if (S.phase === 'retest_fb') {
      var rti = S.retestItem || item;
      html += '<div class="card tight"><h3>' + (S.retestOk ? '再测答对了' : '再测又答错了') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(rti.word) + '</div>';
      html += '<div class="word-ipa">' + esc(rti.ipa || '') + '</div>';
      html += '<div class="word-cn">' + esc(rti.meaning || '') + '</div>';
      if (!S.retestOk) html += '<div class="note mt12">你写的是「' + esc(S.retestTyped || '（空）') + '」。' + (S.retestTries >= RETRY_MAX ? '这个词会按错词进入复习。' : '稍后还会再测一次。') + '</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="retestnext">继续</button></div>';
      html += '</div>';
    } else if (S.phase === 'gspell') {
      var gs = S.groupSpell;
      html += '<div class="card tight"><h3>集中默写 · 第 ' + (gs.pos + 1) + ' / ' + gs.order.length + ' 个</h3>';
      html += '<p class="small muted">这一组已经学完，现在统一打乱默写，中途不回到词卡。</p>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (item.pos) html += '<p class="small muted mt8">词性 ' + esc(item.pos) + '</p>';
      html += '<div class="field mt8"><input id="gspellInput" aria-label="输入英文单词" type="text" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done" placeholder="写出对应的英文单词"></div>';
      html += '<div class="row mt8"><button class="btn block" data-act="gspellsubmit">提交</button></div>';
      html += '</div>';
    } else if (S.phase === 'gspell_fb') {
      var gs2 = S.groupSpell;
      html += '<div class="card tight"><h3>' + (gs2.ok ? '默写正确' : '默写有误') + '</h3>';
      html += '<div class="word-en" style="font-size:26px">' + esc(item.word) + '</div>';
      html += '<div class="word-ipa">' + esc(item.ipa || '') + '</div>';
      html += '<div class="word-cn">' + esc(item.meaning || '') + '</div>';
      if (!gs2.ok) html += '<div class="note mt12">你写的是「' + esc(gs2.typed || '（空）') + '」。这个词会进入复习错词。</div>';
      html += '<div class="row mt16"><button class="btn block" data-act="gspellnext">' + (gs2.pos + 1 < gs2.order.length ? '下一个' : '看这一组结果') + '</button></div>';
      html += '</div>';
    } else if (S.phase === 'saving') {
      html += '<div class="card center"><p class="muted">正在保存作答…</p></div>';
    } else if (S.phase === 'item_done') {
      var st = S.lastSave || {};
      var map = {
        sent: '已保存到云端',
        queued: '已在本机排队，联网后自动补交',
        dead: '这条记录被服务端拒绝，不会再重试',
        rejected: '这个条目之前已按另一个答案提交，本次没有覆盖'
      };
      html += '<div class="card tight">';
      html += '<h3>' + (st.status === 'sent' ? '本词记录已提交' : '本词处理结果') + '</h3>';
      html += wordCard(item, true);
      html += '<div class="note mt12">' + esc(map[st.status] || st.message || '已记录') + '</div>';
      if (st.status === 'queued') html += '<p class="small muted mt8">本机还有 ' + S.pending + ' 条待补交记录，回到列表页可点「补交本机记录」。</p>';
      html += '<div class="row mt16"><button class="btn block" data-act="next">' + (S.idx + 1 < S.queue.length ? '下一个词' : '查看今日结果') + '</button></div>';
      html += '</div>';
    }
    var feedback = S.phase === 'type_fb' ? (S.typeOk ? 'correct' : 'incorrect') :
      S.phase === 'quiz_fb' ? (S.pickedMeaningOk ? 'correct' : 'incorrect') :
      S.phase === 'spell_fb' ? (S.spellOk ? 'correct' : 'incorrect') :
      S.phase === 'retry_fb' ? (S.retryOk ? 'correct' : 'incorrect') : '';
    // 音效只在这里触发一次：同一 idx+phase 重渲染不重复；答错温柔提示，连对递进。
    if (feedback) {
      var sk = S.idx + '|' + S.phase + '|' + feedback;
      if (sk !== S.soundKey) {
        S.soundKey = sk;
        if (feedback === 'correct') S.combo += 1; else S.combo = 0;
        cmp(feedback === 'correct' ? 'answer_correct' : 'answer_wrong', { combo: S.combo, mode: S.MODE });
        try {
          if (window.Sound) {
            if (S.rememberOnce && S.combo < 3) window.Sound.play('remember', { haptic: true });
            else window.Sound.answer(feedback === 'correct', S.combo);
          }
        } catch (e) { }
        S.rememberOnce = false;
      }
    } else {
      S.soundKey = '';
    }
    renderShell(html, 'study', S.phase, feedback);
    if (S.phase === 'spell') {
      var inp = $('spellInput');
      if (inp) {
        inp.value = '';
        setTimeout(function () { try { inp.focus(); } catch (e) { /* iOS 需用户手势，忽略 */ } }, 30);
      }
    }
    if (S.phase === 'type') {
      var tin = $('typeInput');
      if (tin) {
        tin.value = S.typed || '';
        tin.addEventListener('input', onTypeInput);
        tin.addEventListener('keydown', function (ev) {
          if (ev.key === 'Enter') { ev.preventDefault(); ACT.typesubmit(); }
        });
        setTimeout(function () { try { tin.focus({ preventScroll: true }); } catch (e) { /* iOS 需用户手势 */ } }, 30);
      }
    }
  }

  function wordExSmall(item) {
    if (!item.example_en) return '';
    var html = '<div class="card tight"><p class="small muted">例句（只给英文，答题时参考）</p>';
    html += '<p class="small"><b>' + esc(item.example_en) + '</b></p>' + sayBtn(item.example_en, 'example');
    html += '</div>';
    return html;
  }

  function firstLetterHint(word) {
    var w = String(word || '');
    if (w.length <= 2) return w.charAt(0) + '…';
    return w.charAt(0) + new Array(Math.max(1, w.length - 2)).join('_') + w.charAt(w.length - 1);
  }

  // ---------- 渲染：完成 ----------
  function renderGroupDone() {
    var gs = S.groupSpell || { right: 0, wrong: [], order: [] };
    var view = $('view');
    if (!view) return;
    var p = progress();
    var html = '<div class="card center"><h2>这一组默写完成</h2>';
    html += '<p class="muted">这一组 ' + gs.order.length + ' 个词，默写正确 ' + gs.right + ' 个，写错 ' + gs.wrong.length + ' 个。本轮总进度 ' + p.done + ' / ' + Math.max(p.total, 1) + '。</p>';
    if (gs.wrong.length) {
      html += '<div class="note mt12">写错的词已交给复习系统：' + gs.wrong.map(function (w) { return esc(w); }).join('、') + '</div>';
    }
    html += '<div class="row mt16"><button class="btn block" data-act="groupnext">下一组</button></div>';
    html += '</div>';
    view.innerHTML = html + '<section id="lumi-home-difficulty"></section>';
  }

  function renderDone() {
    soundOnceInit();
    var p = progress();
    var html = '<div class="card center">';
    var label = MODE === 'review' ? '复习' : '新词学习';
    var heading = !p.total ? (MODE === 'review' ? '暂无到期单词' : '暂无待学新词') :
      p.skipped === p.total ? '本轮' + label + '已跳过' : p.skipped ? '本轮' + label + '结束' :
      p.done === p.total ? '今日' + label + '已完成' : '本轮' + label + '结果';
    html += '<h2>' + heading + '</h2>';
    html += '<p class="muted">本轮共 ' + p.total + ' 个词，已完成 ' + p.done + ' 个，已跳过 ' + p.skipped + ' 个。当前学习用时 ' + fmt(S.elapsed) + '。</p>';
    if (MODE === 'today') {
      html += '<div class="row mt16"><a class="btn block" href="lesson.html">继续其他课程（语法·听力·阅读·口语）</a></div>';
      html += '<div class="row mt8"><a class="btn ghost block" href="review.html">去到期复习</a></div>';
    } else {
      html += '<div class="row mt16"><a class="btn block" href="today.html">去今日新词</a></div>';
      html += '<div class="row mt8"><a class="btn ghost block" href="lesson.html">学习其他课程（语法·听力·阅读·口语）</a></div>';
    }
    html += '<div class="row mt8"><button class="btn ghost block" data-act="home">回到任务列表</button></div>';
    html += '</div>';
    html += '<section id="lumi-done-difficulty" class="card" hidden></section>';
    if (S.offlineStudy) {
      html += '<div class="note mt12">这次是离线学习：记录已存在本机，回到联网状态后会自动补交。</div>';
    }
    if (S.pending > 0) {
      html += '<div class="note mt12">本机还有 ' + S.pending + ' 条记录没有提交成功。联网后会自动补交，也可以手动重试。</div>';
      html += '<div class="row mt8"><button class="btn ghost sm" data-act="flush">立即补交</button></div>';
    }
    renderShell(html, 'done');
    try {
      if (window.Sound && !S.soundOnce.done) {
        S.soundOnce.done = true;
        // 一组真实学习完成（复习模式同样算一次完整收尾）。
        window.Sound.complete();
        // 每日新词目标：只有「今日」模式、且本次会话确实完成到目标数才触发，
        // 由 Sound.goalOnce 保证同一天只响一次，避免刷新/重复渲染重播。
        var g = null;
        try { g = window.LumiGoals ? window.LumiGoals.get() : null; } catch (e) { g = null; }
        if (S.MODE === 'today' && g && g.newWords > 0 && S.done >= g.newWords) {
          window.Sound.goal();
          cmp('daily_goal_reached', { target: g.newWords, done: S.done });
        }
      }
    } catch (e) { }
    reportDifficulty();
  }

  // ---------- 难度反馈（Codex 九级难度：words 模块由本页在会话结束时上报一次） ----------
  function reportDifficulty() {
    var D = window.Difficulty;
    var st = S.zStats;
    if (!D || !D.report || !st || !st.independent) return;
    if (!S.zUnit) {
      var day = (S.task && S.task.study_date) || todayStr();
      S.zUnit = 'words:' + day + ':' + String(S.allItems.length) + ':' + String(Date.now());
    }
    try {
      Promise.resolve(D.read()).then(function (res) {
        var lv = res && res.words ? res.words : null;
        if (!lv) return;
        var mount = document.getElementById('lumi-done-difficulty') || document.getElementById('lumi-home-difficulty');
        if (mount) { mount.hidden = false; }
        return D.report({ module: 'words', level: lv, unitKey: S.zUnit, stats: st, mount: mount || undefined });
      }).catch(function () { /* 反馈失败不影响学习 */ });
    } catch (e) { /* ignore */ }
  }

  // ---------- 数据流程 ----------
  function refreshPending() {
    return window.Learn.pendingCount().then(function (n) {
      S.pending = n || 0;
      var el = $('pendingCount');
      if (el) el.textContent = S.pending + ' 条';
      return S.pending;
    }).catch(function () { return S.pending; });
  }

  function applyTask(task, opt) {
    opt = opt || {};
    S.task = task || {};
    var items = S.task.items || [];
    S.allItems = items.filter(function (it) { return it.task_type === (MODE === 'review' ? 'review' : 'new'); });
    S.queue = S.allItems.filter(function (it) { return it.status === 'pending'; });
    S.doneInitial = S.allItems.filter(function (it) { return it.status === 'completed'; }).length;
    S.skippedInit = S.allItems.filter(function (it) { return it.status === 'skipped'; }).length;
    S.offlineView = opt.offline === true;
    S.cachePreview = opt.preview === true;
    S.cacheDate = opt.cacheDate || '';
    S.idx = 0; S.done = 0; S.skipped = 0; S.phase = 'card'; S.lastSave = null; S.firstResult = null;
    S.combo = 0; S.soundKey = ''; S.rememberOnce = false;
    S.zUnit = ''; S.zStats = { independent: 0, correct: 0, hints: 0, repeated: 0 };
    S.offlineStudy = false;
    if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
    S.status = S.queue.length > 0 ? 'home' : 'done';
    if (S.status === 'done' && MODE !== 'today') { renderDone(); } else { renderHome(); }
    refreshPending();
  }

  // 断网/连不上服务器时：读本机快照渲染，不再只给「加载失败」
  function loadCachedTask(uid, tip) {
    var got = (window.OfflineCache && uid) ? window.OfflineCache.getTask(uid) : null;
    if (!got || !got.task) return false;
    applyTask(got.task, { offline: true, cacheDate: got.date });
    toast(tip || '没有网络：显示上次同步的内容，记录会先存在本机', 3200);
    return true;
  }

  // list_wordbooks 返回所有公共词书；mine_status 才代表个人加入状态。
  // 不允许初始化失败后继续调用会从全库抽词的旧 RPC 路径。
  function enrollmentError(message) {
    var err = new Error(message);
    err.code = 'wordbook_required';
    return err;
  }

  function readEnrollment() {
    return window.DB.rpc('list_wordbooks', {}).then(function (res) {
      if (!res || res.ok !== true || !Array.isArray(res.wordbooks) || !res.wordbooks.length) {
        throw enrollmentError('无法确认词书状态，请重试或前往词书中心。');
      }
      // 旧种子词书（code=seed）在词书中心里对新用户隐藏，但存量账号可能正用它。
      // 迁移 027 未执行前，直接把它判为“正在更新”会让老账号一进首页就加载失败，
      // 所以这里只把未加入的 seed 排除，已加入/暂停的 seed 仍按普通词书处理。
      var list = res.wordbooks.filter(function (b) {
        return !b || b.code !== 'seed' || b.mine_status === 'active' || b.mine_status === 'paused';
      });
      if (list.some(function (b) {
        return !b || typeof b.id !== 'string' || !b.id || typeof b.code !== 'string' ||
          typeof b.is_current !== 'boolean' ||
          (b.mine_status !== null && b.mine_status !== 'active' && b.mine_status !== 'paused');
      })) throw enrollmentError('词书状态异常，请重试或前往词书中心。');
      var current = list.filter(function (b) { return b.is_current; });
      if (current.length > 1 || (current.length && current[0].mine_status !== 'active')) {
        throw enrollmentError('当前词书状态异常，请前往词书中心重新选择。');
      }
      return { list: list, current: current[0] || null,
        joined: list.filter(function (b) { return b.mine_status !== null; }),
        active: list.filter(function (b) { return b.mine_status === 'active'; }) };
    });
  }

  function ensureEnrollment() {
    if (!window.DB || typeof window.DB.rpc !== 'function') {
      return Promise.reject(enrollmentError('词书服务未就绪，请重试。'));
    }
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return Promise.reject(new Error('当前离线，无法确认词书状态'));
    }
    return readEnrollment().then(function (state) {
      if (state.current) return state.current; // 保留用户已选的真实词书，不改变学习模式
      var rpcName, target;
      if (!state.joined.length) {
        target = state.list.find(function (b) { return b.code === 'daily'; });
        if (!target) throw enrollmentError('找不到日常高频词书，请前往词书中心。');
        rpcName = 'add_wordbook'; // 首次加入会自动设为当前；不会主动覆盖已存在的 current
      } else if (state.active.length === 1) {
        target = state.active[0];
        rpcName = 'set_current_wordbook';
      } else {
        throw enrollmentError('请前往词书中心选择一本当前词书，再继续学习。');
      }
      return window.DB.rpc(rpcName, { p_book_id: target.id }).then(function (res) {
        if (!res || res.ok !== true) throw enrollmentError('词书设置未成功，请重试或前往词书中心。');
        // 不能只相信写 RPC 返回 ok；再次确认存在有效 current 才能生成任务。
        return readEnrollment().then(function (after) {
          if (!after.current) throw enrollmentError('当前词书尚未生效，请重试或前往词书中心。');
          return after.current;
        });
      });
    });
  }

  // 词书确认结果只用来“跳过重复确认”，真实当前词书仍以服务端任务为准。
  // 若缓存判断失效，loadTask 会自动重新走 ensureEnrollment 一次，不会把用户锁死。
  var ENROLL_PREFIX = 'lumi.enroll.v1.';
  function enrollKey(uid) { return ENROLL_PREFIX + String(uid || ''); }
  function readEnroll(uid) {
    if (!uid) return null;
    try {
      var raw = window.localStorage.getItem(enrollKey(uid));
      var o = raw ? JSON.parse(raw) : null;
      if (!o || !o.at || Date.now() - Number(o.at) > 7 * 864e5) return null;
      return o;
    } catch (e) { return null; }
  }
  function writeEnroll(uid, book) {
    if (!uid || !book) return;
    try {
      window.localStorage.setItem(enrollKey(uid), JSON.stringify({
        at: Date.now(), bookId: book.id || '', code: book.code || ''
      }));
    } catch (e) { /* 忽略 */ }
  }

  var taskLoadInFlight = null;
  function fetchTaskResilient(uid, trustEnroll) {
    var trusted = !!trustEnroll;
    function run() {
      var prep = trusted ? Promise.resolve() : ensureEnrollment().then(function (book) {
        writeEnroll(uid, book);
      });
      return prep.then(function () { return window.Learn.loadTask(); }).catch(function (e) {
        // 缓存只省一次 list_wordbooks；若服务端说词书状态不对，立刻回到真实确认。
        if (trusted) { trusted = false; return run(); }
        throw e;
      });
    }
    return run();
  }

  // 返回用户：同日本地快照先上屏，再后台拉最新任务；第一次进入才显示骨架。
  function startHome() {
    var uid = S.user && S.user.id;
    // 真离线：走原有的“离线查看”说明，不假装正在同步。
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      if (loadCachedTask(uid, '现在没有网络：显示上次同步的内容')) return;
    }
    var got = (window.OfflineCache && uid) ? window.OfflineCache.getTask(uid) : null;
    if (got && got.task && !got.stale) {
      applyTask(got.task, { cacheDate: got.date, preview: true });
      loadTask({ preview: true });
      return;
    }
    loadTask({});
  }

  function loadTask(opt) {
    opt = opt || {};
    if (taskLoadInFlight) return taskLoadInFlight;
    var preview = opt.preview === true;
    S.syncError = false;
    setAuto(false);   // 首页/加载/失败/完成都不是真实学习状态
    if (!preview) {
      S.status = 'loading';
      renderLoading();
    }
    var uid = null;
    taskLoadInFlight = Promise.resolve().then(function () { return window.Learn.ready(); }).then(function (who) {
      if (!who || !who.user_id) throw new Error('没有登录会话');
      uid = who.user_id;
      S.user = S.user || { id: uid };
      return fetchTaskResilient(uid, !!readEnroll(uid));
    }).then(function (res) {
      if (!res || res.ok !== true) {
        var msg = (res && (res.message || res.code)) || '任务创建失败';
        throw new Error(msg);
      }
      if (window.OfflineCache && uid) window.OfflineCache.putTask(uid, res.task || {});
      // 用户可能在 30ms 的预览里已经点进学习：后台水合不得把学习页顶掉。
      if (preview && (S.status === 'study' || S.status === 'done' || S.starting)) {
        S.cachePreview = false;
        return;
      }
      applyTask(res.task || {}, {});
      loadLevels();
    }).catch(function (e) {
      var off = (typeof navigator !== 'undefined' && navigator.onLine === false);
      // 预览快照已可学：同步失败不白屏，也不把旧内容说成刚同步成功。
      if (preview && S.task && S.allItems) {
        S.cachePreview = false;
        S.syncError = true;
        renderHome();
        toast(off ? '现在没有网络：先看上次同步的内容' : '暂时连不上：先看上次同步的内容', 3000);
        return;
      }
      function fallback(u) {
        var bookError = e && e.code === 'wordbook_required';
        var tip = bookError ? '词书未就绪：显示已同步任务，请前往词书中心' :
          (off ? '现在没有网络：显示上次同步的内容' : '连不上服务器：显示上次同步的内容');
        if (loadCachedTask(u, tip)) return;
        S.status = 'error';
        S.error = (e && e.message) || '加载失败';
        S.offline = off;
        if (off) S.error = '连不上服务器（已离线），本机还没有缓存过今天的内容';
        else if (/登录|auth|jwt|session/i.test(S.error)) S.error += '（点「重新登录」可重新进入）';
        renderError();
      }
      if (uid) { fallback(uid); return; }
      Promise.resolve(window.DB && window.DB.auth ? window.DB.auth.getUserId() : null)
        .then(function (u) { fallback(u); })
        .catch(function () { fallback(null); });
    }).finally(function () { taskLoadInFlight = null; });
    return taskLoadInFlight;
  }

  // 无网络时继续学：会话服务连不上，就用本机队列记录（attempt/final 都以 session_id=null 提交，
  // 服务端 log_study_event 允许 session_id 为空，联网补交时照样入库）
  function startOfflineStudy() {
    setAuto(false);   // 离线没有在线会话，回前台只补交队列，不反复尝试建会话
    S.offlineStudy = true;
    S.offlineView = false;
    S.status = 'study';
    S.phase = 'card';
    S.itemStart = Date.now();
    S.elapsed = 0;
    if (restoreSnapshot()) toast(S.restoredOld ? '已恢复上次的学习进度（较早的记录）' : '已恢复上次的学习进度', 2200);
    var deferred = applyDeferred();
    if (deferred) toast('上次没收尾的 ' + deferred + ' 个错词会在这轮重测', 2600);
    if (S.localTimer) clearInterval(S.localTimer);
    S.localTimer = setInterval(function () {
      if (S.status !== 'study') return;
      S.elapsed += 1;
      var el = $('timer');
      if (el) el.textContent = fmt(S.elapsed);
    }, 1000);
    renderStudy();
    toast('离线学习：记录先存在本机，联网后自动补交', 3200);
  }

  function startSession() {
    if (S.busy) return;
    S.busy = true;
    S.starting = true;
    setAuto(true);    // 用户点了「开始学习」：此刻起回前台允许恢复/重建会话
    window.Learn.Session.start().then(function (res) {
      S.busy = false;
      S.starting = false;
      if (!res) {
        setAuto(false);
        if (typeof navigator !== 'undefined' && navigator.onLine === false) { startOfflineStudy(); return; }
        toast('学习会话创建失败，请检查网络后重试'); renderHome(); return;
      }
      S.offlineStudy = false;
      if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
      S.status = 'study';
      S.phase = 'card';
      S.itemStart = Date.now();
      S.elapsed = 0;
      S.typed = '';
      S.hintUsed = false;
      if (restoreSnapshot()) toast(S.restoredOld ? '已恢复上次的学习进度（较早的记录）' : '已恢复上次的学习进度', 2200);
    var deferred = applyDeferred();
    if (deferred) toast('上次没收尾的 ' + deferred + ' 个错词会在这轮重测', 2600);
      loadMode().then(renderStudy, renderStudy);
    }).catch(function (e) {
      S.busy = false;
      S.starting = false;
      setAuto(false);
      toast('启动学习失败：' + ((e && e.message) || e), 5000);
    });
  }

  function attempt(item, result, no) {
    if (result === 'correct' && no === 1 && !S.hintUsed) {
      try { sessionStorage.setItem('lumi-avatar-correct', String(Date.now())); } catch (e) {}
    }
    var dur = Math.round((Date.now() - (S.attemptStart || Date.now())) / 1000);
    S.attemptStart = Date.now();
    if (S.zStats) {
      if (no === 1) { S.zStats.independent += 1; if (result === 'correct') S.zStats.correct += 1; if (S.hintUsed) S.zStats.hints += 1; }
      else S.zStats.repeated += 1;
    }
    var phase = S.phase || '';
    var phaseMode = (phase === 'gspell' || phase === 'gspell_fb') ? 'gspell'
      : ((phase === 'retest' || phase === 'retest_fb') ? 'retest'
      : (S.mode === 'read' ? 'read' : S.mode));
    return window.Learn.submitAttempt(item.word_id, item.item_id, item.task_type, result, dur, no,
      { mode: phaseMode, hint: !!S.hintUsed })
      .catch(function (e) {
        toast('作答记录没提交成功：' + ((e && e.message) || '网络问题'));
        return null;
      });
  }

  // 写错了就记一笔（错词本）：只写数据库，不走 AI，失败也不打扰学习
  function noteMiss(item, mode, typed) {
    if (!item || !item.word_id || !window.DB || typeof window.DB.rpc !== 'function') return;
    try {
      window.DB.rpc('record_word_miss', {
        p_word_id: item.word_id,
        p_typed: String(typed == null ? '' : typed).slice(0, 60),
        p_mode: String(mode || '').slice(0, 20)
      }).catch(function () { /* 记不上不影响本轮学习 */ });
    } catch (e) { /* 忽略 */ }
    if (DETAIL_CACHE[item.word_id]) { DETAIL_CACHE[item.word_id].misses = (DETAIL_CACHE[item.word_id].misses || 0) + 1; }
  }

  // 拼写结果变成拼写类知识点的证据（本地判断，不调 AI）：
  // 写错记负向；独立写对（没用提示、不是跟写）记正向，这样拼写点也能正常达成掌握。
  function spellEvidence(item, typed, hint, assisted) {
    if (!item || !item.word || !window.DB || typeof window.DB.rpc !== 'function') return;
    var want = normSpell(item.word);
    var got = normSpell(typed);
    if (!want) return;
    var ok = got === want;
    var independent = ok && !hint && !assisted;
    if (!ok && !got) return;
    if (ok && !independent) return;           // 提示后写对 / 跟写照抄：不算掌握证据
    try {
      window.DB.rpc('kp_spell', {
        p_word: item.word, p_typed: ok ? String(item.word) : String(typed || ''),
        p_assisted: ok ? false : !!assisted,
        p_event: item.word + '|' + (S.sessionId || '')
      }).catch(function () {});
    } catch (e) { /* 忽略 */ }
  }

  function cachePatch(itemId, status, result) {
    try {
      if (window.OfflineCache && S.user && S.user.id) {
        window.OfflineCache.patchTaskItem(S.user.id, itemId, status, result || null);
      }
    } catch (e) { /* 缓存写失败不影响学习 */ }
  }

  function saveFinal() {
    var item = currentItem();
    if (!item) return;
    S.phase = 'saving';
    renderStudy();
    window.Learn.submitFinal(item.item_id, S.firstResult === 'correct' ? 'correct' : 'incorrect').then(function (res) {
      S.lastSave = res || { status: 'queued', message: '未知状态' };
      S.done += 1;
      S.phase = 'item_done';
      cachePatch(item.item_id, 'completed', S.firstResult === 'correct' ? 'correct' : 'incorrect');
      refreshPending().then(renderStudy);
      if (S.lastSave.status === 'queued') toast('已排在本机，联网后自动补交');
      if (S.lastSave.status === 'dead') toast('服务端拒绝了这条记录，已停止重试');
    }).catch(function (e) {
      S.lastSave = { status: 'queued', message: (e && e.message) || '提交失败，已保留在本机' };
      S.done += 1;
      S.phase = 'item_done';
      refreshPending().then(renderStudy);
      toast('提交失败，已保留在本机，稍后补交');
    });
  }

  // ---------- 交互动作 ----------
  // 朗读：必须在 click 事件里同步调用（iPhone Safari 不允许延迟播放）
  function speakWord(word, btn, lang, rate) {
    if (!window.Speech || typeof window.Speech.say !== 'function') return;
    if (!window.Speech.supported()) {
      toast('这个浏览器不支持朗读，换用 Safari 或新版 Edge 试试');
      return;
    }
    // 显式点按：一定朗读（force），并先 cancel 上一段，保证不叠音
    var ok = window.Speech.say(word, { lang: lang || 'en-US', rate: rate || 0, force: true });
    if (!ok) {
      toast('这个浏览器暂时读不出，可以换 Safari 或新版 Edge');
      return;
    }
    if (!btn) return;
    var txt = btn.querySelector ? btn.querySelector('.say-txt') : null;
    if (!txt) return;
    var old = txt.textContent;
    txt.textContent = '朗读中…';
    // 不禁用按钮：再点一次就是「重播」（内部会先 cancel 上一个，不会叠音）
    setTimeout(function () { txt.textContent = old; }, 1200);
  }

  var ACT = {
    adapt: function (el) {
      var i = Number(el.getAttribute('data-i') || 0);
      var item = ADAPT && ADAPT.items && ADAPT.items[i];
      if (!item) return;
      if (item.action === 'study') { if (window.LumiPlan) window.LumiPlan.markStart(); ACT.start(); }
    },
    adaptgo: function () { if (window.LumiPlan) window.LumiPlan.markStart(); },
    adaptRefresh: function () { ADAPT = null; hydrateAdaptive(true); },
    adaptLevel: function (el) { adaptLevel(el.getAttribute('data-mod'), Number(el.getAttribute('data-lv') || 0)); },
    planStart: function () {
      if (window.LumiPlan) window.LumiPlan.markStart();
      ACT.start();
    },
    planSkip: function () {
      if (window.LumiPlan) window.LumiPlan.skipToday();
      var n = document.getElementById('planCard');
      if (n) { n.hidden = true; n.innerHTML = ''; }
    },
    planGoal: function () {
      var cur = (window.LumiPlan && window.LumiPlan.goal && window.LumiPlan.goal()) || '';
      var v = window.prompt('你想在多久内达到什么？（例如：三个月把四级词汇过一遍 / 雅思 6.5）', cur);
      if (v == null) return;
      v = String(v).trim().slice(0, 40);
      if (v.length < 2) { toast('目标太短了，写两三个字以上'); return; }
      window.DB.rpc('set_study_prefs', { p_patch: { goal: v } }).then(function () {
        if (window.LumiPlan) { window.LumiPlan.clearContext(); }
        toast('目标已保存');
        hydratePlan();
      }).catch(function () { toast('保存失败了，稍后再试'); });
    },
    planRefresh: function () {
      var n = document.getElementById('planCard');
      if (n) n.innerHTML = '<div class="v2-plan-head"><div><b>接着学这些</b><span class="small muted">正在重新看你的记录…</span></div></div>';
      if (window.LumiPlan) window.LumiPlan.clearContext();
      hydratePlan();
    },
    wd: function (el) {
      var id = el.getAttribute('data-id');
      var box = id ? document.getElementById('wd-' + id) : null;
      if (!box) return;
      if (!box.classList.contains('hide')) {
        box.classList.add('hide');
        el.setAttribute('aria-expanded', 'false');
        return;
      }
      box.classList.remove('hide');
      el.setAttribute('aria-expanded', 'true');
      if (box.dataset && box.dataset.loaded) return;
      box.innerHTML = '<p class="small muted">正在读取…</p>';
      getDetail(id).then(function (d) {
        if (box.dataset) box.dataset.loaded = '1';
        box.innerHTML = wordDetailHtml(d, id);
      }).catch(function () {
        box.innerHTML = '<p class="small muted">详情暂时读不到，稍后再试。</p>';
      });
    },
    spellhint: function (el) {
      var item = currentItem(), hint = $('spellHint');
      if (S.phase !== 'spell' || !item || !hint) return;
      var reveal = el.getAttribute('aria-expanded') !== 'true';
      hint.textContent = reveal ? '提示：' + firstLetterHint(item.word) + '，共 ' + item.word.replace(/[^A-Za-z]/g, '').length + ' 个字母' : '';
      hint.hidden = !reveal;
      el.setAttribute('aria-expanded', String(reveal));
      el.textContent = reveal ? '收起提示' : '查看提示';
    },
    say: function (el) {
      var w = el.getAttribute('data-w') || '';
      var lang = el.getAttribute('data-lang') || 'en-US';
      var rate = parseFloat(el.getAttribute('data-rate') || '0') || 0;
      speakWord(w, el, lang, rate);
    },
    fav: function (el) {
      var id = el.getAttribute('data-id');
      if (!id || !window.DB) return;
      el.disabled = true;
      window.DB.rpc('toggle_word_favorite', { p_word_id: id }).then(function (r) {
        el.disabled = false;
        if (!r || r.ok === false) { toast('收藏没存上，稍后再试'); return; }
        if (DETAIL_CACHE[id]) DETAIL_CACHE[id].favorited = r.favorited;
        el.textContent = r.favorited ? '取消收藏' : '收藏这个词';
        toast(r.favorited ? '已加入收藏' : '已取消收藏');
      }).catch(function () {
        el.disabled = false;
        toast('收藏没存上，稍后再试');
      });
    },
    master: function (el) {
      var id = el.getAttribute('data-id');
      if (!id || !window.DB) return;
      var on = el.getAttribute('data-on') === '1';
      el.disabled = true;
      window.DB.rpc('set_word_mistake_mastered', { p_word_id: id, p_mastered: !on }).then(function (r) {
        el.disabled = false;
        if (!r || r.ok === false) { toast('没有保存成功，稍后再试'); return; }
        if (DETAIL_CACHE[id]) DETAIL_CACHE[id].mastered = !on;
        el.setAttribute('data-on', on ? '0' : '1');
        el.textContent = on ? '标为已掌握' : '移出错词本（重新学）';
        toast(on ? '已放回错词本，会重新练' : '已标记为掌握，不再进错词本');
        if (!on) { try { if (window.Sound) window.Sound.mastery(); } catch (e) { } }
      }).catch(function () {
        el.disabled = false;
        toast('没有保存成功，稍后再试');
      });
    },
    reload: function () { loadTask(); },
    logout: function () { window.AppAuth.logout(); },
    start: function () { startSession(); },
    home: function () { loadTask(); },
    flush: function () {
      window.Learn.flush().then(function (r) {
        var sent = (r && r.sent ? r.sent.length : 0);
        var dead = (r && r.dead ? r.dead.length : 0);
        toast(sent > 0 ? '补交成功 ' + sent + ' 条' : (dead > 0 ? '有 ' + dead + ' 条被服务端拒绝' : '没有可补交的记录'));
        return refreshPending();
      }).catch(function (e) { toast('补交失败：' + ((e && e.message) || '网络问题')); });
    },
    toquiz: function () {
      var item = currentItem(); if (!item || S.busy) return;
      // 答题前先听一遍（可在设置里关掉）。这里仍在点击事件内，iOS 允许播放。
      try {
        var sp = window.Speech && window.Speech.prefs ? window.Speech.prefs() : null;
        if (sp && sp.on && sp.auto) speakWord(item.word, null);
      } catch (e) {}
      S.options = buildOptions(item);
      S.picked = null;
      S.phase = 'quiz';
      S.attemptStart = Date.now();
      renderStudy();
    },
    pick: function (el) {
      var item = currentItem(); if (!item || S.busy) return;
      var i = parseInt(el.getAttribute('data-i'), 10);
      S.picked = i;
      var chosen = S.options[i];
      var ok = chosen === item.meaning;
      if (!ok) noteMiss(item, S.mode === 'read' ? 'choice' : S.mode, '');
      if (S.phase === 'quiz') {
        S.firstResult = ok ? 'correct' : 'incorrect';
        S.pickedMeaningOk = ok;
        attempt(item, ok ? 'correct' : 'incorrect', 1);
        if (!ok) scheduleRetry(item);
        S.phase = 'quiz_fb';
        fb(ok ? 'ok' : 'bad');
        renderStudy();
      } else if (S.phase === 'retry') {
        S.retryOk = ok;
        attempt(item, ok ? 'correct' : 'incorrect', 3);
        S.phase = 'retry_fb';
        fb(ok ? 'ok' : 'bad');
        renderStudy();
      }
    },
    mode: function (el) {
      if (S.busy) return;
      var m = el.getAttribute('data-mode');
      if (!MODES[m] || m === S.mode) return;
      S.busy = true;
      saveMode(m).then(function () {
        S.busy = false;
        try { if (window.Sound) window.Sound.play('switch'); } catch (e) { }
        renderStudy();
        toast('学习模式已切到「' + modeName(S.mode) + '」');
      });
    },
    selfrate: function (el) {
      if (S.busy) return;
      var r = el.getAttribute('data-r');
      var item = currentItem();
      if (!item) return;
      S.busy = true;
      var ok = r === 'known';
      S.rememberOnce = ok;
      S.typeOk = ok;
      S.selfFuzzy = r === 'fuzzy';
      S.typed = '';
      if (!ok && window.DB && r === 'unknown') noteMiss(item, 'selftest', '');
      attempt(item, ok ? 'correct' : 'incorrect', r === 'fuzzy' ? 2 : 1);
      S.busy = false;
      S.phase = 'type_fb';
      renderStudy();
    },
    totype: function () {
      if (S.busy) return;
      S.phase = 'type';
      S.typed = '';
      S.typeOk = null;
      S.hintUsed = false;
      S.attemptStart = Date.now();
      renderStudy();
    },
    typehint: function () {
      if (S.phase !== 'type' || S.hintUsed) return;
      S.hintUsed = true;
      renderStudy();
    },
    typesubmit: function () {
      var item = currentItem();
      if (!item || S.busy) return;
      var inp = $('typeInput');
      var val = inp ? inp.value : S.typed;
      S.typed = String(val || '');
      var ok = normSpell(S.typed) === normSpell(item.word);
      S.typeOk = ok;
      if (S.mode === 'dictate' || S.mode === 'recall' || S.mode === 'follow') spellEvidence(item, S.typed, S.hintUsed, S.mode === 'follow');
      if (!ok) noteMiss(item, S.mode, S.typed);
      // 提示后答对：按未掌握记录，避免"看一眼写出来"就拉长间隔
      var record = ok && !S.hintUsed ? 'correct' : 'incorrect';
      S.firstResult = record;
      attempt(item, record, 1);
      if (record === 'incorrect') scheduleRetry(item);
      S.phase = 'type_fb';
      renderStudy();
    },
    tospell: function () {
      S.phase = 'spell';
      S.attemptStart = Date.now();
      S.spellInput = '';
      renderStudy();
    },
    spell: function () {
      var item = currentItem(); if (!item || S.busy) return;
      var inp = $('spellInput');
      var val = inp ? inp.value : '';
      S.spellInput = val;
      var ok = normSpell(val) === normSpell(item.word);
      S.spellOk = ok;
      spellEvidence(item, val, S.hintUsed, false);
      if (!ok) noteMiss(item, 'spell', val);
      attempt(item, ok ? 'correct' : 'incorrect', 2);
      S.phase = 'spell_fb';
      renderStudy();
    },
    toretry: function () {
      var item = currentItem(); if (!item) return;
      S.options = buildOptions(item);
      S.picked = null;
      S.phase = 'retry';
      renderStudy();
    },
    retestsubmit: function () {
      if (S.busy || S.phase !== 'retest') return;
      var item = S.retestItem; if (!item) return;
      var inp = $('retestInput');
      S.retestTyped = inp ? inp.value : '';
      S.retestOk = normSpell(S.retestTyped) === normSpell(item.word);
      attempt(item, S.retestOk ? 'correct' : 'incorrect', 2);
      if (!S.retestOk) noteMiss(item, 'retest', S.retestTyped);
      S.phase = 'retest_fb';
      renderStudy();
    },
    retestnext: function () {
      var item = S.retestItem;
      if (item && !S.retestOk && S.retestTries < RETRY_MAX) {
        S.retry.push({ item: item, due: S.idx + 3, tries: S.retestTries + 1 });
      }
      S.retestItem = null; S.retestOk = null; S.retestTyped = '';
      S.phase = 'card';
      ACT.next();
    },
    gspellsubmit: function () {
      if (S.busy || S.phase !== 'gspell') return;
      var item = groupSpellItem(); var gs = S.groupSpell;
      if (!item || !gs) return;
      var inp = $('gspellInput');
      gs.typed = inp ? inp.value : '';
      gs.ok = normSpell(gs.typed) === normSpell(item.word);
      attempt(item, gs.ok ? 'correct' : 'incorrect', 2);
      if (!gs.ok) { noteMiss(item, 'gspell', gs.typed); gs.wrong.push(item.word); }
      else gs.right += 1;
      S.phase = 'gspell_fb';
      renderStudy();
    },
    gspellnext: function () {
      var gs = S.groupSpell; if (!gs) return;
      gs.pos += 1; gs.typed = ''; gs.ok = null;
      if (gs.pos < gs.order.length) { S.phase = 'gspell'; renderStudy(); return; }
      S.phase = 'group_done';
      renderGroupDone();
    },
    groupnext: function () {
      S.groupStart = groupEnd();
      S.groupSpell = null;
      if (S.groupStart >= S.queue.length) { ACT.finish(); return; }
      S.idx = S.groupStart;
      S.phase = 'card';
      S.firstResult = null; S.typed = ''; S.typeOk = null; S.hintUsed = false;
      S.itemStart = Date.now();
      var due = dueRetry(S.idx, false);
      if (due) { startRetest(due); return; }
      renderStudy();
    },
    finish: function () { finishSession(); },
    save: function () { saveFinal(); },
    next: function () {
      var due = dueRetry(S.idx + 1, false);
      if (due) { startRetest(due); return; }
      if (needsGroupSpell()) { startGroupSpell(); return; }
      if (S.idx + 1 < S.queue.length) {
        S.idx += 1;
        S.phase = 'card';
        S.picked = null;
        S.firstResult = null;
        S.lastSave = null;
        S.typed = '';
        S.typeOk = null;
        S.hintUsed = false;
        S.itemStart = Date.now();
        try { if (window.Sound) window.Sound.play('switch'); } catch (e) { }
        renderStudy();
        return;
      }
      deferRetries();
      finishSession();
    },
    skip: function () {
      var item = currentItem(); if (!item || S.busy) return;
      S.busy = true;
      window.Learn.skipItem(item.item_id).then(function (res) {
        S.busy = false;
        var st = res && res.status;
        if (st === 'sent' || st === 'queued') {
          S.skipped += 1;
          S.lastSave = { status: st, message: res.message };
          S.phase = 'item_done';
          cachePatch(item.item_id, 'skipped', null);
          renderStudy();
        } else {
          toast('跳过没提交成功：' + ((res && res.message) || '未知错误'));
          renderStudy();
        }
      }).catch(function (e) {
        S.busy = false;
        toast('跳过失败：' + ((e && e.message) || '网络问题'));
        renderStudy();
      });
    }
  };


  // ---------- 07-J 组内快照：退出/后台/被杀/刷新/重启后可恢复 ----------
  var SNAP_PREFIX = 'lumi.study.snap.v1.';
  function snapKey() {
    var uid = (S.user && S.user.id) || 'anon';
    return SNAP_PREFIX + uid + '.' + S.MODE;
  }
  function snapshotData() {
    return {
      v: 1, at: Date.now(), sessionId: S.sessionId || null,
      idx: S.idx, done: S.done, skipped: S.skipped, groupStart: S.groupStart,
      phase: S.phase,
      ids: S.queue.map(function (it) { return it.item_id; }).join(','),
      retry: S.retry.map(function (e) { return { id: e.item && e.item.item_id, due: e.due, tries: e.tries }; }),
      gspell: S.groupSpell ? {
        order: S.groupSpell.order.map(function (i) { return S.queue[i] && S.queue[i].item_id; }),
        pos: S.groupSpell.pos, right: S.groupSpell.right, wrong: S.groupSpell.wrong
      } : null
    };
  }
  var snapTimer = null;
  function saveSnapshot() {
    if (S.status !== 'study' || !S.queue || !S.queue.length) return;
    try { window.localStorage.setItem(snapKey(), JSON.stringify(snapshotData())); } catch (e) { /* 写不进快照不影响学习 */ }
  }
  function scheduleSnapshot() {
    if (S.status !== 'study') return;
    if (snapTimer) return;
    snapTimer = setTimeout(function () { snapTimer = null; saveSnapshot(); }, 120);
  }
  function clearSnapshot() {
    try { window.localStorage.removeItem(snapKey()); } catch (e) { /* 忽略 */ }
  }
  function restoreSnapshot() {
    var o = null;
    try { o = JSON.parse(window.localStorage.getItem(snapKey()) || 'null'); } catch (e) { o = null; }
    if (!o || o.v !== 1 || !S.queue || !S.queue.length) return false;
    var age = Date.now() - (o.at || 0);
    // 超过 72 小时才认定无用；12–72 小时之间仍恢复（进度不能静默丢掉），只提示「较旧」
    if (age > 72 * 3600 * 1000) { clearSnapshot(); return false; }
    var ids = S.queue.map(function (it) { return it.item_id; }).join(',');
    if (o.ids !== ids) { clearSnapshot(); return false; }
    S.restoredOld = age > 12 * 3600 * 1000;
    S.idx = Math.max(0, Math.min(o.idx || 0, S.queue.length - 1));
    S.done = o.done || 0;
    S.skipped = o.skipped || 0;
    S.groupStart = o.groupStart || 0;
    S.retry = [];
    (o.retry || []).forEach(function (r) {
      for (var i = 0; i < S.queue.length; i++) {
        if (S.queue[i].item_id === r.id) {
          S.queue[i].__retryQueued = true;
          S.retry.push({ item: S.queue[i], due: r.due || 0, tries: r.tries || 0 });
          return;
        }
      }
    });
    if (o.gspell && o.gspell.order && o.gspell.order.length) {
      var order = [];
      o.gspell.order.forEach(function (id) {
        for (var i = 0; i < S.queue.length; i++) { if (S.queue[i].item_id === id) { order.push(i); return; } }
      });
      S.groupSpell = order.length ? { order: order, pos: o.gspell.pos || 0, right: o.gspell.right || 0, wrong: o.gspell.wrong || 0 } : null;
    }
    S.phase = (o.phase === 'gspell' && S.groupSpell) ? 'gspell' : 'card';
    return true;
  }

  // ---------- 07 补充：本轮没轮到的错词，排到下一次会话，而不是当场再默写 ----------
  var DEFER_PREFIX = 'lumi.study.defer.v1.';
  function deferKey() {
    var uid = (S.user && S.user.id) || 'anon';
    return DEFER_PREFIX + uid + '.' + S.MODE;
  }
  function deferRetries() {
    if (!S.retry || !S.retry.length) return 0;
    var ids = [];
    try {
      var raw = JSON.parse(window.localStorage.getItem(deferKey()) || '[]');
      if (Object.prototype.toString.call(raw) === '[object Array]') ids = raw;
    } catch (e) { ids = []; }
    S.retry.forEach(function (e) {
      var id = e && e.item && e.item.item_id;
      if (id && ids.indexOf(id) < 0) ids.push(id);
    });
    try { window.localStorage.setItem(deferKey(), JSON.stringify(ids)); } catch (e) { /* 写不进不影响结束 */ }
    return ids.length;
  }
  function applyDeferred() {
    var ids = null;
    try { ids = JSON.parse(window.localStorage.getItem(deferKey()) || 'null'); } catch (e) { ids = null; }
    if (Object.prototype.toString.call(ids) !== '[object Array]' || !ids.length) return 0;
    var n = 0;
    ids.forEach(function (id) {
      for (var i = 0; i < S.queue.length; i++) {
        if (S.queue[i].item_id === id && !S.queue[i].__retryQueued) {
          S.queue[i].__retryQueued = true;
          S.retry.push({ item: S.queue[i], due: S.idx + 2, tries: 0 });
          n += 1;
          return;
        }
      }
    });
    try { window.localStorage.removeItem(deferKey()); } catch (e) { /* 忽略 */ }
    return n;
  }

  // STAGE 10：把判题结果的变化交给统一的反馈层（只做 transform/opacity，不阻塞判题）
  function fb(kind) {
    try {
      if (!window.LumiMotion || !window.LumiMotion.feedback) return;
      var box = document.querySelector('#view .card') || document.getElementById('view');
      if (box) window.LumiMotion.feedback(box, kind);
    } catch (e) { }
  }

  function soundOnceInit() { if (!S.soundOnce) S.soundOnce = {}; return S.soundOnce; }

  // Q 版角色接口：只发事件，不创建 DOM、不发网络请求，失败一律吞掉不影响学习。
  function cmp(event, detail) {
    try { if (window.LumiCompanion) window.LumiCompanion.emit(event, detail); } catch (e) { }
  }

  function finishSession() {
    cmp(S.MODE === 'review' ? 'review_completed' : 'group_completed', { done: S.done, mode: S.MODE });
    clearSnapshot();
    S.groupSpell = null;
    S.retry = [];
    setAuto(false);
    window.Learn.Session.end();
    if (S.localTimer) { clearInterval(S.localTimer); S.localTimer = null; }
    S.status = 'done';
    renderDone();
    fb('done');
    window.Learn.flush().then(refreshPending);
  }

  function bind() {
    view = $('view');
    function stopPronunciation() { if (window.Speech) window.Speech.stop(); }
    window.addEventListener('pagehide', function () { saveSnapshot(); stopPronunciation(); });
    document.addEventListener('visibilitychange', function () { if (document.hidden) stopPronunciation(); });
    window.addEventListener('error', function (ev) {
      toast('页面脚本错误：' + ((ev && ev.message) || '未知'), 6000);
    });
    window.addEventListener('unhandledrejection', function (ev) {
      var reason = ev && ev.reason;
      toast('异步错误：' + ((reason && (reason.message || reason.code)) || reason || '未知'), 6000);
    });
    if (!view) { return; }
    view.addEventListener('click', function (ev) {
      var el = ev.target;
      while (el && el !== view) {
        if (el.getAttribute && el.getAttribute('data-act')) break;
        el = el.parentNode;
      }
      if (!el || el === view) return;
      var act = el.getAttribute('data-act');
      var fn = ACT[act];
      if (fn) { ev.preventDefault(); fn(el); }
    });
    view.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' && S.phase === 'gspell' && ev.target === $('gspellInput')) {
        ev.preventDefault();
        ACT.gspellsubmit();
        return;
      }
      if (ev.key === 'Enter' && S.phase === 'retest' && ev.target === $('retestInput')) {
        ev.preventDefault();
        ACT.retestsubmit();
        return;
      }
      if (ev.key === 'Enter' && S.phase === 'spell' && ev.target === $('spellInput')) {
        ev.preventDefault();
        ACT.spell();
      }
    });
  }

  function boot() {
    cmp('page_enter', { mode: S.MODE, page: location.pathname.split('/').pop() });
    window.addEventListener('pagehide', function () { cmp('page_leave', { mode: S.MODE }); });
    document.addEventListener('visibilitychange', function () {
      cmp(document.hidden ? 'app_background' : 'app_foreground', { mode: S.MODE });
    });
    var body = document.body;
    MODE = (body && body.getAttribute('data-mode')) === 'review' ? 'review' : 'today';
    var t = document.getElementById('pageTitle');
    if (t) t.textContent = MODE === 'review' ? '到期复习' : '今日学习';
    var back = $('btnLogout');
    if (back) back.addEventListener('click', function () { window.AppAuth.logout(); });
    window.Learn.Session.onTick = function (sec) {
      S.elapsed = sec;
      S.lastTickSec = sec;
      var el = $('timer');
      if (el) el.textContent = fmt(sec);
    };
    window.Learn.Session.onState = function (state, detail) {
      S.lastState = state;
      // 回前台时 data 层会自动 start 会话；只有正在学习时才允许会话存在
      if ((state === 'started' || state === 'resumed') && S.status !== 'study' && !S.starting) {
        setAuto(false);
        window.Learn.Session.end();
        return;
      }
      if (state === 'session_expired') toast('学习会话已重建，记录会继续保存');
      if (state === 'auth') toast('登录已过期，请重新登录');
      if (state === 'error' && detail) toast('会话异常：' + detail);
    };
    window.Learn.Session.bindEvents();

    window.AppAuth.requireLogin().then(function (user) {
      if (!user) return;
      S.user = user;
      renderTopbar();
      startHome();
    });
  }

  document.addEventListener('DOMContentLoaded', function () { bind(); boot(); });

  return { boot: boot, state: S, groupHooks: { groupEnd: groupEnd, needsGroupSpell: needsGroupSpell, startGroupSpell: startGroupSpell, size: GROUP_SIZE }, retryHooks: { scheduleRetry: scheduleRetry, dueRetry: dueRetry, startRetest: startRetest, gap: RETRY_GAP, max: RETRY_MAX }, snapshotHooks: { save: saveSnapshot, restore: restoreSnapshot, clear: clearSnapshot, key: snapKey }, deferHooks: { defer: deferRetries, apply: applyDeferred, key: deferKey }, debug: { render: renderStudy, renderDone: renderDone, finish: finishSession } };
})();
