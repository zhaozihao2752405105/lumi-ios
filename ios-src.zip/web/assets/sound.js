/* ============================================================
 * Lumi Words · SoundManager (v52.97)
 * 纯 Web Audio 合成，不加载外部音频，不产生网络/AI 请求。
 * 声音设计：冰晶 + 轻玻璃 + 温暖木质泛音，短促、克制、上扬。
 * 三种风格：A 苹果玻璃 / B 冰晶未来 / C 温暖治愈（默认 A）。
 * 公开：Sound.play / answer / combo / complete / goal / connect /
 *       disconnect / setStyle / settingsHtml / bindSettings / wav / debug
 * ============================================================ */
(function (root) {
  'use strict';

  var KEY = 'lumi.sound.v1';
  var STYLE_KEY = 'lumi.sound.style.v1';
  var GOAL_KEY = 'lumi.sound.goal.';
  var STYLES = { A: '苹果玻璃', B: '冰晶未来', C: '温暖治愈' };

  var def = { enabled: true, feedback: true, tap: true, achieve: true, volume: 0.42, haptic: true };
  var prefs = readPrefs();
  var style = readStyle();
  var ac = null, master = null, comp = null, lp = null, delay = null, wet = null;
  var unlocked = false, active = 0, lastAt = {}, lastPlay = null;
  var buses = (typeof WeakMap === 'function') ? new WeakMap() : null;
  var noiseBuf = null;
  function busFor(ac2) {
    if (!buses) return { delay: delay };
    var b = buses.get(ac2);
    if (!b) { b = { delay: null, noise: null }; buses.set(ac2, b); }
    return b;
  }

  function readPrefs() {
    var out = {}, k;
    for (k in def) if (Object.prototype.hasOwnProperty.call(def, k)) out[k] = def[k];
    try {
      var raw = root.localStorage.getItem(KEY);
      if (raw) {
        var v = JSON.parse(raw) || {};
        for (k in out) if (typeof v[k] === typeof out[k]) out[k] = v[k];
      }
    } catch (e) { /* 忽略：坏数据回默认 */ }
    out.volume = Math.max(0, Math.min(1, Number(out.volume)));
    return out;
  }
  function savePrefs() {
    try { root.localStorage.setItem(KEY, JSON.stringify(prefs)); } catch (e) { /* 忽略 */ }
  }
  function readStyle() {
    try {
      var v = root.localStorage.getItem(STYLE_KEY);
      return STYLES[v] ? v : 'A';
    } catch (e) { return 'A'; }
  }
  function setVolume(v) {
    prefs.volume = Math.max(0, Math.min(1, Number(v) || 0));
    if (master) master.gain.value = prefs.volume * 0.55;
    savePrefs();
    return prefs.volume;
  }
  function saveStyle(s) {
    style = STYLES[s] ? s : 'A';
    try { root.localStorage.setItem(STYLE_KEY, style); } catch (e) { /* 忽略 */ }
  }

  function supported() {
    return !!(root.AudioContext || root.webkitAudioContext);
  }
  function hapticSupported() {
    try {
      return typeof root.navigator !== 'undefined' &&
        typeof root.navigator.vibrate === 'function' &&
        (root.navigator.maxTouchPoints || 0) > 0 &&
        root.matchMedia && root.matchMedia('(pointer: coarse)').matches;
    } catch (_) { return false; }
  }

  function ensure() {
    if (ac || !supported()) return ac;
    var C = root.AudioContext || root.webkitAudioContext;
    try { ac = new C({ latencyHint: 'interactive' }); } catch (e) { ac = new C(); }
    comp = ac.createDynamicsCompressor();
    comp.threshold.value = -20; comp.knee.value = 24; comp.ratio.value = 3;
    comp.attack.value = 0.003; comp.release.value = 0.22;
    lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 9200; lp.Q.value = 0.4;
    master = ac.createGain();
    master.gain.value = prefs.volume * 0.55;
    delay = ac.createDelay(0.6); delay.delayTime.value = 0.115;
    var fb = ac.createGain(); fb.gain.value = 0.16;
    wet = ac.createGain(); wet.gain.value = 0.10;
    delay.connect(fb); fb.connect(delay); delay.connect(wet); wet.connect(comp);
    comp.connect(lp); lp.connect(master); master.connect(ac.destination);
    busFor(ac).delay = delay;
    return ac;
  }

  function unlock() {
    if (!ensure()) return false;
    try {
      if (ac.state === 'suspended') ac.resume();
      unlocked = ac.state === 'running';
    } catch (e) { /* 忽略 */ }
    return unlocked;
  }

  /* ---------------- 音频优先级 ---------------- */
  function ttsBusy() {
    try { return !!(root.speechSynthesis && root.speechSynthesis.speaking); } catch (e) { return false; }
  }
  var liveMedia = [];
  function trackMedia(el) {
    if (!el || el.__lumiTracked) return;
    el.__lumiTracked = true;
    try {
      el.addEventListener('pause', function () { dropMedia(el); });
      el.addEventListener('ended', function () { dropMedia(el); });
      el.addEventListener('emptied', function () { dropMedia(el); });
      el.addEventListener('error', function () { dropMedia(el); });
    } catch (e) { /* 忽略 */ }
  }
  function dropMedia(el) {
    var i = liveMedia.indexOf(el);
    if (i >= 0) liveMedia.splice(i, 1);
  }
  function hookMedia() {
    if (hookMedia.done || !root.HTMLMediaElement) return;
    hookMedia.done = true;
    var proto = root.HTMLMediaElement.prototype;
    var orig = proto.play;
    if (typeof orig !== 'function' || orig.__lumiHook) return;
    var wrapped = function () {
      var el = this;
      trackMedia(el);
      var p = orig.apply(el, arguments);
      if (p && p.then) {
        p.then(function () {
          if (!el.paused && !el.ended && !el.muted && liveMedia.indexOf(el) < 0) liveMedia.push(el);
        }).catch(function () { dropMedia(el); });
      }
      return p;
    };
    wrapped.__lumiHook = true;
    proto.play = wrapped;
  }
  function mediaBusy() {
    hookMedia();
    try {
      for (var i = liveMedia.length - 1; i >= 0; i--) {
        var m = liveMedia[i];
        if (!m || m.paused || m.ended || m.muted || m.volume === 0) { liveMedia.splice(i, 1); continue; }
        if (m.readyState > 2 && m.currentTime > 0) return true;
      }
      var list = document.querySelectorAll('audio,video');
      for (var j = 0; j < list.length; j++) {
        var a = list[j];
        if (!a.paused && !a.ended && !a.muted && a.volume !== 0 && a.readyState > 2 && a.currentTime > 0) return true;
      }
    } catch (e) { /* 忽略 */ }
    return false;
  }
  function voiceBusy() {
    if (root.LumiVoiceActive) return true;
    try {
      if (root.LumiVoice && typeof root.LumiVoice.active === 'function' && root.LumiVoice.active()) return true;
    } catch (e) { /* 忽略 */ }
    return false;
  }
  function primaryBusy() { return voiceBusy() || mediaBusy(); }

  function allowed(name) {
    if (!prefs.enabled) return false;
    if (name === 'tap' || name === 'switch' || name === 'character') return prefs.tap;
    if (name === 'correct' || name === 'wrong' || name === 'combo' || name === 'remember') return prefs.feedback;
    return prefs.achieve; // complete / goal / mastery / connect / disconnect
  }

  var COOL = {
    tap: 55, switch: 120, correct: 110, wrong: 220, combo: 320, remember: 200,
    complete: 1200, goal: 5000, mastery: 900, connect: 1200, disconnect: 600, character: 400
  };

  function gate(name, force) {
    if (!allowed(name) && !force) return 'off';
    if (!ensure()) return 'unsupported';
    var now = Date.now();
    if (!force && lastAt[name] && now - lastAt[name] < (COOL[name] || 0)) return 'cool';
    if (!force) {
      if (primaryBusy() && name !== 'connect' && name !== 'disconnect') return 'primary';
      if (name !== 'connect' && name !== 'disconnect' && ttsBusy()) return 'tts';
    }
    return 'ok';
  }

  /* ---------------- 合成工具 ---------------- */
  function noise(ac2) {
    var b = busFor(ac2);
    if (b.noise) return b.noise;
    var len = Math.floor(ac2.sampleRate * 0.25);
    var buf = ac2.createBuffer(1, len, ac2.sampleRate);
    var d = buf.getChannelData(0);
    var seed = 1;
    for (var i = 0; i < len; i++) {
      seed = (seed * 16807) % 2147483647;
      d[i] = (seed / 2147483647) * 2 - 1;
    }
    b.noise = buf;
    noiseBuf = buf;
    return buf;
  }

  function note(ac2, dest, freq, t, dur, o) {
    o = o || {};
    var gain = ac2.createGain();
    var send = ac2.createGain();
    var out = ac2.createGain();
    out.gain.value = o.gain == null ? 0.1 : o.gain;
    var filt = ac2.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.value = o.lp || 7400;
    filt.Q.value = 0.5;
    var partials = o.partials || [1];
    var types = o.types || ['sine'];
    for (var i = 0; i < partials.length; i++) {
      var osc = ac2.createOscillator();
      osc.type = types[i % types.length];
      osc.frequency.setValueAtTime(freq * partials[i], t);
      if (o.detune) osc.detune.value = o.detune * (i % 2 ? -1 : 1);
      var pg = ac2.createGain();
      pg.gain.value = 1 / (i + 1.35);
      osc.connect(pg); pg.connect(filt);
      osc.start(t); osc.stop(t + dur + 0.05);
    }
    filt.connect(gain);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(0.9, t + (o.attack || 0.006));
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    gain.connect(out);
    out.connect(dest);
    if (o.send !== false) {
      send.gain.value = o.send || 0.12;
      out.connect(send);
      var bus = busFor(ac2);
      if (bus.delay) send.connect(bus.delay);
    }
  }

  function sparkle(ac2, dest, t, gain) {
    var src = ac2.createBufferSource();
    src.buffer = noise(ac2);
    var hp = ac2.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 4200;
    var bp = ac2.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 6200; bp.Q.value = 1.1;
    var g = ac2.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain || 0.02, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    src.connect(hp); hp.connect(bp); bp.connect(g); g.connect(dest);
    src.start(t); src.stop(t + 0.2);
  }

  function pad(ac2, dest, freq, t, dur, gain) {
    note(ac2, dest, freq / 2, t, dur, { gain: gain || 0.028, attack: 0.08, lp: 1600, partials: [1, 2], types: ['sine', 'triangle'], send: 0.06 });
  }

  /* ---------------- 声音事件 ---------------- */
  function schedule(ac2, dest, name, t0, st) {
    var t = t0 + 0.01;
    var A = st === 'A', Bs = st === 'B', Cs = st === 'C';
    var bell = A ? { partials: [1, 2.01, 2.99], types: ['sine', 'sine', 'sine'], lp: 8600, send: 0.13, attack: 0.004 }
      : Bs ? { partials: [1, 1.5, 2.98, 4.02], types: ['sine', 'triangle', 'sine', 'sine'], lp: 9600, send: 0.17, attack: 0.003 }
        : { partials: [1, 1.99, 2.4], types: ['triangle', 'sine', 'sine'], lp: 5200, send: 0.08, attack: 0.012 };

    function bellNote(f, at, dur, gain, extra) {
      var o = {}, k;
      for (k in bell) o[k] = bell[k];
      if (extra) for (k in extra) o[k] = extra[k];
      o.gain = gain;
      note(ac2, dest, f, t + at, dur, o);
    }

    if (name === 'tap') {
      note(ac2, dest, 1180, t, 0.045, { gain: 0.055, partials: [1, 2.03], types: ['sine', 'triangle'], lp: 7000, send: 0.05, attack: 0.003 });
      note(ac2, dest, 2360, t + 0.004, 0.022, { gain: 0.022, partials: [1], lp: 9000, send: 0.03 });
      return 0.08;
    }
    if (name === 'switch') {
      var f1 = Cs ? 540 : 660, f2 = Cs ? 760 : 990;
      note(ac2, dest, f1, t, 0.12, { gain: 0.07, partials: [1, 2], types: ['sine', 'triangle'], lp: 6400, send: 0.1, detune: 4 });
      note(ac2, dest, f2, t + 0.055, 0.09, { gain: 0.05, partials: [1], lp: 7600, send: 0.1 });
      return 0.16;
    }
    if (name === 'correct') {
      var c = A ? [1046.5, 1318.5, 1568] : Bs ? [1046.5, 1396.9, 1760] : [783.99, 987.77, 1174.7];
      for (var i = 0; i < c.length; i++) bellNote(c[i], i * 0.068, 0.20 - i * 0.02, 0.085 - i * 0.012, { detune: Bs ? 6 : 2 });
      sparkle(ac2, dest, t + 0.02, Bs ? 0.022 : 0.012);
      return 0.36;
    }
    if (name === 'remember') {
      var r1 = A ? 783.99 : Bs ? 880 : 659.25;
      var r2 = A ? 1046.5 : Bs ? 1174.7 : 880;
      note(ac2, dest, r1, t, 0.18, { gain: 0.06, partials: Bs ? [1, 1.5, 2.01] : [1, 2.01], types: Bs ? ['sine', 'triangle', 'sine'] : ['sine', 'sine'], lp: Bs ? 9000 : 5200, send: Bs ? 0.16 : 0.12, attack: 0.008 });
      note(ac2, dest, r2, t + 0.075, 0.20, { gain: 0.05, partials: Cs ? [1, 1.99] : [1, 2.01, 3], types: Cs ? ['triangle', 'sine'] : ['sine', 'sine', 'sine'], lp: Cs ? 4200 : 7000, send: Cs ? 0.06 : 0.14, attack: 0.006 });
      pad(ac2, dest, r1, t, 0.34, 0.012);
      return 0.32;
    }
    if (name === 'wrong') {
      var w = Cs ? [349.23, 293.66] : [392, 311.13];
      note(ac2, dest, w[0], t, 0.16, { gain: 0.055, partials: [1, 2], types: ['triangle', 'sine'], lp: 2000, send: 0.04, attack: 0.008 });
      note(ac2, dest, w[1], t + 0.105, 0.20, { gain: 0.045, partials: [1, 1.5], types: ['triangle', 'sine'], lp: 1700, send: 0.04, attack: 0.01 });
      return 0.32;
    }
    if (name === 'combo') {
      var lv = Number(arguments[5]) || 3;
      var seq = lv >= 10
        ? (A ? [1318.5, 1661.2, 1975.5, 2637] : Bs ? [1174.7, 1568, 1975.5, 2349.3, 3136] : [1046.5, 1318.5, 1568, 2093])
        : lv >= 5
          ? (A ? [1174.7, 1480, 1760] : Bs ? [1046.5, 1396.9, 1760, 2093] : [880, 1046.5, 1318.5])
          : (A ? [1046.5, 1318.5, 1568] : Bs ? [987.77, 1318.5, 1568] : [783.99, 987.77, 1174.7]);
      for (var j = 0; j < seq.length; j++) bellNote(seq[j], j * 0.052, 0.22, 0.075 + j * 0.004, { detune: Bs ? 7 : 3 });
      sparkle(ac2, dest, t + 0.03, 0.02);
      if (lv >= 10) pad(ac2, dest, seq[0], t, 0.42, 0.018);
      return 0.44;
    }
    if (name === 'complete') {
      var k = A ? [523.25, 659.25, 783.99, 1046.5] : Bs ? [523.25, 698.46, 880, 1046.5, 1396.9] : [392, 523.25, 659.25, 783.99];
      for (var n = 0; n < k.length; n++) bellNote(k[n], n * 0.115, 0.34, 0.08, { detune: Bs ? 5 : 2 });
      pad(ac2, dest, k[0], t, 0.72, 0.022);
      return 0.78;
    }
    if (name === 'goal') {
      var g = A ? [523.25, 659.25, 783.99, 1046.5, 1318.5] : Bs ? [523.25, 783.99, 1046.5, 1318.5, 1568, 2093] : [392, 523.25, 659.25, 783.99, 1046.5];
      for (var m = 0; m < g.length; m++) bellNote(g[m], m * 0.125, 0.42, 0.082, {});
      pad(ac2, dest, g[0], t, 1.05, 0.03);
      sparkle(ac2, dest, t + 0.45, 0.03);
      return 1.12;
    }
    if (name === 'mastery') {
      var y = Bs ? [880, 1174.7, 1568, 2349.3] : [880, 1108.7, 1318.5];
      for (var p = 0; p < y.length; p++) bellNote(y[p], p * 0.07, 0.26, 0.06, {});
      sparkle(ac2, dest, t + 0.02, 0.018);
      return 0.4;
    }
    if (name === 'connect') {
      note(ac2, dest, 659.25, t, 0.16, { gain: 0.06, partials: [1, 2.01], types: ['sine', 'sine'], lp: 7200, send: 0.16 });
      note(ac2, dest, 987.77, t + 0.09, 0.24, { gain: 0.055, partials: [1, 2.01, 3], types: ['sine', 'sine', 'sine'], lp: 8200, send: 0.18 });
      return 0.36;
    }
    if (name === 'disconnect') {
      note(ac2, dest, 523.25, t, 0.14, { gain: 0.045, partials: [1, 2], types: ['sine', 'sine'], lp: 5200, send: 0.1 });
      note(ac2, dest, 392, t + 0.08, 0.2, { gain: 0.038, partials: [1], types: ['sine'], lp: 4200, send: 0.08 });
      return 0.3;
    }
    if (name === 'character') {
      note(ac2, dest, 740, t, 0.07, { gain: 0.032, partials: [1, 2], types: ['sine', 'triangle'], lp: 6000, send: 0.08 });
      return 0.1;
    }
    return 0;
  }

  /* ---------------- 播放 ---------------- */
  function play(name, opts) {
    opts = opts || {};
    var force = !!opts.force;
    var state = gate(name, force);
    if (state !== 'ok') { lastPlay = { name: name, ok: false, why: state, at: Date.now() }; return false; }
    if (active > 6 && name === 'tap') { lastPlay = { name: name, ok: false, why: 'busy', at: Date.now() }; return false; }
    try {
      if (ac.state === 'suspended') ac.resume();
      var dur = schedule(ac, comp, name, ac.currentTime, opts.style || style, opts.level);
      lastAt[name] = Date.now();
      active++;
      root.setTimeout(function () { active = Math.max(0, active - 1); }, Math.max(120, dur * 1000));
      lastPlay = { name: name, ok: true, dur: Math.round(dur * 1000), style: opts.style || style, at: Date.now() };
      if (opts.haptic) haptic(name);
      return true;
    } catch (e) {
      lastPlay = { name: name, ok: false, why: 'error', at: Date.now() };
      return false;
    }
  }

  function answer(ok, combo) {
    if (ok) {
      if (combo >= 3 && (combo === 3 || combo === 5 || combo % 10 === 0)) return play('combo', { level: combo, haptic: true });
      return play('correct', { haptic: true });
    }
    play('wrong');
    return false;
  }

  function haptic(name) {
    if (!prefs.haptic || !hapticSupported()) return false;
    try {
      if (name === 'correct' || name === 'combo') root.navigator.vibrate([6, 24, 8]);
      else if (name === 'complete') root.navigator.vibrate([8, 40, 8, 40, 16]);
      else if (name === 'wrong') root.navigator.vibrate(0);
      else root.navigator.vibrate(5);
      return true;
    } catch (e) { return false; }
  }

  function goalOnce() {
    var d = new Date();
    var key = GOAL_KEY + d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
    try {
      if (root.localStorage.getItem(key) === '1') return false;
    } catch (e) { /* 忽略 */ }
    var ok = play('goal', { haptic: true });
    if (ok) { try { root.localStorage.setItem(key, '1'); } catch (e) { /* 忽略 */ } }
    return ok;
  }

  /* ---------------- 设置界面 ---------------- */
  function row(key, title, desc) {
    return '<div class="v2-set-row"><div class="v2-set-txt"><b>' + title + '</b>' + (desc ? '<small>' + desc + '</small>' : '') +
      '</div><button type="button" class="v2-switch" role="switch" data-snd="' + key + '" aria-checked="' + (prefs[key] ? 'true' : 'false') + '"><i></i></button></div>';
  }

  function settingsHtml() {
    var h = '<div class="card v2-set-list v2-sound-card">';
    h += row('enabled', '交互音效', '按钮、切换与学习反馈的总开关');
    h += row('feedback', '学习反馈', '答对、答错与连击');
    h += row('tap', '普通点击', '按钮与入口的轻点击');
    h += row('achieve', '成就音效', '完成、掌握与语音连接');
    h += '<div class="v2-set-row v2-set-col"><div class="v2-set-txt"><b>音量</b><small>建议保持偏低，久听不累</small></div>' +
      '<div class="v2-vol"><input id="sndVol" type="range" min="0" max="100" step="1" value="' + Math.round(prefs.volume * 100) + '" aria-label="音效音量"><span id="sndVolVal">' + Math.round(prefs.volume * 100) + '</span></div></div>';
    h += '<div class="v2-set-row v2-set-col"><div class="v2-set-txt"><b>音色风格</b><small>试听后可随时更换，默认苹果玻璃</small></div>' +
      '<div class="v2-snd-styles">';
    ['A', 'B', 'C'].forEach(function (s) {
      h += '<button type="button" class="v2-snd-style" data-snd-style="' + s + '" aria-pressed="' + (style === s ? 'true' : 'false') + '">' + s + ' · ' + STYLES[s] + '</button>';
    });
    h += '</div></div>';
    h += '<div class="v2-set-row"><div class="v2-set-txt"><b>触感反馈</b><small>' + (hapticSupported() ? '本机支持短震动' : '本机不支持（iPhone Safari 无 Vibration API），自动降级') + '</small></div>' +
      '<button type="button" class="v2-switch" role="switch" data-snd="haptic" aria-checked="' + (prefs.haptic && hapticSupported() ? 'true' : 'false') + '"' + (hapticSupported() ? '' : ' disabled') + '><i></i></button></div>';
    h += '<div class="v2-set-row"><div class="v2-set-txt"><b>试听</b><small>先点一下解锁音频，再试听答对音</small></div>' +
      '<button type="button" class="btn ghost sm" data-snd-preview="correct">▶ 试听</button></div>';
    h += '<div class="v2-set-row"><div class="v2-set-txt"><b>全部音效</b><small>12 个事件、三套风格与 WAV 导出</small></div>' +
      '<a class="btn ghost sm" href="sound-lab.html">声音实验室</a></div>';
    h += '<p class="v2-set-note">音效只影响界面反馈，不会关闭单词发音、听力材料或 AI 语音。检测到听力、发音或实时语音时，低优先级音效会自动让路。</p>';
    h += '</div>';
    return h;
  }

  function sync(rootEl) {
    if (!rootEl) rootEl = document.getElementById('soundSettings') || document;
    var list = rootEl.querySelectorAll('[data-snd]');
    for (var i = 0; i < list.length; i++) {
      var k = list[i].getAttribute('data-snd');
      var on = k === 'haptic' ? (prefs.haptic && hapticSupported()) : !!prefs[k];
      list[i].setAttribute('aria-checked', on ? 'true' : 'false');
      list[i].classList.toggle('on', on);
    }
    var vol = rootEl.querySelector('#sndVol');
    if (vol) vol.value = Math.round(prefs.volume * 100);
    var vv = rootEl.querySelector('#sndVolVal');
    if (vv) vv.textContent = Math.round(prefs.volume * 100);
    var st = rootEl.querySelectorAll('[data-snd-style]');
    for (var j = 0; j < st.length; j++) st[j].setAttribute('aria-pressed', st[j].getAttribute('data-snd-style') === style ? 'true' : 'false');
  }

  function bindSettings(rootEl) {
    if (!rootEl) return;
    sync(rootEl);
    rootEl.addEventListener('click', function (ev) {
      var t = ev.target.closest('[data-snd]');
      if (t) {
        var k = t.getAttribute('data-snd');
        if (k === 'haptic' && !hapticSupported()) return;
        prefs[k] = !prefs[k];
        if (k === 'enabled' && prefs.enabled) unlock();
        savePrefs(); sync(rootEl);
        if (k === 'enabled' && !prefs.enabled) return;
        play('tap', { force: true });
        if (k === 'haptic') haptic('tap');
        return;
      }
      var s = ev.target.closest('[data-snd-style]');
      if (s) {
        saveStyle(s.getAttribute('data-snd-style'));
        sync(rootEl);
        play('correct', { force: true });
        return;
      }
      var p = ev.target.closest('[data-snd-preview]');
      if (p) { unlock(); play(p.getAttribute('data-snd-preview'), { force: true, haptic: true }); }
    });
    rootEl.addEventListener('input', function (ev) {
      if (ev.target && ev.target.id === 'sndVol') {
        prefs.volume = Math.max(0, Math.min(1, Number(ev.target.value) / 100));
        savePrefs();
        if (master) master.gain.value = prefs.volume * 0.55;
        var vv = rootEl.querySelector('#sndVolVal');
        if (vv) vv.textContent = ev.target.value;
      }
    });
    rootEl.addEventListener('change', function (ev) {
      if (ev.target && ev.target.id === 'sndVol') play('tap', { force: true });
    });
  }

  /* ---------------- WAV 导出（与在线播放同一套调度） ---------------- */
  function wav(name, st, level) {
    st = STYLES[st] ? st : style;
    var C = root.OfflineAudioContext || root.webkitOfflineAudioContext;
    if (!C) return Promise.reject(new Error('OfflineAudioContext 不可用'));
    var dur = 1.6;
    var off;
    try { off = new C(2, Math.ceil(44100 * dur), 44100); } catch (e) { return Promise.reject(e); }
    var out = off.createGain(); out.gain.value = 0.9;
    var dl = off.createDelay(0.6); dl.delayTime.value = 0.115;
    var fb = off.createGain(); fb.gain.value = 0.16;
    var wet2 = off.createGain(); wet2.gain.value = 0.10;
    var comp2 = off.createDynamicsCompressor();
    comp2.threshold.value = -20; comp2.ratio.value = 3;
    dl.connect(fb); fb.connect(dl); dl.connect(wet2); wet2.connect(comp2);
    out.connect(comp2); comp2.connect(off.destination);
    busFor(off).delay = dl;
    schedule(off, out, name, 0, st, level || (name === 'combo' ? 3 : undefined));
    return off.startRendering().then(function (buf) { return encodeWav(buf); });
  }

  function encodeWav(buf) {
    var ch = buf.numberOfChannels, len = buf.length, bytes = 44 + len * ch * 2;
    var view = new DataView(new ArrayBuffer(bytes));
    function str(o, s) { for (var i = 0; i < s.length; i++) view.setUint8(o + i, s.charCodeAt(i)); }
    str(0, 'RIFF'); view.setUint32(4, bytes - 8, true); str(8, 'WAVE'); str(12, 'fmt ');
    view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, ch, true);
    view.setUint32(24, buf.sampleRate, true); view.setUint32(28, buf.sampleRate * ch * 2, true);
    view.setUint16(32, ch * 2, true); view.setUint16(34, 16, true); str(36, 'data');
    view.setUint32(40, len * ch * 2, true);
    var data = [], c, i;
    for (c = 0; c < ch; c++) data.push(buf.getChannelData(c));
    var o = 44;
    for (i = 0; i < len; i++) {
      for (c = 0; c < ch; c++) {
        var s = Math.max(-1, Math.min(1, data[c][i]));
        view.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
        o += 2;
      }
    }
    return new Blob([view.buffer], { type: 'audio/wav' });
  }

  function debug() {
    return {
      supported: supported(), state: ac ? ac.state : 'none', unlocked: unlocked || !!(ac && ac.state === 'running'),
      active: active, prefs: prefs, style: style, last: lastPlay,
      haptic: hapticSupported(), tts: ttsBusy(), media: mediaBusy(), voice: voiceBusy()
    };
  }

  /* ---------------- 全局解锁与轻点击 ---------------- */
  function isTapTarget(el) {
    if (!el || !el.closest) return false;
    return !!el.closest('.btn,.v2-btn,.v2-dock-btn,.v2-module,.v2-quick,.icon-btn,.v2-seg-btn,.v2-snd-style,[data-snd-preview],.v2-switch');
  }

  if (typeof document !== 'undefined') {
    document.addEventListener('pointerdown', function (ev) {
      unlock();
      var t = ev.target;
      if (t && t.closest && t.closest('[data-sound="off"]')) return;
      if (isTapTarget(t)) play('tap');
    }, { passive: true });
    document.addEventListener('keydown', function () { unlock(); }, { passive: true });
    document.addEventListener('visibilitychange', function () {
      if (!ac) return;
      try {
        if (document.hidden) { if (ac.state === 'running') ac.suspend(); }
        else if (unlocked) ac.resume();
      } catch (e) { /* 忽略 */ }
    });
  }

  hookMedia();

  root.Sound = {
    play: play, answer: answer, combo: function (n) { return play('combo', { level: n, haptic: true }); },
    complete: function () { return play('complete', { haptic: true }); },
    goal: goalOnce, mastery: function () { return play('mastery', { haptic: true }); },
    connect: function () { return play('connect'); }, disconnect: function () { return play('disconnect'); },
    character: function () { return play('character'); },
    tap: function () { return play('tap'); }, unlock: unlock, prefs: function () { return prefs; },
    setStyle: saveStyle, setVolume: setVolume, style: function () { return style; }, settingsHtml: settingsHtml,
    bindSettings: bindSettings, sync: sync, wav: wav, debug: debug,
    supported: supported, hapticSupported: hapticSupported, STYLES: STYLES
  };
})(typeof window !== 'undefined' ? window : globalThis);