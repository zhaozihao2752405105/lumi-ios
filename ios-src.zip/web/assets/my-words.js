/* ============================================================
 * my-words.js —— 个人词书（上传自己的资料，抽出真实词条）
 * 规则：
 *   - 只接受文本里出现的英文词，逐个到公共词典（public.words）里找；
 *     词典里没有的词直接跳过，不编造、不猜释义。
 *   - 个人词书只用于「自由练习 / 自测」，不进入 SM-2 正式复习队列。
 *   - 解析全程在浏览器完成，不调用 AI、不产生费用。
 * ============================================================ */
(function () {
  'use strict';

  var S = {
    books: [],
    busy: false,
    result: null,      // {title, matched, missing, total, missingSample}
    preview: null,     // {title, count, sample}
    fileName: ''
  };

  var CHUNK = 500;
  var MAX_WORDS = 3000;

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function toast(msg, ms) {
    var t = el('toast'); if (!t) return;
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, ms || 2400);
  }
  function rpc(name, args) {
    if (!window.DB || typeof window.DB.rpc !== 'function') return Promise.reject(new Error('数据库未就绪'));
    return window.DB.rpc(name, args || {});
  }

  /* ---------- 抽词 ---------- */
  function extractWords(text) {
    var raw = String(text || '');
    var found = raw.match(/[A-Za-z][A-Za-z'\-]{1,39}/g) || [];
    var seen = Object.create(null);
    var out = [];
    for (var i = 0; i < found.length; i++) {
      var w = found[i].toLowerCase().replace(/^[-']+|[-']+$/g, '');
      if (w.length < 2) continue;
      if (seen[w]) continue;
      seen[w] = 1;
      out.push(w);
      if (out.length >= MAX_WORDS) break;
    }
    return out;
  }

  function titleFrom(name) {
    var base = String(name || '').replace(/\.[a-z0-9]+$/i, '').trim();
    if (!base) base = '我的词书';
    return base.slice(0, 60);
  }

  /* ---------- 渲染 ---------- */
  function uploadCard() {
    var p = S.preview;
    return '<section class="card"><h3 style="margin:0 0 6px">上传资料，生成我的词书</h3>' +
      '<p class="muted small">支持 .txt / .csv / .md，或者直接粘贴文本。只抽取英文单词，' +
      '再逐个到词典里核对；词典里没有的词会跳过，不会编造释义。全程在浏览器解析，不花 AI 费用。</p>' +
      '<div class="row mt12"><input id="mwFile" type="file" accept=".txt,.csv,.md,text/plain" class="mw-file"></div>' +
      '<p class="muted small mt8">或者直接粘贴一段英文（比如课文、文章、生词表）：</p>' +
      '<textarea id="mwText" class="mw-area" rows="6" placeholder="Paste English text here…"></textarea>' +
      '<div class="row mt8"><button class="btn ghost block" data-act="scan">先看看能抽到多少词</button></div>' +
      (p ? '<div class="mw-preview"><b>' + esc(p.title) + '</b>' +
        '<p class="muted small">识别到 <b>' + p.count + '</b> 个不重复英文词' +
        (p.sample.length ? '，例如：' + p.sample.map(esc).join('、') : '') + '</p>' +
        '<div class="row mt8"><button class="btn block" data-act="create"' + (S.busy ? ' disabled' : '') + '>' +
        (S.busy ? '正在建词书…' : '生成词书') + '</button></div></div>' : '') +
      (S.result ? '<div class="mw-result"><b>' + esc(S.result.title) + '</b>' +
        '<p class="muted small">收进 <b>' + S.result.total + '</b> 个真实词条（匹配 ' + S.result.matched + ' 个）。' +
        (S.result.missing ? '有 ' + S.result.missing + ' 个词不在词典里，已跳过' +
          (S.result.missingSample && S.result.missingSample.length ? '（如 ' + S.result.missingSample.slice(0, 6).map(esc).join('、') + '）' : '') + '。' : '') +
        '</p>' +
        '<div class="row mt8"><a class="btn block" href="practice.html?src=personal&book=' + esc(S.result.id) + '">去练这本（跟写/听写/默写）</a></div>' +
        '</div>' : '') +
      '</section>';
  }

  function listCard() {
    if (!S.books.length) {
      return '<section class="card"><h3 style="margin:0 0 8px">我的词书</h3>' +
        '<p class="muted small">还没有个人词书。上传一份资料就有了。</p></section>';
    }
    return '<section class="card"><h3 style="margin:0 0 8px">我的词书（' + S.books.length + '）</h3>' +
      S.books.map(function (b) {
        return '<div class="mw-book"><div><b>' + esc(b.title) + '</b>' +
          '<div class="muted small">' + b.word_count + ' 个词 · ' + String(b.created_at || '').slice(0, 10) + '</div></div>' +
          '<div class="mw-acts">' +
          '<a class="btn ghost sm" href="practice.html?src=personal&book=' + esc(b.id) + '">练习</a>' +
          '<button class="btn ghost sm" data-act="del" data-id="' + esc(b.id) + '" data-title="' + esc(b.title) + '">删除</button>' +
          '</div></div>';
      }).join('') +
      '<p class="muted small mt8">个人词书只用于自由练习与自测，不占正式复习安排。</p></section>';
  }

  function render() {
    var box = el('view'); if (!box) return;
    box.innerHTML = uploadCard() + listCard();
    var f = el('mwFile');
    if (f && !f._bound) {
      f._bound = true;
      f.addEventListener('change', function () {
        var file = f.files && f.files[0];
        if (!file) return;
        S.fileName = file.name || '';
        var fr = new FileReader();
        fr.onload = function () { var t = el('mwText'); if (t) t.value = String(fr.result || ''); scan(); };
        fr.onerror = function () { toast('文件读取失败'); };
        fr.readAsText(file.slice(0, 2 * 1024 * 1024));
      });
    }
  }

  /* ---------- 动作 ---------- */
  function scan() {
    var t = el('mwText');
    var words = extractWords(t ? t.value : '');
    if (!words.length) { toast('这段文本里没抽到英文词'); return; }
    S.preview = { title: titleFrom(S.fileName), count: words.length, sample: words.slice(0, 8) };
    render();
    toast('抽到 ' + words.length + ' 个不重复的词');
  }

  async function createBook() {
    if (S.busy || !S.preview) return;
    var t = el('mwText');
    var words = extractWords(t ? t.value : '');
    if (!words.length) { toast('先粘贴或上传一段英文'); return; }
    S.busy = true; S.result = null; render();
    try {
      var c = await rpc('create_personal_wordbook', { p_title: S.preview.title });
      if (!c || !c.ok) throw new Error((c && c.message) || '建书失败');
      var id = c.id;
      var matched = 0, missing = 0, missingSample = [], total = 0;
      for (var i = 0; i < words.length; i += CHUNK) {
        var part = words.slice(i, i + CHUNK);
        var r = await rpc('add_personal_book_words', { p_book_id: id, p_words: part });
        if (!r || !r.ok) throw new Error((r && r.message) || '加词失败');
        matched += Number(r.matched) || 0;
        total = Number(r.total) || total;
        var ms = r.missing_sample || [];
        missing += Math.max(0, part.length - (Number(r.matched) || 0));
        if (missingSample.length < 8 && ms.length) missingSample = missingSample.concat(ms).slice(0, 8);
      }
      S.result = { id: id, title: S.preview.title, matched: matched, total: total, missing: missing, missingSample: missingSample };
      S.preview = null;
      toast('词书建好了：' + total + ' 个词');
      await loadBooks();
    } catch (e) {
      toast('出错了：' + ((e && e.message) || e));
    }
    S.busy = false;
    render();
  }

  async function delBook(id, title) {
    if (!window.confirm('删除「' + title + '」？练习记录里这个词的词条不会动，只是这本词书消失。')) return;
    try {
      var r = await rpc('delete_personal_wordbook', { p_book_id: id });
      if (!r || !r.ok) throw new Error((r && r.message) || '删除失败');
      toast('已删除');
      await loadBooks();
    } catch (e) { toast('删除失败：' + ((e && e.message) || e)); }
    render();
  }

  async function loadBooks() {
    try {
      var r = await rpc('list_personal_wordbooks', {});
      S.books = (r && r.books) || [];
    } catch (e) { S.books = []; }
  }

  /* ---------- 事件 ---------- */
  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'scan') return scan();
    if (act === 'create') return createBook();
    if (act === 'del') return delBook(t.getAttribute('data-id'), t.getAttribute('data-title') || '这本书');
  });

  /* ---------- 启动 ---------- */
  (async function boot() {
    el('view').innerHTML = '<div class="card"><p class="muted">正在准备…</p></div>';
    var user = null;
    try { user = await window.AppAuth.requireLogin(); } catch (e) { user = null; }
    if (!user) return;
    var name = '';
    try { name = window.AppAuth.displayName(user) || ''; } catch (e) { name = ''; }
    var u = el('userName');
    if (u) u.textContent = (name ? name + ' · ' : '') + '已登录';
    await loadBooks();
    render();
  })();
})();