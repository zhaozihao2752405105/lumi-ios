/* ============================================================
 * assets/memory.js —— B3 学习档案与教学记忆
 *
 * 用户可以：开关、查看、修改、删除、归档、恢复；确认/忽略系统推断。
 * 原则：
 *   · 系统推断先进 pending，确认后才 active；未确认绝不给 AI。
 *   · 生成观察只用本地学习数据，不调用 AI，不产生费用。
 *   · 关闭开关后 learnerProfile 返回 enabled=false，网关不拼任何档案。
 * ============================================================ */
(function () {
  'use strict';
  var S = { uid: null, prof: null, list: [], a: null, busy: false, err: '' };
  var KIND = {
    preference: '学习偏好', goal: '长期目标', error_pattern: '反复错误',
    mastered: '已掌握', note: '备注'
  };
  var KIND_ORDER = ['goal', 'preference', 'error_pattern', 'mastered', 'note'];

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function toast(msg) {
    var t = el('toast'); if (!t) return alert(msg);
    t.textContent = msg; t.classList.add('on');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('on'); }, 2800);
  }
  function pct(r) { return r == null ? '—' : Math.round(Number(r) * 100) + '%'; }
  function dateOf(s) { return s ? String(s).slice(0, 10) : ''; }
  function byId(id) { return S.list.filter(function (m) { return m.id === id; })[0] || null; }

  function postgrestCode(e) {
    var m = String((e && e.message) || '');
    var hit = m.match(/23505|duplicate key|already exists/i);
    return hit ? '23505' : '';
  }

  /* ---------------- 渲染 ---------------- */
  function headerHtml() {
    var on = !!(S.prof && S.prof.memory_enabled !== false);
    var h = '<div class="v2-pagehead"><p class="v2-eyebrow">Learning profile</p><h1 class="v2-h1">学习档案</h1><p>AI 老师参考什么、记住什么，都由你决定。</p></div>';
    h += '<section class="card v2-mem-switch' + (on ? '' : ' is-off') + '">' +
      '<div class="v2-mem-switch-row"><div><h3>' + (on ? 'AI 可以参考我的学习记录' : '学习档案已关闭') + '</h3>' +
      '<p class="small muted">' + (on
        ? '开启时，AI 老师会看到下面的统计和「生效」记忆，用来调整讲解与练习难度。'
        : '现在不会把你的学习统计或记忆发给 AI。聊天和学习功能仍然正常，只是老师不了解你的进度。') + '</p></div>' +
      '<button type="button" class="btn ' + (on ? 'ghost' : '') + ' sm v2-mem-toggle" data-act="toggle" aria-pressed="' + on + '">' + (on ? '关闭' : '开启') + '</button></div>' +
      '<div class="v2-mem-state"><span class="dot" aria-hidden="true"></span>' + (on ? '正在参考 · 可随时关闭' : '已停止参考 · 数据仍保存在你的账号里') + '</div>' +
      '</section>';
    h += '<section class="card v2-mem-about"><h3>AI 会看到什么</h3><ul>' +
      '<li><b>学习统计</b>：到期词数量、近 14 天正确率、薄弱词、最近未解决错题。</li>' +
      '<li><b>教学记忆</b>：下面状态为「生效」的条目（你写的，或你确认过的观察）。</li>' +
      '<li><b>不会看到</b>：聊天原文、邮箱、密码、预算；也不会把一次错题当成整体能力结论。</li></ul>' +
      '<p class="small muted">关闭后，AI 请求里不会附带任何档案。你仍可以在这个页面查看自己的数据。</p>' +
      '<div class="v2-actions"><a class="btn ghost sm" href="chat.html">去问 AI 老师</a><a class="btn ghost sm" href="settings.html">返回设置</a></div></section>';
    return h;
  }

  function addHtml() {
    var opts = KIND_ORDER.map(function (k) { return '<option value="' + k + '">' + KIND[k] + '</option>'; }).join('');
    return '<section class="card v2-mem-add"><h3>添加一条记忆</h3>' +
      '<p class="small muted">写你希望老师长期记住的事，例如目标、偏好、常错的点。2–500 字。</p>' +
      '<div class="v2-mem-form"><label class="small muted" for="memKind">类型</label><select id="memKind" class="v2-input">' + opts + '</select>' +
      '<label class="small muted" for="memText">内容</label><textarea id="memText" class="v2-input" rows="3" maxlength="500" placeholder="例如：我想更自信地用英语交流；解释语法时请先给中文。"></textarea>' +
      '<div class="v2-mem-form-foot"><span id="memCount" class="small muted">0 / 500</span><button type="button" class="btn sm" data-act="add">保存记忆</button></div></div></section>';
  }

  function memoryItem(m, archived) {
    var isInferred = m.source === 'inferred';
    var h = '<article class="v2-mem-item" data-id="' + esc(m.id) + '">';
    h += '<div class="v2-mem-meta"><span class="v2-mem-kind">' + esc(KIND[m.kind] || '记忆') + '</span>' +
      '<span class="v2-mem-source ' + (isInferred ? 'is-inferred' : 'is-user') + '">' + (isInferred ? '系统观察 · 已确认' : '我写的') + '</span>' +
      (m.evidence_count ? '<span class="v2-mem-evidence">依据 ' + Number(m.evidence_count) + ' 条</span>' : '') +
      (m.updated_at ? '<time datetime="' + esc(m.updated_at) + '">' + esc(dateOf(m.updated_at)) + '</time>' : '') + '</div>';
    h += '<p class="v2-mem-content">' + esc(m.content) + '</p>';
    h += '<div class="v2-mem-actions">';
    if (archived) {
      h += '<button type="button" class="v2-mem-act" data-act="restore">恢复</button><button type="button" class="v2-mem-act is-danger" data-act="delete">删除</button>';
    } else {
      h += '<button type="button" class="v2-mem-act" data-act="edit">修改</button><button type="button" class="v2-mem-act" data-act="archive">归档</button><button type="button" class="v2-mem-act is-danger" data-act="delete">删除</button>';
    }
    return h + '</div></article>';
  }

  function pendingHtml() {
    var list = S.list.filter(function (m) { return m.status === 'pending'; });
    var h = '<section class="card v2-mem-pending"><div class="v2-section-head"><h3>待确认的观察</h3><span class="v2-mem-count">' + list.length + ' 条</span></div>' +
      '<p class="small muted">这些是系统根据你的答题记录推断的，<b>还没有生效</b>。确认后才进入 AI 上下文；忽略会归档。</p>';
    if (!list.length) h += '<p class="v2-mem-empty">现在没有待确认的观察。</p>';
    list.forEach(function (m) {
      h += '<article class="v2-mem-item is-pending" data-id="' + esc(m.id) + '">' +
        '<div class="v2-mem-meta"><span class="v2-mem-kind">' + esc(KIND[m.kind] || '观察') + '</span><span class="v2-mem-source is-pending">待确认</span>' +
        (m.evidence_count ? '<span class="v2-mem-evidence">依据 ' + Number(m.evidence_count) + ' 条</span>' : '') + '</div>' +
        '<p class="v2-mem-content">' + esc(m.content) + '</p>' +
        '<div class="v2-mem-actions"><button type="button" class="v2-mem-act is-primary" data-act="confirm">确认并生效</button><button type="button" class="v2-mem-act" data-act="ignore">忽略</button><button type="button" class="v2-mem-act is-danger" data-act="delete">删除</button></div></article>';
    });
    h += '<div class="v2-mem-generate"><button type="button" class="btn ghost sm" data-act="generate">根据最近记录生成观察</button><span class="small muted">只在本机计算，不调用 AI、不花钱。</span></div></section>';
    return h;
  }

  function activeHtml() {
    var list = S.list.filter(function (m) { return m.status === 'active'; });
    var h = '<section class="card v2-mem-list"><div class="v2-section-head"><h3>生效中的记忆</h3><span class="v2-mem-count">' + list.length + ' 条</span></div>';
    if (!list.length) {
      h += '<p class="v2-mem-empty">还没有生效的记忆。你可以在上面添加，或确认一条系统观察。</p>';
    } else {
      KIND_ORDER.forEach(function (k) {
        var group = list.filter(function (m) { return m.kind === k; });
        if (!group.length) return;
        h += '<h4 class="v2-mem-group">' + KIND[k] + '</h4>';
        group.forEach(function (m) { h += memoryItem(m, false); });
      });
    }
    h += '</section>';
    return h;
  }

  function archivedHtml() {
    var list = S.list.filter(function (m) { return m.status === 'archived'; });
    if (!list.length) return '';
    var h = '<details class="card v2-mem-archived"><summary>已归档的记忆 <span>' + list.length + '</span></summary><div class="v2-mem-arch-inner">';
    list.forEach(function (m) { h += memoryItem(m, true); });
    return h + '</div></details>';
  }

  function statsHtml() {
    var a = S.a;
    if (!a) return '<section class="card"><h3>当前掌握情况</h3><p class="small muted">现在读不到学习统计（可能离线或数据还没同步）。恢复网络后会重新计算。</p></section>';
    var sm = a.sample || {}, mod = a.module_accuracy || {};
    var h = '<section class="card v2-mem-stats"><div class="v2-section-head"><h3>当前掌握情况</h3><span class="v2-mem-count">只读</span></div>';
    h += '<div class="v2-metrics"><div class="v2-metric"><b>' + Number(a.mastered_words || 0) + '</b><span>已掌握词</span></div>' +
      '<div class="v2-metric"><b>' + Number(a.streak_days || 0) + '</b><span>连续天数</span></div>' +
      '<div class="v2-metric"><b>' + pct(sm.accuracy) + '</b><span>近 14 天正确率</span></div></div>';
    h += '<p class="small muted v2-mem-sample">样本：' + Number(sm.units || 0) + ' 题 · ' + Number(sm.active_days || 0) + ' 个学习日' + (Number(sm.units || 0) < 12 ? '（还少，不会据此调难度）' : '') + '</p>';
    var weak = (a.weak_words || []).slice(0, 6);
    if (weak.length) {
      h += '<h4 class="v2-mem-group">容易忘的词</h4><div class="v2-mem-chips">';
      weak.forEach(function (w) { h += '<span class="v2-mem-chip">' + esc(w.word) + ' <i>忘 ' + Number(w.lapses) + ' 次</i></span>'; });
      h += '</div>';
    }
    if ((a.weak_points || []).length) {
      h += '<h4 class="v2-mem-group">还需巩固的语法</h4><ul class="v2-mem-points">';
      a.weak_points.forEach(function (p) { h += '<li><span>' + esc(p.title) + '</span><i>最近 ' + pct(p.last_rate) + '</i></li>'; });
      h += '</ul>';
    }
    if ((a.mastered_points || []).length) {
      h += '<h4 class="v2-mem-group">已经掌握的语法</h4><ul class="v2-mem-points is-ok">';
      a.mastered_points.forEach(function (p) { h += '<li><span>' + esc(p.title) + '</span><i>最近 ' + pct(p.last_rate) + '</i></li>'; });
      h += '</ul>';
    }
    var mods = [['listening', '听力'], ['reading', '阅读'], ['grammar', '语法']];
    if (mods.some(function (m) { return (mod[m[0]] || {}).total; })) {
      h += '<h4 class="v2-mem-group">模块正确率</h4><div class="v2-mem-modules">';
      mods.forEach(function (m) {
        var x = mod[m[0]] || {};
        h += '<div><span>' + m[1] + '</span><b>' + (x.total ? pct(x.rate) : '—') + '</b><small>' + Number(x.total || 0) + ' 题</small></div>';
      });
      h += '</div>';
    }
    h += '<p class="small muted v2-mem-note">这里显示的是你自己的数据；关闭上面的开关只会停止把它们发给 AI，不会删除学习记录。</p></section>';
    return h;
  }

  function render() {
    var h = headerHtml() + addHtml() + pendingHtml() + activeHtml() + statsHtml() + archivedHtml();
    if (S.err) h = '<div class="card v2-mem-error"><b>读取失败</b><p class="small muted">' + esc(S.err) + '</p><button type="button" class="btn ghost sm mt12" data-act="reload">重试</button></div>' + h;
    el('view').innerHTML = h;
    var ta = el('memText');
    if (ta) {
      ta.addEventListener('input', function () {
        var c = el('memCount'); if (c) c.textContent = ta.value.length + ' / 500';
      });
    }
  }

  /* ---------------- 数据 ---------------- */
  async function load() {
    var user = await window.AppAuth.requireLogin();
    if (!user) return;
    S.uid = user.id;
    el('userName').textContent = (window.AppAuth.displayName(user) || '') + ' · 已登录';
    S.err = '';
    try {
      var ps = await window.DB.select('profiles', { id: user.id, limit: 1 });
      S.prof = ps && ps[0];
      if (!S.prof) throw new Error('没有找到个人资料');
    } catch (e) {
      S.err = (e && e.message) || '读取个人资料失败';
      render();
      return;
    }
    try {
      var rows = await window.DB.select('learner_memory', { user_id: user.id, order: 'updated_at.desc', limit: 200 });
      S.list = Array.isArray(rows) ? rows : [];
    } catch (e) {
      S.err = (e && e.message) || '读取记忆失败';
      S.list = [];
    }
    if (window.Adaptive) {
      try { S.a = await window.Adaptive.get(user.id); } catch (e) { S.a = null; }
    }
    render();
  }

  async function toggle() {
    if (S.busy || !S.prof) return;
    S.busy = true;
    var next = S.prof.memory_enabled === false;
    try {
      await window.DB.update('profiles', { memory_enabled: next }, { id: S.uid });
      S.prof.memory_enabled = next;
      if (window.Adaptive) window.Adaptive.invalidate(S.uid);
      toast(next ? '已开启：AI 会参考学习记录' : '已关闭：AI 不再读取学习档案');
      render();
    } catch (e) {
      toast('保存失败：' + ((e && e.message) || '未知错误'));
    }
    S.busy = false;
  }

  async function addMemory() {
    if (S.busy) return;
    var kind = (el('memKind') || {}).value || 'note';
    var ta = el('memText');
    var content = ta ? String(ta.value || '').replace(/\s+/g, ' ').trim() : '';
    if (content.length < 2) return toast('请至少写 2 个字');
    if (content.length > 500) return toast('最多 500 字');
    if (!KIND[kind]) kind = 'note';
    S.busy = true;
    try {
      await window.DB.insert('learner_memory', {
        user_id: S.uid, kind: kind, content: content, source: 'user', status: 'active',
        confirmed_at: new Date().toISOString(), evidence_count: 1
      });
      toast('已保存');
      await load();
    } catch (e) {
      if (postgrestCode(e)) toast('已有同样的记忆');
      else toast('保存失败：' + ((e && e.message) || '未知错误'));
    }
    S.busy = false;
  }

  async function patch(m, data, okMsg) {
    if (!m || S.busy) return;
    S.busy = true;
    try {
      await window.DB.update('learner_memory', data, { id: m.id });
      if (window.Adaptive) window.Adaptive.invalidate(S.uid);
      toast(okMsg);
      await load();
    } catch (e) {
      toast('更新失败：' + ((e && e.message) || '未知错误'));
    }
    S.busy = false;
  }

  function confirmMemory(m) {
    patch(m, { status: 'active', confirmed_at: new Date().toISOString() }, '已确认，AI 之后会参考');
  }
  function ignoreMemory(m) {
    patch(m, { status: 'archived' }, '已忽略并归档');
  }
  function archiveMemory(m) {
    patch(m, { status: 'archived' }, '已归档');
  }
  function restoreMemory(m) {
    var canActive = m.source === 'user' || !!m.confirmed_at;
    patch(m, { status: canActive ? 'active' : 'pending' }, canActive ? '已恢复' : '已恢复为待确认');
  }
  function deleteMemory(m) {
    if (!m) return;
    try { if (!window.confirm('删除这条记忆？删除后不能恢复。')) return; } catch (e) {}
    if (S.busy) return;
    S.busy = true;
    window.DB.remove('learner_memory', { id: m.id }).then(function () {
      if (window.Adaptive) window.Adaptive.invalidate(S.uid);
      toast('已删除');
      return load();
    }).catch(function (e) {
      toast('删除失败：' + ((e && e.message) || '未知错误'));
    }).then(function () { S.busy = false; });
  }
  function editMemory(m) {
    if (!m) return;
    var v = null;
    try { v = window.prompt('修改这条记忆（2–500 字）', m.content); } catch (e) { v = null; }
    if (v == null) return;
    v = String(v).replace(/\s+/g, ' ').trim();
    if (v.length < 2) return toast('请至少写 2 个字');
    if (v.length > 500) return toast('最多 500 字');
    if (v === m.content) return;
    patch(m, { content: v }, '已修改');
  }

  function observations(a) {
    var out = [];
    (a.weak_words || []).slice(0, 2).forEach(function (w) {
      if (!w.word) return;
      out.push({
        kind: 'error_pattern',
        content: '我容易忘记「' + w.word + '」这个词（已累计忘记 ' + Number(w.lapses || 0) + ' 次）。',
        confidence: Math.min(0.9, 0.5 + 0.1 * Number(w.lapses || 0)),
        evidence_count: Number(w.lapses || 0)
      });
    });
    var gp = (a.weak_points || [])[0];
    if (gp) {
      out.push({
        kind: 'error_pattern',
        content: '语法「' + gp.title + '」还需要巩固（最近一次正确率 ' + pct(gp.last_rate) + '）。',
        confidence: 0.7, evidence_count: gp.attempts
      });
    }
    if (Number(a.mastered_words || 0) >= 5) {
      out.push({
        kind: 'mastered',
        content: '已经掌握 ' + Number(a.mastered_words) + ' 个单词，能在间隔 6 天以上后回忆起来。',
        confidence: 0.8, evidence_count: Number(a.mastered_words)
      });
    }
    var sm = a.sample || {};
    if (Number(sm.units || 0) >= 20 && Number(sm.accuracy || 0) >= 0.8) {
      out.push({
        kind: 'mastered',
        content: '近 14 天整体正确率稳定在 ' + pct(sm.accuracy) + '（' + Number(sm.units) + ' 题样本）。',
        confidence: 0.75, evidence_count: Number(sm.units)
      });
    }
    if (Number(a.streak_days || 0) >= 7) {
      out.push({
        kind: 'note',
        content: '已经连续学习 ' + Number(a.streak_days) + ' 天，适合继续按自己的节奏学习。',
        confidence: 0.9, evidence_count: Number(a.streak_days)
      });
    }
    var mod = a.module_accuracy || {};
    [['listening', '听力'], ['reading', '阅读'], ['grammar', '语法']].forEach(function (m) {
      var x = mod[m[0]] || {};
      if (Number(x.total || 0) >= 10 && x.rate != null && Number(x.rate) < 0.55) {
        out.push({
          kind: 'error_pattern',
          content: m[1] + '正确率偏低（' + pct(x.rate) + '，共 ' + Number(x.total) + ' 题），需要更多基础练习。',
          confidence: 0.65, evidence_count: Number(x.total)
        });
      }
    });
    return out.slice(0, 4);
  }

  async function generate() {
    if (S.busy) return;
    if (!S.a) return toast('现在读不到学习统计，稍后再试');
    var obs = observations(S.a);
    if (!obs.length) return toast('记录还不够，暂时没有可生成的观察');
    var existing = {};
    S.list.forEach(function (m) { existing[m.content] = 1; });
    var todo = obs.filter(function (o) { return !existing[o.content]; });
    if (!todo.length) return toast('这些观察都已经在了');
    S.busy = true;
    var added = 0, dup = 0, failed = 0;
    for (var i = 0; i < todo.length; i++) {
      try {
        await window.DB.insert('learner_memory', {
          user_id: S.uid, kind: todo[i].kind, content: todo[i].content,
          source: 'inferred', status: 'pending',
          confidence: todo[i].confidence, evidence_count: todo[i].evidence_count
        });
        added++;
      } catch (e) {
        if (postgrestCode(e)) dup++; else failed++;
      }
    }
    S.busy = false;
    if (added) toast('已生成 ' + added + ' 条待确认观察');
    else if (!failed) toast('没有新的观察');
    else toast('生成失败，请稍后重试');
    await load();
  }

  document.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('[data-act]') : null;
    if (!btn) return;
    var act = btn.getAttribute('data-act');
    if (act === 'toggle') return toggle();
    if (act === 'add') return addMemory();
    if (act === 'generate') return generate();
    if (act === 'reload') return load();
    if (btn.id === 'btnLogout') return window.AppAuth.logout();
    var host = btn.closest('[data-id]');
    var m = host ? byId(host.getAttribute('data-id')) : null;
    if (!m) return;
    if (act === 'confirm') return confirmMemory(m);
    if (act === 'ignore') return ignoreMemory(m);
    if (act === 'archive') return archiveMemory(m);
    if (act === 'restore') return restoreMemory(m);
    if (act === 'delete') return deleteMemory(m);
    if (act === 'edit') return editMemory(m);
  });

  document.addEventListener('DOMContentLoaded', load);
  if (document.readyState !== 'loading') load();
})();
