/* ============================================================
 * assets/mistakes.js —— 错题本：查看 / 到期复习 / 标记掌握 / 重新开始复习
 * 数据来源：public.mistakes（RLS 只允许本人读写）
 *   question        题面（单词题是「word /ipa/」；其它题型是原题）
 *   user_answer     当时选错的答案
 *   correct_answer  正确答案（单词题是中文释义）
 *   explain_zh      解析（可能为空）
 *   context         阶段 2 的题目快照（问 AI 用）
 *   resolved        是否在错题本里「已掌握/毕业」
 *
 * 阶段 3：复习调度走独立表 mistake_review（assets/core/mistake-review.js）
 *   · 答对只推进间隔 3/7/14/30 天，连对 4 次才毕业（不是答对一次就掌握）
 *   · 同一道题每个学习日最多复习 2 次（服务端计数，客户端只显示）
 *   · 标记已掌握 = 出库 + 清理调度状态；重新开始复习 = 轮次 +1、重置调度
 *   · 服务端还没执行迁移 016 时自动降级：复习入口隐藏，重做按旧逻辑练习（不计调度）
 *
 * 重做规则：
 *   单词题 + 有足够干扰项 → 四选一
 *   其它题型（或干扰项不足）→ 「先回想再点开答案」自评，避免用别的题的答案拼出无意义选项
 * ============================================================ */
(function () {
  'use strict';

  var S = {
    phase: 'loading',   // loading | error | list | quiz | done
    err: null,
    user: null,
    all: [],
    filter: 'open',     // open | all
    items: [],
    i: 0,
    answers: [],
    feedback: null,     // { ok, chosen, saved, note, attemptInDay, reps, dueDate, graduated }
    revealed: false,
    detail: null,       // 阶段 2：正在看详情的错题（问 AI 用）
    due: { total: 0, items: [] },
    dueMap: {},
    dueErr: null,
    mrUnsupported: false,
    restarting: false,  // 「重新开始复习」进行中，防重复点击
    pending: null,      // 当前题保存失败待重试：{ id, result, clientEventId, chosen }
    pendingList: [],    // 本机未保存的结果（localStorage 持久化，刷新/关页不丢）：[{ id, result, clientEventId, chosen, at }]
    retrying: false     // 「补交未保存结果」进行中，防重复点击
  };

  /* ---- 未保存结果的本地持久化（localStorage，按账号隔离） ----
   * 目的：网络失败时写进本机，刷新或关掉页面后仍能用同一个 client_event_id 重试，
   * 服务端按事件 ID 幂等，所以重试不会重复计次，也不会多占「每天 2 次」的额度。 */
  var PENDING_KEY = 'mr_pending_v1';
  function pendingKey() { return PENDING_KEY + ':' + ((S.user && S.user.id) || 'anon'); }

  function loadPendingList() {
    S.pendingList = [];
    try {
      var raw = window.localStorage.getItem(pendingKey());
      var arr = raw ? JSON.parse(raw) : [];
      if (Array.isArray(arr)) {
        for (var i = 0; i < arr.length; i++) {
          var it = arr[i];
          if (!it || !it.id || !it.clientEventId) continue;
          S.pendingList.push({
            id: String(it.id),
            result: it.result === 'wrong' ? 'wrong' : 'correct',
            clientEventId: String(it.clientEventId),
            chosen: (it.chosen === undefined ? null : it.chosen),
            at: it.at || null
          });
        }
      }
    } catch (e) { S.pendingList = []; }
  }

  function persistPendingList() {
    try {
      if (!S.pendingList.length) { window.localStorage.removeItem(pendingKey()); return; }
      window.localStorage.setItem(pendingKey(), JSON.stringify(S.pendingList));
    } catch (e) { /* 无痕模式/配额满：只在内存里保留，不阻塞本次学习 */ }
  }

  function setPending(p) {
    if (!p) { S.pending = null; return; }
    S.pending = p;
    var found = false;
    for (var i = 0; i < S.pendingList.length; i++) if (S.pendingList[i].id === p.id) { S.pendingList[i] = p; found = true; }
    if (!found) S.pendingList.push(p);
    persistPendingList();
  }

  function clearPending(id) {
    if (!id) return;
    var out = [];
    for (var i = 0; i < S.pendingList.length; i++) if (S.pendingList[i].id !== id) out.push(S.pendingList[i]);
    S.pendingList = out;
    if (S.pending && S.pending.id === id) S.pending = null;
    persistPendingList();
  }

  function pendingFor(id) {
    for (var i = 0; i < S.pendingList.length; i++) if (S.pendingList[i].id === id) return S.pendingList[i];
    return null;
  }

  var KIND_LABEL = { word: '单词', grammar: '语法', listening: '听力', reading: '阅读', speaking: '口语' };

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function dkey(s) { return String(s || '').slice(0, 10); }
  function fmtDay(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || ''));
    if (!m) return '';
    return Number(m[2]) + '月' + Number(m[3]) + '日';
  }
  function norm(s) { return String(s == null ? '' : s).trim().toLowerCase().replace(/\s+/g, ' '); }
  function toast(msg) {
    var t = el('toast'); if (!t) return alert(msg);
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }
  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  function openItems() { return S.all.filter(function (m) { return !m.resolved; }); }
  function findMistake(id) {
    for (var i = 0; i < S.all.length; i++) if (S.all[i].id === id) return S.all[i];
    return null;
  }

  /* ---------- 阶段 2：错题追问上下文 ----------
   * 只允许语法/阅读/听力/周测 AI 题追问（单词题不提供入口）。
   * 新记录带 mistakes.context 快照（原题/选项/答案/解析）；旧记录没快照时只能用已保存的
   * 题面/你的答案/正确答案/解析，页面必须明确提示「原题原文未保存」，不能伪造原文或匹配别的题。
   */
  var ASK_KINDS = { grammar: 1, reading: 1, listening: 1, test: 1 };
  function askKindOf(m) {
    if (m && m.context && m.context.kind && ASK_KINDS[m.context.kind]) return m.context.kind;
    if (m && ASK_KINDS[m.kind]) return m.kind;
    return null;
  }
  function askable(m) { return !!askKindOf(m); }

  function askCtxOf(m) {
    var kind = askKindOf(m);
    if (!kind) return null;
    var text = '';
    var partial = false;
    if (m.context && m.context.text) {
      text = String(m.context.text);
    } else {
      // 旧记录：只有这几个字段是真的保存过的，其它内容一律不编
      var parts = ['模块: ' + (KIND_LABEL[m.kind] || m.kind), '题干: ' + String(m.question || '')];
      if (m.user_answer) parts.push('你的答案: ' + String(m.user_answer));
      if (m.correct_answer) parts.push('正确答案: ' + String(m.correct_answer));
      if (m.explain_zh) parts.push('解答: ' + String(m.explain_zh).slice(0, 220));
      text = parts.join('\n').slice(0, 1500);
      partial = true;
    }
    return {
      kind: kind,
      ref: 'mistake:' + String(m.id),
      title: (m.context && m.context.title) || (KIND_LABEL[m.kind] || '错题'),
      context: text.slice(0, 1500),
      partial: partial
    };
  }

  function renderDetail() {
    var m = S.detail;
    if (!m) { S.phase = 'list'; return renderList(); }
    var ctx = askCtxOf(m);
    var h = [];
    h.push('<div class="card">');
    h.push('<div class="rowline"><span class="pill grey">' + esc(KIND_LABEL[m.kind] || m.kind) + '</span><span class="muted small">' + dkey(m.created_at) + '</span><span class="spacer"></span><button class="btn sm ghost" data-act="backlist">返回</button></div>');
    h.push('<p style="margin:12px 0 6px;font-weight:600;font-size:18px;line-height:1.6">' + esc(m.question) + '</p>');
    h.push('<div class="muted small">你的答案：' + esc(m.user_answer || '—') + '　正确：' + esc(m.correct_answer || '—') + '</div>');
    if (m.explain_zh) h.push('<div class="muted small" style="margin-top:4px">解析：' + esc(m.explain_zh) + '</div>');
    if (ctx && ctx.partial) h.push('<div class="note blue mt12"><div class="small">这条错题是旧版本记录的，没有保存原题原文和选项。下面只能依据已保存的题面、答案和解析提问，不会编造原文。</div></div>');
    h.push('</div>');
    el('view').innerHTML = h.join('');
    if (ctx && window.AskUI && window.AskUI.mount) {
      try { window.AskUI.mount(el('view'), { kind: ctx.kind, ref: ctx.ref, title: ctx.title, context: ctx.context }); } catch (e) {}
    }
  }

  function openAsk(id) {
    var m = findMistake(id);
    if (!m) { toast('没找到这条错题'); return; }
    if (!askable(m)) { toast('这类错题暂不支持 AI 追问'); return; }
    S.detail = m; S.phase = 'detail';
    renderDetail();
  }

  /* ---------- 列表 ---------- */
  function reviewLine(m) {
    var r = S.dueMap[m.id];
    if (!r) return '';
    if (r.consecutiveWrong > 0) return '连续答错 ' + r.consecutiveWrong + ' 次 · 今天到期';
    if (r.reps > 0) return '已连对 ' + r.reps + '/4 · 下次复习 ' + (fmtDay(r.dueDate) || '—');
    return '今天到期 · 还没开始复习';
  }

  function renderList() {
    var open = openItems();
    var list = (S.filter === 'all' ? S.all : open).slice(0, 60);
    var dueN = S.due.total || 0;
    var h = [];
    h.push('<div class="v2-pagehead"><p class="v2-eyebrow">Review &amp; repair</p><h1 class="v2-h1">错题本</h1><p>答错的题会自动收进来，按间隔重复再练；连续答对 4 次才算掌握。</p></div>');
    h.push('<div class="card">');
    h.push('<div class="rowline"><h2 style="margin:0">复习进度</h2><span class="muted small">共 ' + S.all.length + ' 条 · 未掌握 ' + open.length + ' 条</span></div>');
    if (S.mrUnsupported) {
      h.push('<p class="muted small" style="margin:8px 0 0">答错的题会自动记在这里；重做答对就标记「已掌握」，以后不再出现。（复习计划需要服务端更新后才启用，现在先按这个简单规则。）</p>');
    } else {
      h.push('<p class="muted small" style="margin:8px 0 0">答错的题会按复习计划再出现：答对后第 3、7、14、30 天各复习一次，连续答对 4 次才算掌握；同一道题每天最多复习 2 次。</p>');
    }
    h.push('<div class="row mt12">');
    if (!S.mrUnsupported && dueN > 0) {
      h.push('<button class="btn" data-act="redo">开始复习（今天到期 ' + dueN + ' 题）</button>');
    } else {
      h.push('<button class="btn" data-act="redo"' + (open.length ? '' : ' disabled') + '>练习错题（最多 10 题）</button>');
    }
    h.push('<a class="btn ghost" href="stats.html">回统计</a>');
    h.push('</div>');
    if (!S.mrUnsupported && dueN > 0) {
      h.push('<p class="muted small" style="margin:8px 0 0">今天没有到期的错题时，也可以用「练习错题」随便练，练习不计入复习计划。</p>');
    }
    if (S.dueErr) h.push('<p class="muted small warn-text" style="margin:8px 0 0">' + esc(S.dueErr) + '</p>');
    if (S.pendingList.length) {
      h.push('<div class="note blue mt12"><div class="small">有 ' + S.pendingList.length + ' 条复习结果还没存到服务器（当时网络断了）。用原来的提交编号补交，不会重复计次。</div><div class="row mt8"><button class="btn sm" data-act="retryall"' + (S.retrying ? ' disabled' : '') + '>' + (S.retrying ? '正在补交…' : '补交未保存的结果') + '</button></div></div>');
    }
    h.push('<div class="row mt8">');
    h.push('<button class="btn sm ' + (S.filter === 'open' ? '' : 'ghost') + '" data-act="filter:open">未掌握（' + open.length + '）</button>');
    h.push('<button class="btn sm ' + (S.filter === 'all' ? '' : 'ghost') + '" data-act="filter:all">全部（' + S.all.length + '）</button>');
    h.push('</div>');
    h.push('</div>');

    if (!S.all.length) {
      h.push('<div class="card"><p class="muted">还没有错题。去「今日」或「测试」做题，答错的题会自动记到这里。</p></div>');
    } else if (!list.length) {
      h.push('<div class="card"><p class="muted">没有未掌握的错题了，很不错。切到「全部」可以回看历史错题。</p></div>');
    } else {
      h.push('<div class="card">');
      list.forEach(function (m) {
        var rv = m.resolved ? '' : reviewLine(m);
        h.push('<div class="kwrow" style="padding:10px 0">');
        h.push('<div class="rowline"><b>' + esc(m.question) + '</b><span class="pill grey">' + esc(KIND_LABEL[m.kind] || m.kind) + '</span></div>');
        h.push('<div class="muted small" style="margin-top:4px">你的答案：' + esc(m.user_answer || '—') + '　正确：' + esc(m.correct_answer || '—') + '</div>');
        if (m.explain_zh) h.push('<div class="muted small" style="margin-top:2px">解析：' + esc(m.explain_zh) + '</div>');
        if (rv) h.push('<div class="muted small" style="margin-top:2px">复习：' + esc(rv) + '</div>');
        h.push('<div class="rowline" style="margin-top:6px"><span class="muted small">' + dkey(m.created_at) + '</span>');
        if (m.resolved) {
          h.push('<span class="pill">已掌握</span>');
          h.push('<button class="btn sm ghost" data-act="startreview:' + esc(m.id) + '">重新开始复习</button>');
        } else {
          h.push('<button class="btn sm ghost" data-act="master:' + esc(m.id) + '">标记已掌握</button>');
        }
        if (askable(m)) h.push('<button class="btn sm ghost" data-act="ask:' + esc(m.id) + '">问问 AI</button>');
        h.push('</div></div>');
      });
      h.push('</div>');
    }
    el('view').innerHTML = h.join('');
  }

  /* ---------- 重做 / 复习 ---------- */
  var WORD_MEANINGS = null;
  async function loadWordMeanings() {
    if (WORD_MEANINGS) return WORD_MEANINGS;
    try {
      var rows = await window.DB.select('words', { limit: 120 });
      WORD_MEANINGS = (rows || []).map(function (w) { return w && w.meaning; }).filter(function (s) { return s && String(s).trim(); });
    } catch (e) {
      WORD_MEANINGS = [];
    }
    return WORD_MEANINGS;
  }

  function pickDistractors(item, n, extraPool) {
    var out = [], seen = {};
    seen[norm(item.correct_answer)] = 1;
    var pool = [];
    S.all.forEach(function (m) { if (m.correct_answer) pool.push(m.correct_answer); });
    (extraPool || []).forEach(function (s) { pool.push(s); });
    pool = shuffle(pool);
    for (var i = 0; i < pool.length && out.length < n; i++) {
      var k = norm(pool[i]);
      if (!k || seen[k]) continue;
      seen[k] = 1;
      out.push(pool[i]);
    }
    return out;
  }

  function buildItem(m, extraMeanings, scheduled) {
    var it = {
      id: m.id, kind: m.kind, question: m.question,
      correct: m.correct_answer || '', userAnswer: m.user_answer || '', explain: m.explain_zh || '',
      mode: 'recall', options: [], scheduled: !!scheduled,
      contextText: ''
    };
    // 原题快照（阶段2 存进 mistakes.context.text）里包含原文/选项/题干，也包含「正确答案」「你的答案」「解答」。
    // 复习时先只暴露不给答案的部分，阅读/听力题才有原文可读；答案在作答后由反馈区展示。
    if (m.context && m.context.text) {
      var kept = [];
      String(m.context.text).split('\n').forEach(function (line) {
        var t = String(line).trim();
        if (!t) return;
        if (/^(正确答案|你的答案|解答)\s*[:：]/.test(t)) return;
        kept.push(t);
      });
      it.contextText = kept.join('\n');
    }
    if (m.kind === 'word' && m.correct_answer) {
      var dis = pickDistractors(m, 3, extraMeanings);
      if (dis.length >= 3) {
        it.mode = 'choice';
        it.options = shuffle([m.correct_answer].concat(dis));
      }
    }
    return it;
  }

  async function startRedo() {
    var scheduled = [];
    var pool = [];
    if (!S.mrUnsupported && S.due.items.length) {
      for (var i = 0; i < S.due.items.length; i++) {
        var d = S.due.items[i];
        var m = findMistake(d.mistakeId);
        if (m) scheduled.push(m);
        else if (d.question) scheduled.push({ id: d.mistakeId, kind: d.kind, question: d.question, user_answer: d.userAnswer, correct_answer: d.correctAnswer, explain_zh: d.explainZh, context: d.context, created_at: d.createdAt, resolved: false, _fromDue: true });
      }
      // 服务端已按 p_limit=10 只返回 10 道，这里不再截断（避免「先取 30 再切片」）
      pool = scheduled;
    } else {
      pool = shuffle(openItems().slice()).slice(0, 10);
    }
    if (!pool.length) { toast('今天没有到期错题，也没有可练习的错题'); return; }
    var needWord = pool.some(function (m) { return m.kind === 'word'; });
    var extra = needWord ? await loadWordMeanings() : [];
    S.items = pool.map(function (m) { return buildItem(m, extra, scheduled.length > 0); });
    S.i = 0; S.answers = []; S.feedback = null; S.revealed = false; S.pending = null;
    S.phase = 'quiz';
    renderQuiz();
  }

  function todayYmd() {
    var d = new Date();
    var m = ('0' + (d.getMonth() + 1)).slice(-2);
    var dd = ('0' + d.getDate()).slice(-2);
    return String(d.getFullYear()) + '-' + m + '-' + dd;
  }

  function dueNote(fb) {
    if (!fb || fb.saved !== 'ok') return '';
    if (fb.graduated) return '已从错题本毕业：连续答对 4 次，以后不再进入复习计划。';
    if (fb.ok) {
      var s = '下次复习：' + (fmtDay(fb.dueDate) || '—');
      if (fb.intervalDays) s += '（' + fb.intervalDays + ' 天后）';
      s += '　已连对 ' + (fb.reps || 0) + '/4';
      return s;
    }
    if (fb.attemptInDay >= 2) return '今天这题已经复习 2 次，明天再练。';
    if (fb.dueDate && String(fb.dueDate) <= todayYmd()) return '今天还会再出现 1 次，等会儿再答一次。';
    return '明天再练一次。';
  }

  function renderQuiz() {
    var it = S.items[S.i];
    if (!it) return renderDone();
    // 上次没保存成功的结果（刷新/关页后仍在 localStorage 里）：重新展示成「待重试」状态，复用同一提交编号
    if (!S.feedback && it.scheduled) {
      var pv = pendingFor(it.id);
      if (pv) {
        S.pending = pv;
        S.feedback = { ok: pv.result === 'correct', chosen: pv.chosen, saved: 'failed',
          note: '这道题上次的结果还没保存成功，点下面「重试保存」用同一个提交编号补交，不会重复计次。' };
      }
    }
    var h = [];
    h.push('<div class="card">');
    h.push('<div class="rowline"><span class="pill grey">第 ' + (S.i + 1) + ' / ' + S.items.length + ' 题</span><span class="pill">' + esc(KIND_LABEL[it.kind] || it.kind) + '</span><span class="pill grey">' + (it.scheduled ? '到期复习' : '练习（不计计划）') + '</span><span class="spacer"></span><button class="btn sm ghost" data-act="quit">退出</button></div>');
    h.push('<p style="margin:12px 0 6px;font-weight:600;font-size:18px;line-height:1.6">' + esc(it.question) + '</p>');
    // 原文/选项：只在这类题「不适合四选一」时展示，避免把单词题的原选项（含正确答案）露出来
    if (it.mode !== 'choice' && it.contextText) {
      h.push('<details class="note grey" style="margin-top:6px"><summary class="small">原题上下文（原文 / 选项）</summary>' +
        '<div class="small" style="white-space:pre-wrap;margin-top:6px;max-height:240px;overflow:auto">' + esc(it.contextText) + '</div></details>');
    }

    if (it.mode === 'choice') {
      if (!S.feedback) {
        h.push('<p class="muted small" style="margin:0 0 10px">选出它的正确意思。</p>');
        it.options.forEach(function (opt, idx) {
          h.push('<button class="opt" data-act="pick:' + idx + '"><span class="k">' + 'ABCD'[idx] + '</span><span>' + esc(opt) + '</span></button>');
        });
      }
    } else {
      if (!S.revealed && !S.feedback) {
        h.push('<p class="muted small" style="margin:0 0 10px">先自己回想一下答案（这题不适合做四选一），想好再点开对照。</p>');
        h.push('<button class="btn block" data-act="reveal">看正确答案</button>');
      }
    }

    if (S.feedback) {
      var fb = S.feedback;
      h.push('<div class="note ' + (fb.ok ? '' : 'blue') + '" style="margin-top:12px">');
      var title = fb.ok ? '回答正确 ✅' : '这次没答对';
      if (fb.saved === 'saving') title += ' · 正在保存…';
      else if (fb.saved === 'failed') title += ' · 结果没保存成功';
      else if (fb.saved === 'blocked') title += ' · 今天不能再练';
      else if (fb.saved === 'practice') title += '（练习，不计复习计划）';
      else if (fb.graduated) title = '回答正确 ✅ 已毕业';
      h.push('<div style="font-weight:700">' + title + '</div>');
      if (fb.chosen != null) h.push('<div class="small" style="margin-top:4px">你的答案：' + esc(fb.chosen) + '</div>');
      h.push('<div class="small" style="margin-top:2px">正确答案：' + esc(it.correct || '—') + '</div>');
      if (it.explain) h.push('<div class="small" style="margin-top:2px">解析：' + esc(it.explain) + '</div>');
      var dn = dueNote(fb);
      if (dn) h.push('<div class="small" style="margin-top:6px;font-weight:600">' + esc(dn) + '</div>');
      if (fb.note) h.push('<div class="small" style="margin-top:4px">' + esc(fb.note) + '</div>');
      if (fb.saved === 'failed' && S.pending) h.push('<div class="small" style="margin-top:6px">这次结果还没存到服务器，点下面按钮用同一个提交编号重试，不会重复计次。</div>');
      h.push('</div>');
      h.push('<div class="row mt12">');
      if (fb.saved === 'failed' && S.pending) h.push('<button class="btn" data-act="retrysave">重试保存</button>');
      if (fb.saved !== 'saving') h.push('<button class="btn ' + (fb.saved === 'failed' ? 'ghost' : '') + '" data-act="next">' + (S.i + 1 >= S.items.length ? '看本轮结果' : '下一题') + '</button>');
      h.push('</div>');
    } else if (S.revealed) {
      h.push('<div class="note" style="margin-top:12px"><div class="small">正确答案：<b>' + esc(it.correct || '—') + '</b></div>' +
        (it.explain ? '<div class="small" style="margin-top:2px">解析：' + esc(it.explain) + '</div>' : '') + '</div>');
      h.push('<div class="row mt12">');
      h.push('<button class="btn" data-act="self:1">我答对了</button>');
      h.push('<button class="btn ghost" data-act="self:0">还没记住</button>');
      h.push('</div>');
    }
    h.push('</div>');
    el('view').innerHTML = h.join('');
  }

  /* ---------- 标记掌握 / 重新开始复习 ---------- */
  async function markMastered(id) {
    var res = null;
    try { res = await window.MistakeReview.setMastered(id, true); } catch (e) { res = { ok: false, code: 'error', message: (e && e.message) || '未知错误' }; }
    if (res && res.ok) {
      var m = findMistake(id);
      if (m) m.resolved = true;
      delete S.dueMap[id];
      await refreshDue();
      return true;
    }
    if (res && res.code === 'unsupported') {
      // 服务端还没执行迁移 016：退回旧规则，只改 mistakes.resolved
      try {
        await window.DB.update('mistakes', { resolved: true }, { id: id, user_id: S.user.id });
        var m2 = findMistake(id);
        if (m2) m2.resolved = true;
        return true;
      } catch (e2) {
        toast('标记失败：' + (e2 && e2.message ? e2.message : '未知错误'));
        return false;
      }
    }
    toast('标记失败：' + (res && res.message ? res.message : '未知错误'));
    return false;
  }

  async function restartReview(id) {
    // 防重复点击：同一时间只允许一次「重新开始」，服务端也是幂等的（重复点击不会多加轮次）
    if (S.restarting) return false;
    S.restarting = true;
    try {
      var res = null;
      try { res = await window.MistakeReview.setMastered(id, false); } catch (e) { res = { ok: false, code: 'error', message: (e && e.message) || '未知错误' }; }
      if (res && res.ok) {
        var m = findMistake(id);
        if (m) m.resolved = false;
        if (res.idempotent) toast('已经重新开始过这一轮复习，直接继续即可');
        await refreshDue();
        return true;
      }
      if (res && res.code === 'unsupported') {
        try {
          await window.DB.update('mistakes', { resolved: false }, { id: id, user_id: S.user.id });
          var m2 = findMistake(id);
          if (m2) m2.resolved = false;
          return true;
        } catch (e2) {
          toast('操作失败：' + (e2 && e2.message ? e2.message : '未知错误'));
          return false;
        }
      }
      toast('操作失败：' + (res && res.message ? res.message : '未知错误'));
      return false;
    } finally {
      S.restarting = false;
    }
  }

  async function refreshDue() {
    if (S.mrUnsupported) return;
    var d = null;
    // 只取 10 道（与服务端 p_limit 约定一致）；total_due 由服务端独立统计，不受条数限制影响
    try { d = await window.MistakeReview.due(10); } catch (e) { d = { ok: false, code: 'error', message: (e && e.message) || '读取到期错题失败' }; }
    if (d && d.ok) {
      S.due = { total: d.total, items: d.items || [] };
      S.dueMap = {};
      for (var i = 0; i < S.due.items.length; i++) {
        var it = S.due.items[i];
        S.dueMap[it.mistakeId] = { reps: it.reps, dueDate: it.dueDate, consecutiveWrong: it.consecutiveWrong };
      }
      S.dueErr = null;
    } else if (d && d.code === 'unsupported') {
      S.mrUnsupported = true;
      S.due = { total: 0, items: [] };
      S.dueMap = {};
    } else {
      S.dueErr = (d && d.message) || '读取复习计划失败（不影响看错题）';
    }
  }

  /* ---------- 提交复习结果 ---------- */
  async function submitReview(it, ok, chosen) {
    var result = ok ? 'correct' : 'wrong';
    var eid = window.MistakeReview.newEventId();
    S.feedback = { ok: ok, chosen: chosen, saved: it.scheduled ? 'saving' : 'practice',
      attemptInDay: 0, reps: 0, dueDate: null, graduated: false, intervalDays: null };
    S.answers.push({ id: it.id, ok: ok });
    S.pending = null;
    renderQuiz();
    if (!it.scheduled) { renderQuiz(); return; }
    if (S.mrUnsupported) {
      S.feedback.saved = 'practice';
      S.feedback.note = '复习计划还没启用（服务端未更新），这次只当作练习。';
      renderQuiz();
      return;
    }
    var r = await window.MistakeReview.complete(it.id, result, eid);
    if (r && r.ok && r.alreadyResolved) {
      // 服务端已把这道题判为「已掌握」：不再写入任何复习事件，也不再改调度
      S.feedback.saved = 'blocked';
      clearPending(it.id);
      S.feedback.note = '这道题已经标记为已掌握，不需要再复习；想重练请点「重新开始复习」。';
      delete S.dueMap[it.id];
      S.due.total = Math.max(0, (S.due.total || 0) - 1);
      renderQuiz();
      return;
    }
    if (r && r.ok) {
      clearPending(it.id);
      S.feedback.saved = 'ok';
      S.feedback.attemptInDay = r.attemptInDay || 0;
      S.feedback.reps = r.reps || 0;
      S.feedback.dueDate = r.dueDate || null;
      S.feedback.intervalDays = r.intervalDays;
      S.feedback.graduated = !!r.graduated;
      if (r.graduated) {
        it.graduated = true;
        var gm = findMistake(it.id);
        if (gm) gm.resolved = true;   // 毕业后本地也立即算「已掌握」，列表不再显示复习行
        delete S.dueMap[it.id];
        S.due.total = Math.max(0, (S.due.total || 0) - 1);
      } else if (r.dueDate) {
        S.dueMap[it.id] = { reps: r.reps || 0, dueDate: r.dueDate, consecutiveWrong: r.consecutiveWrong || 0 };
        if (r.attemptInDay >= 2) S.due.total = Math.max(0, (S.due.total || 0) - 1);
      }
    } else if (r && r.terminal) {
      // 服务端硬限制（今天已 2 次 / 还没到期）：不可重试，不当成网络失败排队
      S.feedback.saved = 'blocked';
      clearPending(it.id);
      S.feedback.note = (r && r.message) ? String(r.message) : '这道题今天不能再练了。';
      delete S.dueMap[it.id];
      S.due.total = Math.max(0, (S.due.total || 0) - 1);
    } else {
      S.feedback.saved = 'failed';
      setPending({ id: it.id, result: result, clientEventId: (r && r.clientEventId) || eid, chosen: chosen, at: new Date().toISOString() });
      S.feedback.note = (r && r.message) ? String(r.message) : '这次结果没保存成功，可以点重试。';
    }
    renderQuiz();
  }

  async function retrySave() {
    if (!S.pending) return;
    var p = S.pending;
    S.feedback.saved = 'saving';
    S.feedback.note = '';
    renderQuiz();
    var r = await window.MistakeReview.complete(p.id, p.result, p.clientEventId);
    if (r && r.ok && r.alreadyResolved) {
      S.feedback.saved = 'blocked';
      clearPending(p.id);
      S.feedback.note = '这道题已经标记为已掌握，不需要再复习；想重练请点「重新开始复习」。';
      delete S.dueMap[p.id];
      S.due.total = Math.max(0, (S.due.total || 0) - 1);
      renderQuiz();
      return;
    }
    if (r && r.ok) {
      clearPending(p.id);
      S.feedback.saved = 'ok';
      S.feedback.attemptInDay = r.attemptInDay || 0;
      S.feedback.reps = r.reps || 0;
      S.feedback.dueDate = r.dueDate || null;
      S.feedback.intervalDays = r.intervalDays;
      S.feedback.graduated = !!r.graduated;
      if (r.graduated) {
        var gm2 = findMistake(p.id);
        if (gm2) gm2.resolved = true;
        delete S.dueMap[p.id];
        S.due.total = Math.max(0, (S.due.total || 0) - 1);
      }
      clearPending(p.id);
    } else if (r && r.terminal) {
      S.feedback.saved = 'blocked';
      clearPending(p.id);
      S.feedback.note = (r && r.message) ? String(r.message) : '这道题今天不能再练了。';
      delete S.dueMap[p.id];
      S.due.total = Math.max(0, (S.due.total || 0) - 1);
    } else {
      S.feedback.saved = 'failed';
      S.feedback.note = (r && r.message) ? String(r.message) : '还是没保存成功，检查网络后再试。';
    }
    renderQuiz();
  }

  /* 把本机所有没保存成功的结果按各自原提交编号补交（服务端幂等，重复调用不会重复计次）。 */
  async function retryAllPending() {
    if (S.retrying) return;
    if (!S.pendingList.length) { toast('没有需要补交的结果'); return; }
    S.retrying = true;
    renderList();
    var list = S.pendingList.slice();
    var done = 0, rejected = 0, failed = 0, authBlocked = 0, conflictBlocked = 0;
    for (var i = 0; i < list.length; i++) {
      var p = list[i];
      var r = await window.MistakeReview.complete(p.id, p.result, p.clientEventId);
      if (r && r.ok) { clearPending(p.id); done++; }
      // 服务端明确拒绝（今天已满 2 次 / 还没到期）或错题已被删除：清掉无效记录，但单独计为「拒绝」，不算补交成功
      else if (r && (r.terminal || r.code === 'not_found')) { clearPending(p.id); rejected++; }
      // 登录过期：服务端根本没受理，不能当成补交成功，保留记录等重新登录后再补
      else if (r && r.code === 'auth') { authBlocked++; }
      // 提交编号被占用但内容对不上：不能删本地记录，也不能算成功，保留待人工核对
      else if (r && r.code === 'conflict') { conflictBlocked++; }
      else failed++;
    }
    S.retrying = false;
    await refreshDue();
    renderList();
    if (authBlocked) {
      toast('登录状态已过期，待补交记录仍保留在本机，请重新登录后再点「补交未保存的结果」');
    } else if (conflictBlocked) {
      toast('存在提交编号冲突，记录已保留，请刷新页面后核对，不要直接删');
    } else if (failed || rejected) {
      toast('成功处理 ' + done + ' 条，服务端拒绝 ' + rejected + ' 条，另有 ' + failed + ' 条失败');
    } else {
      toast('未保存的 ' + done + ' 条结果已确认处理');
    }
  }

  function choose(idx) {
    if (S.feedback) return;
    var it = S.items[S.i];
    var chosen = it.options[idx];
    var ok = norm(chosen) === norm(it.correct);
    submitReview(it, ok, chosen);
  }

  function selfMark(ok) {
    if (S.feedback) return;
    submitReview(S.items[S.i], !!ok, null);
  }

  function next() {
    S.feedback = null; S.revealed = false; S.pending = null;
    S.i += 1;
    if (S.i >= S.items.length) {
      // 收尾前重新拉一次到期列表，确保「还有 N 道」是服务端最新值
      refreshDue().then(function () { renderDone(); }, function () { renderDone(); });
      return;
    }
    renderQuiz();
  }

  function renderDone() {
    var ok = S.answers.filter(function (a) { return a.ok; }).length;
    var n = S.answers.length;
    var h = [];
    h.push('<div class="card">');
    h.push('<h2 style="margin:0">本轮复习完成</h2>');
    h.push('<p class="muted" style="margin:8px 0 0">共 ' + n + ' 题，答对 ' + ok + ' 题' + (n ? '（正确率 ' + Math.round(ok * 100 / n) + '%）' : '') + '。</p>');
    h.push('<p class="muted small" style="margin:6px 0 0">答对的题已按 3/7/14/30 天安排下次复习，连续答对 4 次才从错题本毕业；答错的今天还会再出现 1 次（每天最多 2 次）。</p>');
    if (S.due && S.due.total) h.push('<p class="muted small" style="margin:6px 0 0">还有 ' + S.due.total + ' 道到期错题，回错题本点「开始重做」可继续下一组（每组最多 10 题）。</p>');
    h.push('<div class="row mt12"><button class="btn" data-act="back">回错题本</button><a class="btn ghost block" href="today.html">去今日学习</a></div>');
    h.push('</div>');
    el('view').innerHTML = h.join('');
  }

  /* ---------- 加载 ---------- */
  async function load(showLoading) {
    if (showLoading) { S.phase = 'loading'; renderLoading(); }
    try {
      var user = await window.AppAuth.requireLogin();
      if (!user) return;
      S.user = user;
      loadPendingList();
      el('userName').textContent = (window.AppAuth.displayName(user) || '') + ' · 已登录';
      S.all = await window.DB.select('mistakes', { user_id: user.id, order: 'created_at.desc', limit: 200 });
      await refreshDue();
      S.phase = 'list';
      S.detail = null;
      renderList();
      // 从复习页「去复习错题」进来（mistakes.html?due=1）：直接开始到期复习，并把参数从地址栏去掉
      if (showLoading && String(location.search || '').indexOf('due=1') !== -1) {
        try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) {}
        if (!S.mrUnsupported && S.due.total > 0) return startRedo();
      }
    } catch (e) {
      S.phase = 'error';
      S.err = (e && e.message) || String(e);
      el('view').innerHTML = '<div class="card"><p class="warn-text">读取失败：' + esc(S.err) + '</p><div class="row mt8"><button class="btn ghost block" data-act="reload">重试</button></div></div>';
    }
  }

  function renderLoading() {
    el('view').innerHTML = '<div class="card"><p class="muted">正在读取错题…</p></div>';
  }

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'reload') return load(true);
    if (act === 'redo') return startRedo();
    if (act === 'quit') { S.phase = 'list'; S.feedback = null; S.revealed = false; S.pending = null; return renderList(); }
    if (act === 'backlist') { S.phase = 'list'; S.detail = null; return renderList(); }
    if (act.indexOf('ask:') === 0) return openAsk(act.slice(4));
    if (act === 'back') { S.phase = 'list'; S.answers = []; return load(false); }
    if (act === 'next') return next();
    if (act === 'retrysave') return retrySave();
    if (act === 'retryall') return retryAllPending();
    if (act === 'reveal') { S.revealed = true; return renderQuiz(); }
    if (act.indexOf('filter:') === 0) { S.filter = act.slice(7); return renderList(); }
    if (act.indexOf('master:') === 0) {
      var mid = act.slice(7);
      markMastered(mid).then(function (ok) { if (ok) { toast('已标记掌握，不再进入复习计划'); renderList(); } });
      return;
    }
    if (act.indexOf('startreview:') === 0) {
      var rid = act.slice(12);
      restartReview(rid).then(function (ok) { if (ok) { toast('已重新加入复习，今天到期'); renderList(); } });
      return;
    }
    if (act.indexOf('pick:') === 0) return choose(Number(act.slice(5)));
    if (act.indexOf('self:') === 0) return selfMark(act.slice(5) === '1');
  });

  var btnLogout = document.getElementById('btnLogout');
  if (btnLogout) btnLogout.addEventListener('click', function () { window.AppAuth.logout(); });
  window.addEventListener('error', function (e) { toast('页面脚本错误：' + (e && e.message ? e.message : '未知')); });
  window.addEventListener('unhandledrejection', function (e) { toast('请求失败：' + ((e && e.reason && e.reason.message) || '未知')); });

  function boot() { load(true); }
  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();
})();
