/* assets/core/md.js —— 轻量 Markdown 渲染（安全版，零依赖）
 *
 * 目的：AI 回答里的加粗、标题、列表、引用、代码渲染成真正的样式，用户不再看到 ** 这类源码符号。
 * 安全：只创建 DOM 节点、所有文本走 textContent，全文件不使用 innerHTML，
 *       因此不解析任何 HTML 标签，<img onerror>、<script> 之类只会当普通文字显示。
 * 流式：渲染是幂等的（每次用完整累积文本重画），opts.streaming=true 时会隐藏还没闭合的标记，
 *       避免用户长时间盯着 "**" 或没闭合的代码围栏。
 */
(function () {
  'use strict';

  var MAX = 20000;
  var FENCE = /^\s*\x60{3,}\s*([A-Za-z0-9_+-]*)\s*$/;
  var FENCE_ANY = /^\s*\x60{3,}/;

  function txt(s) { return document.createTextNode(s); }

  // 行内：**粗体**、*斜体*、`代码`；没有闭合的标记当普通文字（不会吞内容）
  function inline(host, s) {
    var re = /(\*\*([^*]+)\*\*|\x60([^\x60\n]+)\x60|\*([^*\n]+)\*)/g;
    var last = 0, m;
    while ((m = re.exec(s))) {
      if (m.index > last) host.appendChild(txt(s.slice(last, m.index)));
      if (m[2] != null) {
        var b = document.createElement('strong');
        b.appendChild(txt(m[2]));
        host.appendChild(b);
      } else if (m[3] != null) {
        var c = document.createElement('code');
        c.appendChild(txt(m[3]));
        host.appendChild(c);
      } else {
        var em = document.createElement('em');
        em.appendChild(txt(m[4]));
        host.appendChild(em);
      }
      last = re.lastIndex;
    }
    if (last < s.length) host.appendChild(txt(s.slice(last)));
    return host;
  }

  // 流式：把还没闭合的标记从“显示文本”里摘掉，等闭合后再按格式显示
  function hideDangling(s) {
    // 1) 未闭合的代码围栏：交给块解析整段当代码块，这里不动
    var fenceLines = 0;
    s.split(/\r\n|\r|\n/).forEach(function (ln) { if (FENCE_ANY.test(ln)) fenceLines++; });
    if (fenceLines % 2 === 1) return s;
    // 2) 未闭合的 ** ：去掉悬空的那个标记，后面的文字先按普通文字显示
    var bold = (s.match(/\*\*/g) || []).length;
    if (bold % 2 === 1) {
      var i2 = s.lastIndexOf('**');
      if (i2 >= 0) s = s.slice(0, i2) + s.slice(i2 + 2);
    }
    // 3) 未闭合的 *斜体*
    var stars = (s.replace(/\*\*/g, "").match(/\*/g) || []).length;
    if (stars % 2 === 1) {
      var i3 = s.lastIndexOf('*');
      if (i3 >= 0) s = s.slice(0, i3) + s.slice(i3 + 1);
    }
    // 4) 未闭合的行内代码
    var ticks = (s.match(/\x60/g) || []).length;
    if (ticks % 2 === 1) {
      var i4 = s.lastIndexOf('\x60');
      if (i4 >= 0) s = s.slice(0, i4) + s.slice(i4 + 1);
    }
    return s;
  }

  function isBlockStart(line) {
    return /^\s*(#{1,6}\s|>|[-*+]\s|\d+[.)]\s)/.test(line) || FENCE_ANY.test(line) || /^\s*([-*_])\1{2,}\s*$/.test(line);
  }

  function render(el, text, opts) {
    if (!el) return el;
    opts = opts || {};
    var s = String(text == null ? "" : text).slice(0, MAX);
    if (opts.streaming) s = hideDangling(s);
    while (el.firstChild) el.removeChild(el.firstChild);
    var root = document.createElement("div");
    root.className = "md";
    var lines = s.split(/\r\n|\r|\n/);
    var i = 0;
    while (i < lines.length) {
      var line = lines[i];
      if (/^\s*$/.test(line)) { i++; continue; }
      var m;
      // 标题
      if ((m = /^\s*(#{1,6})\s+(.*)$/.exec(line))) {
        var lv = m[1].length;
        var tag = lv === 1 ? "h3" : (lv === 2 ? "h4" : "h5");
        var h = document.createElement(tag);
        h.className = "md-h md-h" + Math.min(3, lv);
        inline(h, m[2].trim());
        root.appendChild(h);
        i++; continue;
      }
      // 代码围栏
      if (FENCE_ANY.test(line)) {
        var buf = [];
        i++;
        while (i < lines.length && !FENCE_ANY.test(lines[i])) { buf.push(lines[i]); i++; }
        if (i < lines.length) i++; // 跳过结束围栏
        var pre = document.createElement("pre");
        var code = document.createElement("code");
        code.appendChild(txt(buf.join("\n")));
        pre.appendChild(code);
        root.appendChild(pre);
        continue;
      }
      // 分隔线
      if (/^\s*([-*_])\1{2,}\s*$/.test(line)) {
        root.appendChild(document.createElement("hr"));
        i++; continue;
      }
      // 引用
      if (/^\s*>/.test(line)) {
        var q = document.createElement("blockquote");
        var qbuf = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) { qbuf.push(lines[i].replace(/^\s*>\s?/, "")); i++; }
        qbuf.forEach(function (seg, k) {
          if (k) q.appendChild(document.createElement("br"));
          inline(q, seg);
        });
        root.appendChild(q);
        continue;
      }
      // 无序列表
      if (/^\s*[-*+]\s+/.test(line)) {
        var ul = document.createElement("ul");
        while (i < lines.length && /^\s*[-*+]\s+/.test(lines[i])) {
          var li = document.createElement("li");
          inline(li, lines[i].replace(/^\s*[-*+]\s+/, ""));
          ul.appendChild(li); i++;
        }
        root.appendChild(ul);
        continue;
      }
      // 有序列表
      if (/^\s*\d+[.)]\s+/.test(line)) {
        var ol = document.createElement("ol");
        while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) {
          var li2 = document.createElement("li");
          inline(li2, lines[i].replace(/^\s*\d+[.)]\s+/, ""));
          ol.appendChild(li2); i++;
        }
        root.appendChild(ol);
        continue;
      }
      // 普通段落：连续行用 <br> 软换行
      var p = document.createElement("p");
      var first = true;
      while (i < lines.length && !/^\s*$/.test(lines[i]) && !isBlockStart(lines[i])) {
        if (!first) p.appendChild(document.createElement("br"));
        inline(p, lines[i]);
        first = false;
        i++;
      }
      root.appendChild(p);
    }
    // 外层包一层，避免把 .bubble/.askb 自己的样式冲掉
    el.appendChild(root);
    return el;
  }

  function renderText(el, text) { return render(el, text, { streaming: false }); }

  window.MD = { render: render, renderText: renderText, _hideDangling: hideDangling };
})();
