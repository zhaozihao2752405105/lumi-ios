// PWA：注册 Service Worker + 引导加入主屏
(function () {
  'use strict';
  var VERSION = 'v52';
  // 旧标签页继续跑旧 Service Worker 时，页面已加载的 CSS/JS 也是旧的。
  // sw.js 已 skipWaiting + clients.claim；这里只给一个明确的刷新入口，避免用户以为
  // 新 UI 没上线，也避免在答题中途强制 reload。
  var hadController = !!(navigator.serviceWorker && navigator.serviceWorker.controller);
  function showUpdateToast() {
    if (!hadController || document.getElementById('lumi-update-toast')) return;
    try { if (sessionStorage.getItem('lumi_update_dismissed') === '1') return; } catch (e) { }
    var box = document.createElement('div');
    box.id = 'lumi-update-toast';
    box.setAttribute('role', 'status');
    box.setAttribute('aria-live', 'polite');
    box.style.cssText = 'position:fixed;top:72px;left:50%;transform:translateX(-50%);z-index:10000;display:flex;align-items:center;gap:8px;width:max-content;max-width:calc(100% - 24px);box-sizing:border-box;padding:9px 10px 9px 14px;border-radius:14px;background:rgba(255,255,255,.94);border:1px solid rgba(91,63,214,.16);box-shadow:0 12px 34px rgba(54,40,100,.18);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);color:#2B2440;font:13px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif';
    var txt = document.createElement('span');
    txt.textContent = 'Lumi Words 有新版本，刷新后生效。';
    var go = document.createElement('button');
    go.type = 'button';
    go.textContent = '刷新';
    go.style.cssText = 'border:0;border-radius:9px;padding:6px 11px;background:#5B3FD6;color:#fff;font:600 12px/1 system-ui,sans-serif;cursor:pointer;white-space:nowrap';
    go.addEventListener('click', function () { location.reload(); });
    var later = document.createElement('button');
    later.type = 'button';
    later.textContent = '稍后';
    later.style.cssText = 'border:0;background:transparent;color:#716880;font:12px/1 system-ui,sans-serif;cursor:pointer;padding:6px 4px;white-space:nowrap';
    later.addEventListener('click', function () {
      try { sessionStorage.setItem('lumi_update_dismissed', '1'); } catch (e) { }
      box.remove();
    });
    box.appendChild(txt); box.appendChild(go); box.appendChild(later);
    document.body.appendChild(box);
  }
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (hadController) showUpdateToast();
    });
    window.addEventListener('load', function () {
      // 安装版由 App 内置本地服务器提供全部资源，Service Worker 只会多一层陈旧缓存。
      if (window.LumiNative && window.LumiNative.localAssets) return;
      navigator.serviceWorker.register('sw.js?v=' + VERSION, { scope: './' }).catch(function (e) {
        if (window.console) console.warn('[pwa] 注册失败', e && e.message);
      });
    });
  }
  // Netlify 免费版会在右下角注入 "Powered by Netlify" 徽标（约 197x64，fixed）。
  // 窄屏时它会压住底部 Dock 和聊天输入框；检测到后给 <html> 加类，由 ui-v2.css
  // 统一抬高底部安全区，不隐藏、不修改徽标本身。
  // v41：徽标首次布局时高度可能短暂是 92px，加载后稳定为 64px。先按已知的
  // 84px 安全区落位，再在 1.2s/3s 和尺寸变化时重测，避免 Dock 被永久多抬 28px。
  function setBadgeSafe(px) {
    var root = document.documentElement;
    if (root.style.getPropertyValue('--nl-badge-safe') !== px) {
      root.style.setProperty('--nl-badge-safe', px);
    }
    root.classList.add('nl-badge-safe');
  }
  function measureBadge(f) {
    var h = 64;
    try { var r = f.getBoundingClientRect(); if (r && r.height) h = r.height; } catch (e) { }
    if (h < 64) h = 64;
    setBadgeSafe(Math.round(h + 20) + 'px');
  }
  function trackBadge(f) {
    setBadgeSafe('84px');
    setTimeout(function () { measureBadge(f); }, 1200);
    setTimeout(function () { measureBadge(f); }, 3000);
    try {
      if (window.ResizeObserver) {
        var first = true;
        var ro = new ResizeObserver(function () {
          if (first) { first = false; return; } // 初次 observe 的回调不算尺寸变化
          measureBadge(f);
        });
        ro.observe(f);
        setTimeout(function () { try { ro.disconnect(); } catch (e) { } }, 8000);
      }
    } catch (e) { }
    // 不在 1.2s 前反复测量：徽标首帧可能是 92px，过早测量会把 Dock 抬高再落回。
    // 1.2s/3s 各测一次；尺寸真正变化时由 ResizeObserver 立即修正。
  }
  function watchNetlifyBadge() {
    var f = document.getElementById('nl-badge-frame');
    if (f) { trackBadge(f); return; }
    var tries = 0;
    var t = setInterval(function () {
      tries++;
      f = document.getElementById('nl-badge-frame');
      if (f) { clearInterval(t); trackBadge(f); }
      else if (tries >= 20) clearInterval(t);
    }, 250);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watchNetlifyBadge);
  else watchNetlifyBadge();

  var INSTALL_PROMPT = null;
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    INSTALL_PROMPT = e;
  });
  window.PWA = {
    canInstall: function () { return !!INSTALL_PROMPT; },
    install: function () {
      if (!INSTALL_PROMPT) return false;
      INSTALL_PROMPT.prompt();
      var p = INSTALL_PROMPT;
      INSTALL_PROMPT = null;
      return p;
    },
    isStandalone: function () {
      return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ||
        window.navigator.standalone === true;
    }
  };
})();
