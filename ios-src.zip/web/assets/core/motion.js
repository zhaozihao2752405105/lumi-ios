/* ============================================================
 * assets/core/motion.js —— 统一动效系统（STAGE 10）
 * 令牌：反馈 80–120ms、转场 180–300ms、弹簧 200–350ms
 * 只改 transform/opacity；尊重 prefers-reduced-motion
 * ============================================================ */
window.LumiMotion = (function () {
  'use strict';
  var DUR = { tap: 90, page: 220, spring: 280, sheet: 260 };
  var EASE = {
    standard: 'cubic-bezier(.2,.8,.2,1)',
    enter: 'cubic-bezier(.22,1,.36,1)',
    spring: 'cubic-bezier(.34,1.4,.64,1)'
  };

  function prefersReduced() {
    try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; }
    catch (e) { return false; }
  }

  // 一次性位移动画：结束后移除内联样式，避免残留 transform 影响布局命中
  function animate(el, from, to, opts) {
    if (!el || !el.style) return Promise.resolve(false);
    opts = opts || {};
    if (prefersReduced()) return Promise.resolve(false);
    var dur = opts.duration || DUR.page;
    var ease = opts.easing || EASE.enter;
    el.style.transition = 'transform ' + dur + 'ms ' + ease + ', opacity ' + dur + 'ms ' + ease;
    Object.keys(from).forEach(function (k) { el.style[k] = from[k]; });
    var timer = null;
    var pr = new Promise(function (resolve) {
      // 强制一次布局，确保起始态生效
      void el.offsetWidth;
      Object.keys(to).forEach(function (k) { el.style[k] = to[k]; });
      timer = window.setTimeout(function () {
        el.style.transition = '';
        Object.keys(to).forEach(function (k) { if (k !== 'opacity') el.style[k] = ''; });
        resolve(true);
      }, dur + 20);
    });
    // 允许被后续动画打断：清掉计时器并把内联过渡撤掉，避免两段动画互相拉扯
    pr.cancel = function () {
      if (timer) { clearTimeout(timer); timer = null; }
      el.style.transition = '';
      resolve === null;
    };
    return pr;
  }

  function pageIn(el) {
    if (!el) return Promise.resolve(false);
    return animate(el, { opacity: '0', transform: 'translateY(8px)' }, { opacity: '1', transform: 'translateY(0)' },
      { duration: DUR.page, easing: EASE.enter });
  }

  function tap(el) {
    if (!el) return;
    if (prefersReduced()) return;
    el.classList.add('v2-tapping');
    window.setTimeout(function () { el.classList.remove('v2-tapping'); }, DUR.tap + 30);
  }

  // 底栏滑块：连续位移 + 方向拉伸，快速连点时直接对齐目标
  function slideTo(bar, index, count) {
    if (!bar) return;
    var n = Math.max(1, count || 4);
    var i = Math.max(0, Math.min(n - 1, index || 0));
    bar.style.setProperty('--v2-dock-i', String(i));
    bar.style.setProperty('--v2-dock-n', String(n));
    bar.classList.add('v2-dock-anim');
  }

  // 底栏滑块：给每个 dock 注入一个指示器，并按当前 active 项定位
  function initDocks() {
    var docks = document.querySelectorAll('.v2-dock');
    for (var d = 0; d < docks.length; d++) {
      var bar = docks[d];
      var btns = bar.querySelectorAll('.v2-dock-btn');
      if (!btns.length) continue;
      if (!bar.querySelector('.v2-dock-ind')) {
        var ind = document.createElement('span');
        ind.className = 'v2-dock-ind';
        ind.setAttribute('aria-hidden', 'true');
        bar.appendChild(ind);
      }
      var active = -1;
      for (var i = 0; i < btns.length; i++) if (btns[i].classList.contains('is-active')) active = i;
      bar.style.setProperty('--v2-dock-n', String(btns.length));
      bar.style.setProperty('--v2-dock-i', String(active < 0 ? 0 : active));
      (function (b, btns2) {
        b.addEventListener('pointerdown', function (ev) {
          var t2 = ev.target.closest ? ev.target.closest('.v2-dock-btn') : null;
          if (!t2) return;
          var idx = Array.prototype.indexOf.call(btns2, t2);
          if (idx < 0) return;
          var cur = Number(b.style.getPropertyValue('--v2-dock-i') || 0);
          stretch(b, idx > cur ? 1 : (idx < cur ? -1 : 0));
          slideTo(b, idx, btns2.length);
        });
      })(bar, btns);
    }
  }

  function bindPress(root) {
    var host = root || document;
    if (host.__v2press) return;
    host.__v2press = true;
    host.addEventListener('pointerdown', function (e) {
      var t = e.target && e.target.closest && e.target.closest('.btn,.v2-btn,.v2-dock-btn,.v2-quick,.v2-card-btn,.icon-btn');
      if (!t) return;
      tap(t);
    }, { passive: true });
  }

  // 连续位移打断：同一个元素同一类动画只保留最后一个目标，避免逐帧抖动
  var running = new WeakMap();
  function retarget(el, from, to, opts) {
    if (!el) return Promise.resolve();
    var prev = running.get(el);
    if (prev && prev.cancel) { try { prev.cancel(); } catch (e) { } }
    var anim = animate(el, from, to, opts);
    running.set(el, anim);
    var clear = function () { if (running.get(el) === anim) running.delete(el); };
    if (anim && anim.finished) anim.finished.then(clear, clear); else clear();
    return Promise.resolve(anim);
  }

  // 底栏滑块方向拉伸：切换方向时短暂加宽，快速连点只保留最后一个目标
  function stretch(bar, dir) {
    if (!bar) return;
    bar.classList.add('v2-dock-stretch');
    clearTimeout(bar.__lumiStretch);
    bar.__lumiStretch = setTimeout(function () { bar.classList.remove('v2-dock-stretch'); }, 260);
    bar.style.setProperty('--v2-dock-dir', String(dir || 1));
  }

  // 帧采样：返回每次 rAF 的间隔，用于粗测掉帧（headless 不等于真机）
  function sampleFrames(durationMs) {
    return new Promise(function (resolve) {
      var ts = []; var start = performance.now();
      function step(t) { ts.push(t); if (t - start < durationMs) requestAnimationFrame(step); else {
        var gaps = []; for (var i = 1; i < ts.length; i++) gaps.push(ts[i] - ts[i - 1]);
        gaps.sort(function (a, b) { return a - b; });
        resolve({ frames: ts.length, p50: gaps[Math.floor(gaps.length * .5)] || 0, p95: gaps[Math.floor(gaps.length * .95)] || 0, max: gaps[gaps.length - 1] || 0 });
      } }
      requestAnimationFrame(step);
    });
  }

  // 学习反馈：四种节奏，元素不存在或减少动效时仍保留状态变化（不靠动画传达对错）
  function feedback(el, kind) {
    if (!el || !el.classList) return;
    var cls = kind === 'ok' ? 'lumi-fb-ok' : kind === 'bad' ? 'lumi-fb-bad' : kind === 'done' ? 'lumi-fb-done' : 'lumi-fb-progress';
    el.classList.add('lumi-fb');
    el.classList.remove('lumi-fb-ok', 'lumi-fb-bad', 'lumi-fb-done', 'lumi-fb-progress');
    void el.offsetWidth;
    el.classList.add(cls);
    clearTimeout(el.__lumiFb);
    el.__lumiFb = setTimeout(function () { el.classList.remove(cls); }, 400);
  }

  // 弹层：一个 mask + 一个 sheet，只做 transform/opacity；支持快速开合打断
  function openSheet(html, opts) {
    opts = opts || {};
    var mask = document.createElement('div');
    mask.className = 'v2-sheet-mask';
    var sheet = document.createElement('div');
    sheet.className = 'v2-sheet';
    sheet.setAttribute('role', 'dialog');
    sheet.setAttribute('aria-modal', 'true');
    sheet.innerHTML = html || '';
    document.body.appendChild(mask);
    document.body.appendChild(sheet);
    var close = function () { closeSheet(sheet, mask); if (opts.onClose) opts.onClose(); };
    mask.addEventListener('click', close);
    sheet.addEventListener('click', function (ev) { if (ev.target === sheet) close(); });
    void sheet.offsetHeight;
    mask.classList.add('is-open');
    sheet.classList.add('is-open');
    // 手势下拉关闭：跟手位移 + 松手判断（位移超 30% 或快速下滑即关闭，否则回弹）
    var drag = null;
    sheet.addEventListener('pointerdown', function (ev) {
      if (ev.target.closest && ev.target.closest('input,button,textarea,select,a')) return;
      drag = { y0: ev.clientY, t0: performance.now(), dy: 0 };
      sheet.style.transition = 'none';
    });
    sheet.addEventListener('pointermove', function (ev) {
      if (!drag) return;
      drag.dy = Math.max(0, ev.clientY - drag.y0);
      sheet.style.transform = 'translateY(' + drag.dy + 'px)';
    });
    var endDrag = function () {
      if (!drag) return;
      var dy = drag.dy, dt = Math.max(1, performance.now() - drag.t0);
      var fast = dy / dt > 0.55;
      sheet.style.transition = '';
      sheet.style.transform = '';
      drag = null;
      if (dy > sheet.offsetHeight * 0.3 || (fast && dy > 24)) close();
      else { sheet.classList.add('is-open'); }
    };
    sheet.addEventListener('pointerup', endDrag);
    sheet.addEventListener('pointercancel', endDrag);
    return { sheet: sheet, mask: mask, close: close };
  }
  function closeSheet(sheet, mask) {
    if (!sheet || !sheet.parentNode) return;
    sheet.classList.remove('is-open');
    if (mask) mask.classList.remove('is-open');
    var done = function () {
      if (sheet.parentNode) sheet.parentNode.removeChild(sheet);
      if (mask && mask.parentNode) mask.parentNode.removeChild(mask);
    };
    if (prefersReduced()) done(); else setTimeout(done, 300);
  }

  return {
    DUR: DUR, EASE: EASE, prefersReduced: prefersReduced,
    animate: animate, pageIn: pageIn, tap: tap, slideTo: slideTo, bindPress: bindPress, initDocks: initDocks, openSheet: openSheet, closeSheet: closeSheet, feedback: feedback, retarget: retarget, stretch: stretch, sampleFrames: sampleFrames
  };
})();

/* 统一接入：按压反馈 + 首屏入场（懒加载到 load 之后，避免与数据渲染抢帧） */
(function () {
  function boot() {
    try { window.LumiMotion.bindPress(document); } catch (e) { }
    try { window.LumiMotion.initDocks(); } catch (e) { }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  window.addEventListener('load', function () {
    try {
      var v = document.getElementById('view');
      if (v) window.LumiMotion.pageIn(v);
    } catch (e) { }
  });
})();
