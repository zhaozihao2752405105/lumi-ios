/* ============================================================
 * assets/core/ai.js —— AI 网关客户端（唯一调用入口）
 * 设计要点：
 *  1) 同一个 request_id 重试 = 服务端幂等：网关发现已有 attempt 就递增 attempt_no 复用历史，
 *     不会重复计费；所以网络抖动时重试不换 ID。
 *  2) 错误分类：网络/5xx/429 → 自动重试（最多 3 次，退避 0.7s、1.4s）；
 *     401/403/402/400 → 不重试，直接交给页面处理。
 *  3) 预算被拒（402 month_limit / daily_limit）后本次会话内不再发请求，避免无谓等待；
 *     页面可调 AI.clearBudgetBlock() 让用户手动再试（例如调高预算后）。
 *  4) 不做内容缓存、不改写 payload —— 内容级缓存与降级在各自模块里做。
 * 用法：
 *   var r = await AI.invoke('word', { count: 15, level: 1, domain: 'gen' });
 *   if (r.ok) use(r.data, r.meta, r.usage); else show(r.code, r.message);
 * ============================================================ */
window.AI = (function () {
  var MAX_ATTEMPTS = 3;
  var BACKOFF_MS = [700, 1400];
  var budgetBlock = null;
  var stats = { calls: 0, failed: 0, cost: 0 };

  function newRequestId() {
    return 'ai-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function pick(body, key) {
    if (!body) return '';
    if (body[key]) return body[key];
    if (body.error && body.error[key]) return body.error[key];
    return '';
  }

  // 统一结构：{ok,status,code,message,data,meta,usage,requestId,attempts}
  function normalize(status, body) {
    var ok = !!(body && body.ok);
    return {
      ok: ok,
      status: status,
      code: ok ? 'ok' : (pick(body, 'code') || 'unknown'),
      message: pick(body, 'message'),
      data: (body && body.data !== undefined) ? body.data : null,
      meta: (body && body.meta) || null,
      usage: (body && body.usage) || null
    };
  }

  // 只有这些才值得重试
  function isRetryable(status, code) {
    if (status === 0) return true;              // 断网 / 超时
    if (status >= 500) return true;              // 服务端临时故障
    if (status === 429) return true;             // 限流
    if (code === 'network' || code === 'bad_response') return true;
    return false;
  }

  function isBudgetCode(code) {
    return code === 'month_limit' || code === 'daily_limit';
  }

  async function invoke(kind, payload, opts) {
    opts = opts || {};
    if (!kind) throw new Error('AI.invoke 需要 kind');
    if (budgetBlock && !opts.ignoreBudgetBlock) {
      return {
        ok: false, status: 402, code: budgetBlock.code, message: budgetBlock.message,
        budgetBlocked: true, requestId: '', attempts: 0, data: null, meta: null, usage: null
      };
    }
    var requestId = opts.requestId || newRequestId();
    var attempts = 0;
    var last = null;
    while (attempts < MAX_ATTEMPTS) {
      attempts++;
      var raw;
      try {
        raw = await window.DB.aiInvoke(kind, payload || {}, requestId);
      } catch (e) {
        raw = { status: 0, body: { ok: false, code: 'network', message: (e && e.message) || '网络异常' } };
      }
      last = normalize(raw.status, raw.body);
      last.requestId = requestId;
      last.attempts = attempts;

      if (last.ok) {
        stats.calls++;
        stats.cost += Number((last.usage && last.usage.cost_cny) || 0);
        if (window.console) console.log('[AI]', kind, 'ok', attempts + '次', (last.usage && last.usage.cost_cny) || 0, '元');
        return last;
      }
      if (isBudgetCode(last.code) || last.status === 402) {
        budgetBlock = { code: last.code || 'month_limit', message: last.message || '本月 AI 预算已用完', at: Date.now() };
        last.budgetBlocked = true;
        stats.failed++;
        if (window.console) console.log('[AI]', kind, '预算闸门', last.code);
        return last;
      }
      if (!isRetryable(last.status, last.code)) {
        stats.failed++;
        if (window.console) console.log('[AI]', kind, '放弃', last.status, last.code);
        return last;
      }
      if (attempts < MAX_ATTEMPTS) await sleep(BACKOFF_MS[attempts - 1] || 1400);
    }
    stats.failed++;
    if (window.console) console.log('[AI]', kind, '重试', attempts, '次仍失败');
    return last;
  }

  // 便捷封装：只关心「成功的数据」，失败抛错给调用方统一处理（页面级替换成降级内容）
  async function data(kind, payload, opts) {
    var r = await invoke(kind, payload, opts);
    if (r.ok) return r;
    var err = new Error(r.message || ('AI 调用失败：' + r.code));
    err.code = r.code;
    err.status = r.status;
    err.budgetBlocked = !!r.budgetBlocked;
    err.requestId = r.requestId;
    throw err;
  }

  function budgetInfo() { return budgetBlock ? JSON.parse(JSON.stringify(budgetBlock)) : null; }
  function clearBudgetBlock() { budgetBlock = null; }
  function statsSnapshot() { return JSON.parse(JSON.stringify(stats)); }
  function resetStats() { stats = { calls: 0, failed: 0, cost: 0 }; }

  return {
    invoke: invoke,
    data: data,
    newRequestId: newRequestId,
    budgetInfo: budgetInfo,
    clearBudgetBlock: clearBudgetBlock,
    stats: statsSnapshot,
    resetStats: resetStats,
    MAX_ATTEMPTS: MAX_ATTEMPTS
  };
})();
