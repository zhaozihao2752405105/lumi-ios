/* Lumi Words · 键盘遮挡修复
   问题：iPhone 弹出软键盘后，输入框常被键盘挡住，用户看不到自己写的内容。
   做法：输入框获得焦点后把它滚到可视区中间；键盘出现（visualViewport 缩小）时再校正一次。
   只做滚动，不改任何业务逻辑。 */
(function () {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  var SEL = 'input:not([type=checkbox]):not([type=radio]):not([type=button]),textarea';

  function reveal(el, delay) {
    if (!el) return;
    setTimeout(function () {
      try {
        var r = el.getBoundingClientRect();
        var vv = window.visualViewport;
        var vh = vv ? vv.height : window.innerHeight;
        var top = vv ? vv.offsetTop : 0;
        var margin = 96;
        // 已经在可视区且离键盘够远，就不打扰用户
        if (r.top > top + margin && r.bottom < top + vh - margin) return;
        el.scrollIntoView({ block: 'center', inline: 'nearest' });
      } catch (e) { /* 老浏览器没有对象参数，忽略 */ }
    }, delay || 260);
  }

  document.addEventListener('focusin', function (e) {
    var el = e.target;
    if (!el || !el.matches || !el.matches(SEL)) return;
    reveal(el, 260);
  });

  if (window.visualViewport) {
    var last = window.visualViewport.height;
    window.visualViewport.addEventListener('resize', function () {
      var h = window.visualViewport.height;
      var shrunk = h < last - 60;
      last = h;
      if (!shrunk) return;
      var el = document.activeElement;
      if (el && el.matches && el.matches(SEL)) reveal(el, 60);
    });
  }
})();