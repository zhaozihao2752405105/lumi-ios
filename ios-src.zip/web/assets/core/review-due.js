/* assets/core/review-due.js —— 复习页顶部的「今天到期错题」提示卡（阶段 3）
 * 只读调用 get_due_mistake_reviews；服务端未执行迁移 016、未登录、无到期题时整卡隐藏，不报错。
 * 不参与每日任务完成度计算（完成度只看 daily_task_item）。
 */
(function () {
  'use strict';

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function hide(box) {
    if (!box) return;
    box.style.display = 'none';
    box.innerHTML = '';
  }

  async function boot() {
    var box = document.getElementById('dueCard');
    if (!box) return;
    if (!window.MistakeReview || !window.DB) return hide(box);
    // 先等登录态就绪（supabase 会异步恢复会话），否则 RPC 可能没带 JWT 而误判失败
    try {
      if (window.AppAuth && window.AppAuth.requireLogin) {
        var user = await window.AppAuth.requireLogin();
        if (!user) return hide(box);
      }
    } catch (e) { return hide(box); }
    var d = null;
    // 只要总数与第一题提示，取 10 道足够；total_due 由服务端独立统计，不受 p_limit 影响
    try { d = await window.MistakeReview.due(10); } catch (e) { d = null; }
    if (!d || !d.ok || !d.total) return hide(box);
    var first = (d.items && d.items[0]) ? d.items[0] : null;
    var hint = '';
    if (first) {
      var q = String(first.question || '').slice(0, 48);
      hint = '先复习：' + q + (String(first.question || '').length > 48 ? '…' : '');
    }
    box.innerHTML = '<div class="card"><div class="rowline"><h3 style="margin:0;font-size:16px">今天到期错题 ' + d.total + ' 题</h3><span class="pill grey">复习计划</span></div>' +
      '<p class="muted small" style="margin:8px 0 0">' + esc(hint || '答错的题会按 3/7/14/30 天安排复习，连对 4 次才毕业；每天最多复习 2 次。') + '</p>' +
      '<div class="row mt8"><a class="btn sm" href="mistakes.html?due=1">去复习错题</a></div></div>';
    box.style.display = '';
  }

  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();
})();
