/* ============================================================
 * assets/core/queue.js —— 离线待提交队列（IndexedDB，无第三方库）v4
 * v4 相对 v3（第三轮审查 4 项）：
 *   0) v1→v2 升级迁移：onupgradeneeded 里用游标把旧记录 key 改成 user_id+'|'+client_event_id，
 *      补齐 client_event_id，保留 payload/attempts/last_error/dead/created_at。绝不删旧队列重建。
 *   1) 所有删除/更新都显式绑定记录自己的 user_id（ownerId 参数），不再依赖会变的全局 currentUser：
 *      trim、clearDead、sendAll 读到记录后一律把 rec.user_id 传下去，避免 A 退出 B 登录后误删 B 的记录。
 *   2) finals 状态单向流转：queued→sent / queued→dead；sent 不能再被 dead 覆盖；dead 不能回 queued。
 *      判断与写入在同一个 readwrite 事务内完成，多标签页不会互相倒退状态。
 * 其余沿用 v3：账号前缀主键、最终答案永久锁定、同键同参数幂等、dead 不复活、软上限清理。
 * 对外：window.StudyQueue
 *   init(userId) / isSupported() / finalEventId(itemId) / newEventId()
 *   enqueue(kind, payload, clientId) → {client_event_id, existing, dead, record}
 *   lockFinal(itemId, result) / getFinal(itemId, ownerId) / setFinalState(itemId, state, ownerId)
 *   listMine() / listAll() / remove(clientId, ownerId) / getRecord(clientId, ownerId)
 *   markError(clientId, msg, ownerId) / markDead(clientId, msg, ownerId) / trim() / count()
 *   kind：'attempt'（普通作答）/ 'complete'（最终提交）/ 'skip'（跳过条目）
 * ============================================================ */
window.StudyQueue = (function () {
  var DB_NAME = 'study_queue.v1';
  var STORE = 'outbox';
  var FINALS = 'finals';
  var VERSION = 3;   // v3→v4 代码：2 已发布过，必须再升版本才能触发 onupgradeneeded（第五轮审查）
  var SOFT_MAX = 200;
  var WARN_MAX = 400;
  var dbp = null;
  var currentUser = null;

  function isSupported() {
    try { return typeof indexedDB !== 'undefined' && indexedDB !== null; } catch (e) { return false; }
  }

  function openDB() {
    if (dbp) return dbp;
    dbp = new Promise(function (resolve, reject) {
      if (!isSupported()) { reject(new Error('这个浏览器不支持离线队列（IndexedDB）')); return; }
      var req = indexedDB.open(DB_NAME, VERSION);
      req.onupgradeneeded = function (event) {
        var db = req.result;
        var tx = req.transaction;
        var oldVersion = event.oldVersion || 0;
        var os;
        if (!db.objectStoreNames.contains(STORE)) {
          os = db.createObjectStore(STORE, { keyPath: 'key' });
          os.createIndex('by_user', 'user_id', { unique: false });
          os.createIndex('by_created', 'created_at', { unique: false });
        }
        if (!db.objectStoreNames.contains(FINALS)) {
          db.createObjectStore(FINALS, { keyPath: 'key' });
        }
        // v1/v2 → v3 迁移：旧记录的 key 是裸 client_event_id，且没有 client_event_id 字段。
        // 注意：v3 版本号 2 已经发布过，用过 v3 的用户 oldVersion 就是 2，
        // 所以必须升到 3 且条件写 < 3，否则这些用户根本不会触发迁移（第五轮审查）。
        if (oldVersion >= 1 && oldVersion < 3) {
          migrateOutbox(tx.objectStore(STORE));
        }
      };
      req.onsuccess = function () {
        var db = req.result;
        db.onversionchange = function () {
          try { db.close(); } catch (e) { /* 忽略 */ }
          dbp = null;
        };
        repairInvalid(db).then(function () { resolve(db); });
      };
      req.onerror = function () { reject(req.error || new Error('离线队列打开失败')); };
      req.onblocked = function () { reject(new Error('离线队列被其他标签页占用，请关掉多余页面后重试')); };
    });
    dbp.catch(function () { dbp = null; });
    return dbp;
  }

  // 在升级事务内迁移：先 add 新键，成功后才删旧键；失败只跳过该条并保留旧记录。
  // 两个关键点（第四/五/六轮审查）：
  //  1) add/put 的键冲突是异步 request error，try/catch 抓不到，必须 onerror + preventDefault，
  //     否则错误会让整个升级事务中止，用户升级后所有离线记录都补交不了；
  //  2) 请求失败后必须继续推进游标（continue），否则事务里再没有新请求，升级会提前提交，
  //     剩下的旧记录全部漏迁移。所以每个分支的成功/失败回调都要调用同一个 advance()，且只推进一次。
  function migrateOutbox(store) {
    var cur = store.openCursor();
    cur.onsuccess = function () {
      var c = cur.result;
      if (!c) return;
      var rec = c.value;
      var oldKey = rec && rec.key;
      var moved = null;
      var advanced = false;
      function advance() {
        if (advanced) return;
        advanced = true;
        try { c['continue'](); } catch (e) { /* 游标已失效时无法继续，交给事务结束 */ }
      }
      function onErr(ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        if (ev && ev.stopPropagation) ev.stopPropagation();
      }

      // 已经是「user_id|ID」前缀键但缺 client_event_id：从键里安全提取 ID 补齐（键不变）
      if (rec && rec.user_id && oldKey && !rec.client_event_id && String(oldKey).indexOf(rec.user_id + '|') === 0) {
        var picked = String(oldKey).slice(String(rec.user_id).length + 1);
        if (picked) {
          rec.client_event_id = picked;
        } else {
          rec.dead = true;
          rec.last_error = 'migrate_bad_key';
        }
        var fillReq = store.put(rec);
        fillReq.onsuccess = advance;
        fillReq.onerror = function (ev) { onErr(ev); advance(); };
        return;
      }

      // 没有 user_id 的遗留记录无法归属账号：不静默删除，标死信保留原因
      if (rec && oldKey && !rec.client_event_id && !rec.user_id) {
        rec.dead = true;
        rec.last_error = 'migrate_no_owner';
        var fixReq = store.put(rec);
        fixReq.onsuccess = advance;
        fixReq.onerror = function (ev) { onErr(ev); advance(); };
        return;
      }

      // 旧格式：key 是裸 client_event_id → 复制成账号前缀键
      if (rec && rec.user_id && oldKey && !rec.client_event_id) {
        moved = {};
        Object.keys(rec).forEach(function (k) { moved[k] = rec[k]; });
        moved.client_event_id = oldKey;
        moved.key = rec.user_id + '|' + oldKey;
      }
      if (!moved) { advance(); return; }

      var addReq = store.add(moved);
      addReq.onsuccess = function () {
        var del = store['delete'](oldKey);   // 新键写好后再删旧键
        del.onsuccess = advance;
        del.onerror = function (ev) { onErr(ev); advance(); };
      };
      addReq.onerror = function (ev) {
        onErr(ev);
        // 目标键已存在：旧记录标 dead + 原因（listMine 会过滤，不进发送流程），不静默丢数据
        var keep = rec;
        keep.dead = true;
        keep.last_error = 'migrate_conflict';
        var putReq = store.put(keep);
        putReq.onsuccess = advance;
        putReq.onerror = function (ev2) { onErr(ev2); advance(); };
      };
    };
  }

  var newEventSeq = 0;
  function newEventId() {
    var rnd = '';
    try {
      if (window.crypto && window.crypto.getRandomValues) {
        var a = new Uint8Array(10);
        window.crypto.getRandomValues(a);
        for (var i = 0; i < a.length; i++) rnd += ('0' + a[i].toString(16)).slice(-2);
      }
    } catch (e) { rnd = ''; }
    if (!rnd) rnd = Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10);
    newEventSeq = (newEventSeq + 1) % 1000;
    return 'evt-' + Date.now().toString(36) + '-' + newEventSeq + '-' + rnd;
  }

  function finalEventId(itemId) {
    if (!itemId) throw new Error('finalEventId 需要条目 ID');
    return 'fin-' + String(itemId);
  }

  function init(userId) {
    currentUser = userId || null;
    return Promise.resolve(currentUser);
  }

  // ownerId 显式传入时优先使用：异步操作必须绑定记录原始归属，不能依赖 currentUser
  function scoped(clientId, ownerId) {
    var owner = ownerId || currentUser;
    if (!owner) throw new Error('队列未绑定用户（请先登录）');
    return owner + '|' + clientId;
  }
  function finalKey(itemId, ownerId) {
    var owner = ownerId || currentUser;
    if (!owner) throw new Error('队列未绑定用户（请先登录）');
    return owner + '|' + String(itemId);
  }

  function tx(stores, mode) {
    return openDB().then(function (db) { return db.transaction(stores, mode); });
  }

  function getRecord(clientId, ownerId) {
    return tx([STORE], 'readonly').then(function (t) {
      return new Promise(function (resolve, reject) {
        var r = t.objectStore(STORE).get(scoped(clientId, ownerId));
        r.onsuccess = function () { resolve(r.result || null); };
        r.onerror = function () { reject(r.error || new Error('读取队列记录失败')); };
      });
    });
  }

  function listAll() {
    return tx([STORE], 'readonly').then(function (t) {
      return new Promise(function (resolve, reject) {
        var r = t.objectStore(STORE).getAll();
        r.onsuccess = function () {
          var rows = r.result || [];
          rows.sort(function (a, b) {
            if (a.created_at === b.created_at) return a.key < b.key ? -1 : 1;
            return a.created_at < b.created_at ? -1 : 1;
          });
          resolve(rows);
        };
        r.onerror = function () { reject(r.error || new Error('读取队列失败')); };
      });
    });
  }

  // 可发送记录必须同时满足：未 dead、有 user_id、有 client_event_id、key 与账号前缀一致。
  // 迁移失败或历史脏数据即使 put 失败也不会被当成正常记录发送（第五轮审查第 2 点）。
  function isSendable(rec) {
    if (!rec || rec.dead === true) return false;
    if (!rec.user_id || !rec.client_event_id) return false;
    return rec.key === rec.user_id + '|' + rec.client_event_id;
  }

  // 打开库后做一次修复：不满足可发送条件的活记录就地标 dead + 明确原因（保留可检查信息，不静默丢）
  function repairInvalid(db) {
    return new Promise(function (resolve) {
      var t;
      try { t = db.transaction([STORE], 'readwrite'); } catch (e) { resolve(); return; }
      var s = t.objectStore(STORE);
      var rq = s.getAll();
      rq.onerror = function () { /* 交给事务结束回调 */ };
      rq.onsuccess = function () {
        var rows = rq.result || [];
        rows.forEach(function (rec) {
          if (rec && rec.dead === true) return;
          if (isSendable(rec)) return;
          rec.dead = true;
          rec.last_error = rec.last_error || (rec.client_event_id ? 'invalid_key' : 'missing_client_event_id');
          var p = s.put(rec);
          p.onerror = function (ev) {
            if (ev && ev.preventDefault) ev.preventDefault();
            if (ev && ev.stopPropagation) ev.stopPropagation();
          };
        });
      };
      t.oncomplete = function () { resolve(); };
      t.onerror = function () { resolve(); };
      t.onabort = function () { resolve(); };
    });
  }

  function listMine() {
    if (!currentUser) return Promise.resolve([]);
    return listAll().then(function (rows) {
      return rows.filter(function (r) { return r.user_id === currentUser && isSendable(r); });
    });
  }

  function enqueue(kind, payload, clientId, ownerId) {
    var owner = ownerId || currentUser;
    if (!owner) return Promise.reject(new Error('队列未绑定用户（请先登录）'));
    clientId = clientId || newEventId();
    var rec = {
      key: owner + '|' + clientId,
      client_event_id: clientId,
      kind: kind,
      user_id: owner,
      payload: payload || {},
      created_at: new Date().toISOString(),
      attempts: 0,
      last_error: null,
      dead: false
    };
    return tx([STORE], 'readwrite').then(function (t) {
      return new Promise(function (resolve, reject) {
        var os = t.objectStore(STORE);
        var g = os.get(rec.key);
        var result = null;
        g.onsuccess = function () {
          var old = g.result;
          if (old) {
            if (old.user_id !== owner) {
              reject(new Error('本地记录属于其他账号，已拒绝复用'));
              try { t.abort(); } catch (e) { /* 忽略 */ }
              return;
            }
            var same = (old.kind === kind) &&
                       (JSON.stringify(old.payload) === JSON.stringify(rec.payload));
            if (!same) {
              reject(new Error('同一提交编号已有不同参数，已拒绝覆盖（编号 ' + clientId + '）'));
              try { t.abort(); } catch (e) { /* 忽略 */ }
              return;
            }
            result = { client_event_id: clientId, key: old.key, existing: true, dead: old.dead === true, record: old };
            return;
          }
          os.put(rec);
          result = { client_event_id: clientId, key: rec.key, existing: false, dead: false, record: rec };
        };
        t.oncomplete = function () { resolve(result); };
        t.onerror = function () { reject(t.error || new Error('入队失败')); };
        t.onabort = function () { reject(t.error || new Error('入队事务被中断')); };
      });
    }).then(function (r) { return trim(owner).then(function () { return r; }); });
  }

  function updateRecord(clientId, mutate, ownerId) {
    var key = scoped(clientId, ownerId);
    return tx([STORE], 'readwrite').then(function (t) {
      return new Promise(function (resolve, reject) {
        var os = t.objectStore(STORE);
        var g = os.get(key);
        var out = null;
        g.onsuccess = function () {
          var rec = g.result;
          if (!rec) { resolve(null); return; }
          var patch = mutate(rec);
          if (patch === false) { out = rec; return; }
          Object.keys(patch).forEach(function (k) { rec[k] = patch[k]; });
          os.put(rec);
          out = rec;
        };
        t.oncomplete = function () { resolve(out); };
        t.onerror = function () { reject(t.error || new Error('更新队列记录失败')); };
        t.onabort = function () { reject(t.error || new Error('更新队列事务被中断')); };
      });
    });
  }

  function markError(clientId, message, ownerId) {
    return updateRecord(clientId, function (rec) {
      return { attempts: (rec.attempts || 0) + 1, last_error: String(message || '') };
    }, ownerId);
  }

  function markDead(clientId, message, ownerId) {
    return updateRecord(clientId, function (rec) {
      return { dead: true, last_error: String(message || ''), attempts: (rec.attempts || 0) + 1 };
    }, ownerId);
  }

  function remove(clientId, ownerId) {
    var key = scoped(clientId, ownerId);
    return tx([STORE], 'readwrite').then(function (t) {
      return new Promise(function (resolve, reject) {
        t.objectStore(STORE).delete(key);
        t.oncomplete = function () { resolve(true); };
        t.onerror = function () { reject(t.error || new Error('出队失败')); };
        t.onabort = function () { reject(t.error || new Error('出队事务被中断')); };
      });
    });
  }

  // ---------------- finals：最终答案永久锁定 + 状态单向流转 ----------------

  function getFinal(itemId, ownerId) {
    return tx([FINALS], 'readonly').then(function (t) {
      return new Promise(function (resolve, reject) {
        var r = t.objectStore(FINALS).get(finalKey(itemId, ownerId));
        r.onsuccess = function () { resolve(r.result || null); };
        r.onerror = function () { reject(r.error || new Error('读取最终答案锁失败')); };
      });
    });
  }

  function lockFinal(itemId, result, ownerId) {
    var raw = JSON.stringify(result);
    var owner = ownerId || currentUser;
    if (!owner) return Promise.reject(new Error('队列未绑定用户（请先登录）'));
    return tx([FINALS], 'readwrite').then(function (t) {
      return new Promise(function (resolve, reject) {
        var os = t.objectStore(FINALS);
        var g = os.get(finalKey(itemId, owner));
        var out = null;
        g.onsuccess = function () {
          var old = g.result;
          if (old) {
            if (old.user_id !== owner) {
              reject(new Error('最终答案锁属于其他账号'));
              try { t.abort(); } catch (e) { /* 忽略 */ }
              return;
            }
            out = { same: old.result_raw === raw, created: false, existing: old };
            return;
          }
          var rec = {
            key: finalKey(itemId, owner),
            user_id: owner,
            item_id: String(itemId),
            result_raw: raw,
            state: 'queued',
            created_at: new Date().toISOString()
          };
          os.put(rec);
          out = { same: true, created: true, existing: rec };
        };
        t.oncomplete = function () { resolve(out); };
        t.onerror = function () { reject(t.error || new Error('锁定最终答案失败')); };
        t.onabort = function () { reject(t.error || new Error('锁定事务被中断')); };
      });
    });
  }

  // 只允许 queued→sent / queued→dead / 相同状态重复；sent 不能被 dead 覆盖，dead 不能回 queued
  var FINAL_TRANSITIONS = {
    queued: { queued: 1, sent: 1, dead: 1 },
    sent: { sent: 1 },
    dead: { dead: 1 }
  };

  function setFinalState(itemId, state, ownerId) {
    var key = finalKey(itemId, ownerId);
    return tx([FINALS], 'readwrite').then(function (t) {
      return new Promise(function (resolve, reject) {
        var os = t.objectStore(FINALS);
        var g = os.get(key);
        var out = null;
        g.onsuccess = function () {
          var rec = g.result;
          if (!rec) { resolve({ changed: false, state: null }); return; }
          var allowed = FINAL_TRANSITIONS[rec.state] && FINAL_TRANSITIONS[rec.state][state];
          if (!allowed) {
            out = { changed: false, state: rec.state };
            return;
          }
          rec.state = state;
          os.put(rec);
          out = { changed: true, state: state };
        };
        t.oncomplete = function () { resolve(out); };
        t.onerror = function () { reject(t.error || new Error('更新最终答案状态失败')); };
        t.onabort = function () { reject(t.error || new Error('更新事务被中断')); };
      });
    });
  }

  function trim(ownerId) {
    var owner = ownerId || currentUser;
    if (!owner) return Promise.resolve({ dropped: 0, total: 0 });
    return listAll().then(function (all) {
      var mine = all.filter(function (r) { return r.user_id === owner; });
      if (mine.length <= SOFT_MAX) {
        if (mine.length > WARN_MAX && window.console) {
          console.warn('离线队列已达 ' + mine.length + ' 条（软上限 ' + SOFT_MAX +
            '）。为保证最终提交不丢，系统没有继续删除，请尽快联网。');
        }
        return { dropped: 0, total: mine.length };
      }
      var overflow = mine.length - SOFT_MAX;
      var victims = [];
      var picked = {};
      var i;
      for (i = 0; i < mine.length && victims.length < overflow; i++) {
        if (mine[i].dead === true && !picked[mine[i].key]) { picked[mine[i].key] = true; victims.push(mine[i]); }
      }
      for (i = 0; i < mine.length && victims.length < overflow; i++) {
        if (mine[i].kind === 'attempt' && !picked[mine[i].key]) { picked[mine[i].key] = true; victims.push(mine[i]); }
      }
      return Promise.all(victims.map(function (v) {
        return remove(v.client_event_id, v.user_id);   // 绑定记录自身账号
      })).then(function () {
        var total = mine.length - victims.length;
        if (total > WARN_MAX && window.console) {
          console.warn('离线队列仍剩 ' + total + ' 条（含最终提交，已保护不删）。请尽快联网补交。');
        }
        return { dropped: victims.length, total: total };
      });
    });
  }

  function listFinals(ownerId) {
    var owner = ownerId || currentUser;
    if (!owner) return Promise.resolve([]);
    return tx([FINALS], 'readonly').then(function (t) {
      return new Promise(function (resolve, reject) {
        var r = t.objectStore(FINALS).getAll();
        r.onsuccess = function () {
          resolve((r.result || []).filter(function (f) { return f.user_id === owner; }));
        };
        r.onerror = function () { reject(r.error || new Error('读取最终答案失败')); };
      });
    });
  }

  // 待补交 = 本账号 outbox 可发送记录 + 本账号 queued 状态的最终答案锁
  function count() {
    var owner = currentUser;
    if (!owner) return Promise.resolve(0);
    var finals = tx([FINALS], 'readonly').then(function (t) {
      return new Promise(function (resolve, reject) {
        var r = t.objectStore(FINALS).getAll();
        r.onsuccess = function () { resolve(r.result || []); };
        r.onerror = function () { reject(r.error || new Error('读取最终答案失败')); };
      });
    });
    return Promise.all([listMine(), finals]).then(function (res) {
      var rows = res[0] || [];
      var fs = (res[1] || []).filter(function (f) { return f.user_id === owner && f.state === 'queued'; });
      return rows.length + fs.length;
    });
  }

  return {
    isSupported: isSupported,
    init: init,
    newEventId: newEventId,
    finalEventId: finalEventId,
    enqueue: enqueue,
    getRecord: getRecord,
    listMine: listMine,
    listAll: listAll,
    remove: remove,
    markError: markError,
    markDead: markDead,
    getFinal: getFinal,
    listFinals: listFinals,
    lockFinal: lockFinal,
    setFinalState: setFinalState,
    trim: trim,
    count: count
  };
})();
