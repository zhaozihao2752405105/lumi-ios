/* ============================================================
 * assets/core/speech.js —— 真人单词录音与浏览器语音合成
 * 设计要点：
 *   1) 优先播放本地真人录音，缺少录音时调用浏览器语音，不消耗 Lumi 的 AI 预算。
 *   2) iPhone Safari 限制：必须在用户点击事件里直接调 speak()，不允许进页面自动播；
 *      连续点击先 cancel 上一个，避免叠音。
 *   3) 拿不到语音列表时（部分浏览器首次为空）监听 voiceschanged，下次手动点击时使用新音色（不自动重播）。
 *   4) 偏好存在 localStorage：开关 / 语速 / 答题前自动朗读；不同步云端（换手机重新设即可）。
 * ============================================================ */
window.Speech = (function () {
  'use strict';

  var PREF_KEY = 'eng_speech_prefs_v1';
  var DEFAULT = { on: true, auto: false, rate: 1 };
  var recordedWords = new Set(['action', 'answer', 'book', 'control', 'day', 'english',
    'example', 'friend', 'good', 'home', 'listen']);
  var activeAudio = null;
  var playbackId = 0;

  function synthesisSupported() {
    return typeof window !== 'undefined' &&
      'speechSynthesis' in window &&
      typeof window.SpeechSynthesisUtterance === 'function';
  }

  function supported() { return synthesisSupported() || typeof window.Audio === 'function'; }
  function prefs() {
    var p = { on: DEFAULT.on, auto: DEFAULT.auto, rate: DEFAULT.rate };
    try {
      var raw = window.localStorage.getItem(PREF_KEY);
      if (raw) {
        var o = JSON.parse(raw);
        if (o && typeof o === 'object') {
          if (o.on === false || o.on === true) p.on = o.on;
          if (o.auto === false || o.auto === true) p.auto = o.auto;
          var r = Number(o.rate);
          if (isFinite(r) && r >= 0.5 && r <= 1.5) p.rate = r;
        }
      }
    } catch (e) { /* localStorage 不可用（隐私模式）时用默认值 */ }
    return p;
  }

  function savePrefs(patch) {
    var p = prefs();
    if (patch && typeof patch === 'object') {
      if (patch.on === true || patch.on === false) p.on = patch.on;
      if (patch.auto === true || patch.auto === false) p.auto = patch.auto;
      var r = Number(patch.rate);
      if (isFinite(r) && r >= 0.5 && r <= 1.5) p.rate = r;
    }
    try { window.localStorage.setItem(PREF_KEY, JSON.stringify(p)); } catch (e) {}
    return p;
  }

  var voices = [];
  var voiceHooked = false;

  function loadVoices() {
    if (!synthesisSupported()) return voices;
    try {
      var v = window.speechSynthesis.getVoices();
      if (v && v.length) voices = v;
    } catch (e) {}
    return voices;
  }

  function hookVoices() {
    if (voiceHooked || !synthesisSupported()) return;
    voiceHooked = true;
    loadVoices();
    try {
      if (typeof window.speechSynthesis.addEventListener === 'function') {
        window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
      } else {
        window.speechSynthesis.onvoiceschanged = loadVoices;
      }
    } catch (e) {}
  }

  function isRemote(voice) {
    return voice?.localService === false || /\bonline\b/i.test(voice?.name || '');
  }

  function voiceFor(lang, { localOnly = false } = {}) {
    hookVoices();
    var want = String(lang || 'en-US').toLowerCase();
    var base = want.split('-')[0];
    var best = null, bestScore = -1;
    for (const voice of loadVoices()) {
      const language = String(voice?.lang || '').toLowerCase();
      if (language.split('-')[0] !== base) continue;
      const remote = isRemote(voice);
      if (remote && (localOnly || navigator.onLine === false)) continue;
      const natural = /\b(natural|neural|enhanced|premium)\b/i.test(voice.name || '');
      const score = (language === want ? 100 : 0) + (natural ? (remote ? 22 : 26) : 0)
        + (remote ? 0 : 3) + (voice.default ? 1 : 0);
      if (score > bestScore) { best = voice; bestScore = score; }
    }
    return best;
  }

  function stop() {
    playbackId++;
    if (activeAudio) {
      activeAudio.onended = activeAudio.onerror = null;
      activeAudio.pause();
      activeAudio = null;
    }
    try { if (synthesisSupported()) window.speechSynthesis.cancel(); } catch (e) {}
  }

  function pronounce(text, lang, rate, id, localOnly) {
    if (!synthesisSupported() || id !== playbackId) return false;
    try {
      const utter = new window.SpeechSynthesisUtterance(text);
      const voice = voiceFor(lang, { localOnly });
      utter.lang = voice?.lang || lang;
      if (voice) utter.voice = voice;
      utter.rate = rate;
      if (isRemote(voice)) utter.onerror = event => {
        if (event.error !== 'canceled' && event.error !== 'interrupted') pronounce(text, lang, rate, id, true);
      };
      window.speechSynthesis.speak(utter);
      return true;
    } catch { return false; }
  }

  // 需要在「用户点击」的同一个调用栈里执行（iPhone Safari 的硬性要求）
  function say(text, opt) {
    if (!supported()) return false;
    var p = prefs();
    if (opt && opt.force !== true && p.on !== true) return false;
    var t = String(text == null ? '' : text).replace(/\s+/g, ' ').trim();
    if (!t) return false;
    // Audio Session API (Safari versions which expose it). Set before speak, in the user gesture.
    // Unsupported browsers or OS policies may still respect the mute switch.
    try { if (navigator.audioSession && 'type' in navigator.audioSession) navigator.audioSession.type = 'playback'; } catch (e) {}
    stop();
    var lang = (opt && opt.lang) || 'en-US';
    var rate = (opt && opt.rate) || p.rate || 1;
    var word = t.toLowerCase(), id = playbackId;
    if (lang.toLowerCase() !== 'en-us' || !recordedWords.has(word) || typeof window.Audio !== 'function') {
      return pronounce(t, lang, rate, id, false);
    }
    const audio = new window.Audio('assets/audio/words/en-us/' + word + '.mp3');
    activeAudio = audio;
    audio.playbackRate = rate;
    audio.onended = () => { if (activeAudio === audio) activeAudio = null; };
    function fallback() {
      if (id !== playbackId || activeAudio !== audio) return false;
      activeAudio = null;
      audio.onended = audio.onerror = null;
      audio.pause();
      return pronounce(t, lang, rate, id, false);
    }
    audio.onerror = fallback;
    try {
      audio.play()?.catch(fallback);
      return true;
    } catch { return fallback(); }
  }

  // 只读状态，给设置页显示
  function status() {
    var list = loadVoices();
    var names = [];
    for (var i = 0; i < list.length && names.length < 6; i++) {
      if (list[i] && /^en/i.test(list[i].lang || '')) names.push(list[i].name + ' (' + list[i].lang + ')');
    }
    return { supported: supported(), count: list.length, enVoices: names, prefs: prefs() };
  }

  return {
    supported: supported,
    synthesisSupported: synthesisSupported,
    voiceFor: voiceFor,
    isRemote: isRemote,
    prefs: prefs,
    savePrefs: savePrefs,
    say: say,
    stop: stop,
    status: status,
    // 设置页「试听」用：读一句包含本系统常见领域词的短句
    testSentence: 'I enjoy learning something new every day.'
  };
})();
