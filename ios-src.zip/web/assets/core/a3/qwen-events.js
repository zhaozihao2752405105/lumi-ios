﻿/* Qwen Omni WebSocket event mapping. The injected channel must be a trusted broker. */
(function (root) {
  'use strict';

  function createQwenEvents({ generation, turns, send, requireNewSession }) {
    let input = null;
    let pending = null;
    let upstreamResponse = null;
    let stopped = false;
    let turnId = 0;
    let openingRequested = false;

    function emit(type, fields) {
      return turns.push({ generation, type, ...fields });
    }

    function reset(reason) {
      if (stopped) return;
      stopped = true;
      requireNewSession(reason);
    }

    function receive(event) {
      if (stopped) return false;
      const { type, item_id: item, response_id: responseId } = event;
      switch (type) {
        case 'input_audio_buffer.speech_started':
          if (!item || input?.item === item) return false;
          if (pending !== null) {
            reset('ambiguous_response');
            return false;
          }
          input = { item, id: ++turnId };
          return emit('speech-start', { turnId });
        case 'input_audio_buffer.speech_stopped':
          return input?.item === item && emit('speech-stop', { turnId: input.id });
        case 'input_audio_buffer.committed':
          if (!input || input.item !== item || input.committed) return false;
          input.committed = true;
          pending = input.id;
          return true;
        case 'conversation.item.input_audio_transcription.delta':
          return input?.item === item && emit('input-partial', {
            turnId: input.id, text: (event.text || '') + (event.stash || '')
          });
        case 'conversation.item.input_audio_transcription.completed':
          return input?.item === item && typeof event.transcript === 'string' &&
            emit('input-final', { turnId: input.id, text: event.transcript });
        case 'response.created': {
          if (pending === null || !event.response?.id || upstreamResponse) {
            reset('ambiguous_response');
            return false;
          }
          const id = pending;
          pending = null;
          upstreamResponse = event.response.id;
          if (emit('response-start', { turnId: id, responseId: upstreamResponse })) return true;
          reset('ambiguous_response');
          return false;
        }
        case 'response.audio.delta':
          return upstreamResponse === responseId && typeof event.delta === 'string' &&
            emit('response-audio', { responseId, audio: decodePCM(event.delta) });
        case 'response.audio_transcript.delta':
          return upstreamResponse === responseId && typeof event.delta === 'string' &&
            emit('response-caption', { responseId, delta: event.delta });
        case 'response.done':
          if (!upstreamResponse || upstreamResponse !== event.response?.id) return false;
          upstreamResponse = null;
          return emit(event.response.status === 'completed' ? 'response-done' : 'response-discard', {
            responseId: event.response.id
          });
        case 'error':
          reset('provider_error');
          return false;
        default:
          return false;
      }
    }

    function cancel(request) {
      if (stopped || request.generation !== generation) return;
      try {
        // Qwen documents cancellation of the active response, without a response ID.
        if (request.generating && upstreamResponse === request.responseId) {
          send({ type: 'response.cancel' });
        }
      } finally {
        // The published contract lacks a truncate-to-played-position command.
        reset('interrupted_context');
      }
    }

    return {
      receive, cancel,
      requestOpening() {
        if (stopped || openingRequested || input || pending !== null || upstreamResponse) return false;
        openingRequested = true;
        pending = 0;
        return true;
      },
      skipOpening() { if (pending === 0) pending = null; }
    };
  }

  function decodePCM(encoded) {
    if (encoded.length > 131072) throw new Error('Audio frame exceeds limit');
    const binary = atob(encoded);
    if (!binary.length || binary.length % 2) throw new Error('Invalid PCM16 frame');
    const samples = new Int16Array(binary.length / 2);
    for (let index = 0; index < samples.length; index++) {
      samples[index] = binary.charCodeAt(index * 2) | (binary.charCodeAt(index * 2 + 1) << 8);
    }
    return samples;
  }

  root.LumiQwenEvents = createQwenEvents;
})(globalThis);
