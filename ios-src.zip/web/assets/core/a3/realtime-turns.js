/* State for transports with individually identified audio frames. */
(function (root) {
  'use strict';

  function createTurns({ playback, cancelUpstream, onChange }) {
    let generation = 0;
    let live = false;
    let turn = null;
    let response = null;
    let nextTurn = 0;
    let completed = [];

    function snapshot() {
      return {
        generation, live, completed: completed.slice(),
        turn: turn && { ...turn },
        response: response && { id: response.id, text: response.text }
      };
    }

    function interrupt() {
      if (!response) return false;
      const interrupted = response;
      response = null;
      const playedMs = playback.clear(interrupted.id);
      cancelUpstream({ generation, responseId: interrupted.id, playedMs, generating: !interrupted.done });
      return true;
    }

    function publish() {
      onChange(snapshot());
    }

    function end() {
      if (!live) return;
      live = false;
      turn = null;
      interrupt();
      publish();
    }

    function start() {
      end();
      generation += 1;
      nextTurn = 0;
      live = true;
      publish();
      return generation;
    }

    function push(event) {
      if (!live || event.generation !== generation) return false;
      switch (event.type) {
        case 'speech-start':
          if (event.turnId !== undefined) {
            if (!Number.isSafeInteger(event.turnId) || event.turnId <= nextTurn) return false;
            nextTurn = event.turnId;
            turn = { id: nextTurn, text: '', speaking: true, final: false };
          } else if (turn && !turn.final) {
            if (turn.speaking) return false;
            turn.speaking = true;
          } else {
            turn = { id: ++nextTurn, text: '', speaking: true, final: false };
          }
          interrupt();
          break;
        case 'speech-stop':
        case 'input-partial':
        case 'input-final':
          if (!turn || turn.id !== event.turnId || turn.final) return false;
          if (event.type === 'speech-stop') turn.speaking = false;
          if (event.type === 'input-partial') turn.text = event.text;
          if (event.type === 'input-final') {
            turn.text = event.text;
            turn.speaking = false;
            turn.final = true;
            if (event.text.trim()) completed.push({ role: 'user', text: event.text });
          }
          break;
        case 'response-start':
          if (response) return false;
          if (event.turnId === 0) {
            if (turn || nextTurn !== 0) return false;
          } else {
            if (!turn || turn.speaking || turn.id !== event.turnId || turn.responded) return false;
            turn.responded = true;
          }
          response = { id: event.responseId, text: '', done: false, drained: false };
          break;
        case 'response-discard':
          if (!response || response.id !== event.responseId) return false;
          response = null;
          playback.clear(event.responseId);
          break;
        case 'response-audio':
        case 'response-caption':
        case 'response-done':
        case 'playback-drained':
          if (!response || response.id !== event.responseId) return false;
          if (event.type === 'response-audio') {
            if (response.done) return false;
            playback.enqueue(response.id, event.audio);
          }
          if (event.type === 'response-caption') {
            if (response.done) return false;
            response.text += event.delta;
          }
          if (event.type === 'response-done') {
            if (response.done) return false;
            response.done = true;
            playback.finish(response.id);
          }
          if (event.type === 'playback-drained') response.drained = true;
          if (response && response.drained && response.done) {
            if (response.text.trim()) completed.push({ role: 'assistant', text: response.text });
            response = null;
          }
          break;
        default:
          return false;
      }
      publish();
      return true;
    }

    function clearHistory() {
      completed = [];
      publish();
    }

    return {
      start, end, push, snapshot, clearHistory,
      interruptPlayback() { if (live && interrupt()) publish(); }
    };
  }

  root.LumiRealtimeTurns = createTurns;
})(globalThis);
