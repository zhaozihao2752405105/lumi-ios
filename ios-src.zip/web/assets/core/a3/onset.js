(function (root) {
  'use strict';
  root.LumiA3 ||= {};

/* Energy onset detector for echo-cancelled PCM. Server VAD still owns turn boundaries. */
root.LumiA3.createSpeechOnset = function createSpeechOnset({ minimumRms = 0.025, attackFrames = 3, releaseFrames = 8 } = {}) {
  let floor = minimumRms / 5;
  let attack = 0;
  let release = 0;
  let speaking = false;

  return function detect(pcm) {
    const samples = new DataView(pcm);
    if (samples.byteLength !== 640) return false;
    let sum = 0;
    for (let offset = 0; offset < samples.byteLength; offset += 2) {
      const sample = samples.getInt16(offset, true) / 32768;
      sum += sample * sample;
    }
    const rms = Math.sqrt(sum / 320);
    const loud = rms >= Math.max(minimumRms, floor * 3.5);
    if (loud) {
      release = 0;
      if (speaking || ++attack < attackFrames) return false;
      speaking = true;
      attack = 0;
      return true;
    }
    attack = 0;
    if (speaking && ++release >= releaseFrames) speaking = false;
    if (!speaking) floor = (floor * 0.97) + (Math.min(rms, minimumRms) * 0.03);
    return false;
  };
};
})(globalThis);
