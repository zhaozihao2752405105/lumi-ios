﻿/* PCM16 playback for a WebSocket transport. One response owns the queue. */
(function (root) {
  'use strict';

  function createPcmPlayback({ context, sampleRate, onDrained, onScheduled = () => {}, maxQueuedSeconds = 2 }) {
    let queue = null;

    function enqueue(id, pcm) {
      const firstFrame = !queue;
      if (!queue) queue = { id, sources: new Set(), until: 0, finished: false };
      const response = queue;
      if (response.id !== id || response.finished || !(pcm instanceof Int16Array) || !pcm.length) {
        throw new Error('Invalid audio frame');
      }

      const now = context.currentTime;
      const start = Math.max(now, response.until);
      const end = start + pcm.length / sampleRate;
      if (end - now > maxQueuedSeconds) throw new Error('Audio queue limit exceeded');

      const buffer = context.createBuffer(1, pcm.length, sampleRate);
      const channel = buffer.getChannelData(0);
      for (let i = 0; i < pcm.length; i++) channel[i] = pcm[i] / 32768;

      const source = context.createBufferSource();
      source.buffer = buffer;
      source.connect(context.destination);
      source.onended = () => {
        source.disconnect();
        if (queue !== response) return;
        response.sources.delete(source);
        response.playedSeconds = (response.playedSeconds || 0) + buffer.duration;
        drain(response);
      };
      source.start(start);
      response.sources.add(source);

      response.until = end;
      source.scheduledStart = start;
      if (firstFrame) onScheduled({ responseId: id, delayMs: (start - now) * 1000 });
    }

    function drain(response) {
      if (!response.finished || response.sources.size) return;
      queue = null;
      onDrained(response.id);
    }

    function finish(id) {
      if (!queue) {
        onDrained(id);
      } else if (queue.id === id) {
        queue.finished = true;
        drain(queue);
      }
    }

    function clear(id) {
      if (!queue || queue.id !== id) return 0;
      const response = queue;
      queue = null;
      const now = context.currentTime;
      let played = response.playedSeconds || 0;
      for (const source of response.sources) {
        played += Math.max(0, Math.min(source.buffer.duration, now - source.scheduledStart));
        source.onended = null;
        source.disconnect();
        source.stop();
      }
      return Math.round(played * 1000);
    }

    return { enqueue, finish, clear };
  }

  root.LumiPcmPlayback = createPcmPlayback;
})(globalThis);
