/* ============================================================
 * assets/core/migrate.js —— 旧 Origin 过渡迁移（只跑在**旧 Origin**上）
 * 作用：切换到本地资源前，先把旧 Origin 里排队的待补交学习记录交完。
 * 判定标准：以服务器实际受理为准（Learn.flush 的 sent 列表），
 *           不能只看本地队列是否为空；失败/未登录则保留队列，下次启动重试。
 * 不复制 token、不清旧存储、不跨 Origin 读写。
 * ============================================================ */
window.LumiMigrate = (function () {
  'use strict';

  function report(msg) {
    try {
      if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.lumiMigrate) {
        window.webkit.messageHandlers.lumiMigrate.postMessage(msg);
      }
    } catch (e) { /* 网页环境下没有原生桥，忽略 */ }
  }

  function run() {
    var out = { ok: false, remaining: -1, sent: 0, dead: 0, before: 0, error: null };
    return Promise.resolve().then(function () {
      if (!window.DB || !window.Learn || !window.StudyQueue) throw new Error('学习模块未加载');
      return window.DB.ready();
    }).then(function (r) {
      if (!r || !r.user_id) throw new Error('旧入口未登录，无法自动补交');
      return window.StudyQueue.count();
    }).then(function (n) {
      out.before = n;
      return window.Learn.flush();
    }).then(function (res) {
      res = res || {};
      out.sent = (res.sent || []).length;
      out.dead = (res.dead || []).length;
      return window.StudyQueue.count();
    }).then(function (left) {
      out.remaining = left;
      out.ok = left === 0 && out.dead === 0;
      report(out);
      return out;
    }).catch(function (e) {
      out.error = String((e && e.message) || e);
      // 失败时仍要给出真实剩余量（记录都还在本机，不能因为异常就报 -1）
      var q = window.StudyQueue && window.StudyQueue.count ? window.StudyQueue.count() : Promise.resolve(-1);
      return Promise.resolve(q).catch(function () { return -1; }).then(function (left) {
        out.remaining = left;
        out.ok = false;
        report(out);
        return out;
      });
    });
  }

  return { run: run };
})();
