/* ============================================================
 * assets/core/companion.js —— Q 版 Lumi 角色接口（只留接口，不含素材/动画实现）
 * 目的：STAGE 12 只定义契约与事件，真实 Q 版动画由 Codex/ChatGPT 独立制作后挂载。
 * 约束：零 AI 调用、零网络请求、不遮挡点击、失败不得影响学习主流程。
 * 对外：window.LumiCompanion
 *   init(cfg) / mount(adapter) / release()
 *   show() / hide() / play(name) / bubble(text,opts) / pause() / resume() / state()
 *   emit(event, detail) / on(fn) / off(fn)
 * ============================================================ */
window.LumiCompanion = (function () {
  'use strict';

  var EVENTS = ['page_enter', 'page_leave', 'study_start', 'answer_correct', 'answer_wrong',
    'word_completed', 'group_completed', 'review_completed', 'reading_start', 'writing_start',
    'streak_reached', 'daily_goal_reached', 'companion_tap',
    'app_background', 'app_foreground', 'audio_start', 'audio_end'];

  var state = 'idle';          // idle | visible | paused | released
  var adapter = null;          // 由原生/动画层注入，未注入时全部操作安全空转
  var listeners = [];
  var log = [];
  var cfg = { enabled: true, maxLog: 200 };
  var bubbleSeq = 0;

  function safe(fn, args) {
    try { return fn.apply(null, args || []); } catch (e) { return null; }
  }

  function record(kind, payload) {
    log.push({ t: Date.now(), kind: kind, payload: payload === undefined ? null : payload });
    if (log.length > cfg.maxLog) log.shift();
  }

  function emit(event, detail) {
    if (!cfg.enabled) return false;
    if (EVENTS.indexOf(event) < 0) return false;
    record('event', { event: event, detail: detail === undefined ? null : detail });
    if (adapter && typeof adapter.event === 'function') safe(adapter.event, [event, detail]);
    for (var i = 0; i < listeners.length; i++) safe(listeners[i], [event, detail]);
    return true;
  }

  function call(op, args) {
    record(op, args);
    if (state === 'released' && op !== 'init') return null;
    if (!adapter) {
      // 未挂载真实角色时，只维护状态，不创建任何 DOM，也不抛错。
      if (op === 'show') state = 'visible';
      if (op === 'hide') state = 'idle';
      if (op === 'pause') state = state === 'visible' ? 'paused' : state;
      if (op === 'resume') state = state === 'paused' ? 'visible' : state;
      return null;
    }
    var fn = adapter[op];
    if (typeof fn !== 'function') return null;
    return safe(fn, args);
  }

  function init(options) {
    cfg.enabled = !(options && options.enabled === false);
    state = 'idle';
    record('init', options || null);
    if (adapter && typeof adapter.init === 'function') safe(adapter.init, [options || {}]);
    return { ok: true, events: EVENTS.slice() };
  }

  function mount(a) {
    adapter = a && typeof a === 'object' ? a : null;
    if (adapter && typeof adapter.init === 'function') safe(adapter.init, [cfg]);
    return !!adapter;
  }

  return {
    EVENTS: EVENTS,
    init: init,
    mount: mount,
    release: function () { state = 'released'; adapter = null; listeners = []; record('release'); return true; },
    show: function () { return call('show', []); },
    hide: function () { return call('hide', []); },
    play: function (name) { return call('play', [name]); },
    bubble: function (text, opts) { bubbleSeq += 1; return call('bubble', [String(text || ''), opts || {}, bubbleSeq]); },
    pause: function () { return call('pause', []); },
    resume: function () { return call('resume', []); },
    tap: function () { emit('companion_tap'); return call('tap', []); },
    state: function () { return { state: state, mounted: !!adapter, enabled: cfg.enabled, logLength: log.length }; },
    emit: emit,
    on: function (fn) { if (typeof fn === 'function') listeners.push(fn); },
    off: function (fn) { listeners = listeners.filter(function (x) { return x !== fn; }); },
    debug: function () { return log.slice(); },
    _reset: function () { log = []; state = 'idle'; }
  };
})();
