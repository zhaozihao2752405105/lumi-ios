/* ============================================================
 * assets/core/library.js —— 离线词库（IndexedDB）
 * 目的：把一本真实词书的词条存到本机，断网也能查词、看释义与例句。
 * 数据来源：只走 window.DB.rpc('wordbook_preview')，不写死、不 AI 生成。
 * 键：DB `lumi-library` v1，store `books`（key = book_id）
 * 记录：{book_id, name, ver, at, limit, truncated, count, words:[{word,phonetic,meaning,example}]}
 * 说明：这里存的是“词条内容”，离线答题任务仍由学习队列负责；两者不混。
 * ============================================================ */
window.LumiLibrary = (function () {
  'use strict';
  var DB_NAME = 'lumi-library';
  var DB_VER = 1;
  var STORE = 'books';
  var MAX_WORDS = 5000;
  var PAGE = 1000;
  var STALE_DAYS = 30;

  var dbPromise = null;
  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve, reject) {
      if (!window.indexedDB) { reject(new Error('这台设备不支持离线词库')); return; }
      var req = window.indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: 'book_id' });
        }
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error('打开离线词库失败')); };
    });
    return dbPromise;
  }

  function tx(mode, fn) {
    return open().then(function (db) {
      return new Promise(function (resolve, reject) {
        var t = db.transaction(STORE, mode);
        var store = t.objectStore(STORE);
        var out;
        try { out = fn(store); } catch (e) { reject(e); return; }
        t.oncomplete = function () {
          var v = (out && typeof out === 'object' && 'result' in out) ? out.result : out;
          resolve(v);
        };
        t.onerror = function () { reject(t.error || new Error('离线词库读写失败')); };
        t.onabort = function () { reject(t.error || new Error('离线词库事务中断')); };
      });
    });
  }

  function getRpc() {
    if (!window.DB || typeof window.DB.rpc !== 'function') return null;
    return window.DB.rpc;
  }
  function unwrap(res) {
    if (res && res.error) throw new Error(res.error.message || String(res.error));
    return res && res.data !== undefined ? res.data : res;
  }

  function list() {
    return tx('readonly', function (store) {
      var out = [];
      var req = store.openCursor();
      req.onsuccess = function () {
        var cur = req.result;
        if (!cur) return;
        var r = cur.value;
        out.push({
          book_id: r.book_id, name: r.name, count: r.count || (r.words || []).length,
          at: r.at, ver: r.ver, truncated: !!r.truncated, limit: r.limit || 0
        });
        cur.continue();
      };
      return {
        get result() { return out; }
      };
    }).then(function (v) { return v || []; });
  }

  function get(bookId) {
    if (!bookId) return Promise.resolve(null);
    return tx('readonly', function (store) {
      var req = store.get(String(bookId));
      return { get result() { return req.result; } };
    }).then(function (v) { return v || null; });
  }

  function remove(bookId) {
    return tx('readwrite', function (store) {
      store.delete(String(bookId));
      return true;
    });
  }

  function isStale(rec, days) {
    if (!rec || !rec.at) return true;
    var max = (days || STALE_DAYS) * 86400000;
    return (Date.now() - rec.at) > max;
  }

  // 分批拉取：优先用 p_offset 续页（服务端不支持时会重复返回同一批，靠 word 去重兜底）
  function fetchWords(bookId, onProgress) {
    var rpc = getRpc();
    if (!rpc) return Promise.reject(new Error('离线词库需要登录后使用'));
    var seen = {};
    var words = [];
    var offset = 0;
    var truncated = false;

    function step() {
      return rpc('wordbook_preview', { p_book_id: bookId, p_limit: PAGE, p_offset: offset }).then(function (raw) {
        var res = unwrap(raw) || {};
        var batch = res.words || [];
        var added = 0;
        for (var i = 0; i < batch.length; i++) {
          var w = batch[i] || {};
          var key = String(w.word || '').toLowerCase();
          if (!key || seen[key]) continue;
          seen[key] = 1;
          words.push({
            word: String(w.word || ''), phonetic: w.phonetic || '', meaning: w.meaning || '',
            example: w.example || '', pos: w.pos || ''
          });
          added += 1;
        }
        if (onProgress) onProgress({ count: words.length, batch: batch.length, offset: offset });
        offset += batch.length;
        if (!batch.length || added === 0) return words;          // 没有新词了，说明到底
        if (words.length >= MAX_WORDS) { truncated = batch.length >= PAGE; return words; }
        return step();
      });
    }
    return step().then(function (w) { return { words: w, truncated: truncated, limit: MAX_WORDS }; });
  }

  function download(bookId, meta, onProgress) {
    if (!bookId) return Promise.reject(new Error('缺少词书 ID'));
    return fetchWords(bookId, onProgress).then(function (r) {
      var rec = {
        book_id: String(bookId),
        name: (meta && meta.name) || String(bookId),
        ver: (meta && meta.ver) || 1,
        at: Date.now(),
        limit: r.limit,
        truncated: !!r.truncated,
        count: r.words.length,
        words: r.words
      };
      return tx('readwrite', function (store) {
        store.put(rec);
        return { book_id: rec.book_id, count: rec.count, truncated: rec.truncated, at: rec.at };
      }).then(function (out) { return out; });
    });
  }

  function stats() {
    return list().then(function (rows) {
      var words = 0, bytes = 0;
      rows.forEach(function (r) { words += r.count || 0; });
      return get(rows.map(function (r) { return r.book_id; })).then(function () { return rows; }).then(function (list) {
        return { books: list.length, words: words, bytes: bytes };
      });
    });
  }

  return { list: list, get: get, remove: remove, download: download, isStale: isStale, stats: stats, MAX_WORDS: MAX_WORDS, STALE_DAYS: STALE_DAYS };
})();
