/* ============================================================
 * assets/core/lesson.js —— 第 4 步内容层（语法 / 听力 / 阅读 / 口语）
 * 职责：决定难度与领域 → 取当天内容（三级降级）→ 读写 lesson_content → 记错题
 * 不做：不渲染页面、不直接调 fetch、不写 SQL、不碰 words 学习引擎
 * ============================================================ */
(function () {
  'use strict';

  var MODULES = ['grammar', 'listening', 'reading', 'writing', 'speaking'];
  var MODULE_INDEX = { grammar: 0, listening: 1, reading: 2, writing: 4, speaking: 3 };
  var MODULE_LABEL = { grammar: '语法', listening: '听力', reading: '阅读', writing: '写作', speaking: '口语' };

  var state = {
    uid: null,
    dayIndex: 0,
    level: 1,
    prefs: {},
    difficultyReady: false,
    difficultyOffline: null,
    cache: {},           // module -> row
    aiBlocked: false,    // 402 之后本页不再试 AI
    blockMessage: '',
    lastError: null
  };

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function todayStr() {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function daysBetween(a, b) {
    var x = new Date(a + 'T00:00:00');
    var y = new Date(b + 'T00:00:00');
    return Math.floor((y - x) / 86400000);
  }

  // ---------- 难度与领域 ----------
  // 基线按「第几天」：0-6 天 level1，7-13 天 level2，14 天起 level3（与 010 new_target 阶段一致）
  function baseLevel(dayIdx) {
    if (dayIdx < 7) return 1;
    if (dayIdx < 14) return 2;
    return 3;
  }
  // B2：难度由 Adaptive 统一算（近 14 天加权正确率 + 样本量 + 至少 2 个学习日），
  // 不再用「最近 3 个任务」的 N+1 查询。读不到就保持基线，不阻塞学习。
  async function accuracyAdjust(uid, base) {
    try {
      if (!window.Adaptive || !window.Adaptive.get) return base;
      var a = await window.Adaptive.get(uid);
      if (!a || !a.level || typeof a.level.suggested !== 'number') return base;
      return Math.max(1, Math.min(3, a.level.suggested));
    } catch (e) {
      return base;
    }
  }
  // 默认通用日常主题；不按学习天数强制引入行业主题。
  function domainPool(dayIdx) {
    return ['gen'];
  }
  function domainFor(dayIdx) {
    var p = domainPool(dayIdx);
    return p[Math.max(0, dayIdx) % p.length];
  }

  // ---------- 初始化 ----------
  let readyInFlight;
  async function ensureReady() {
    if (!window.DB) throw new Error('数据层没加载');
    var uid = await window.DB.auth.getUserId();
    if (!uid) throw new Error('还没登录，请先登录');
    if (state.uid && state.uid !== uid) {
      state.cache = {}; state.prefs = {}; state.difficultyReady = false; state.difficultyOffline = null;
      state.aiBlocked = false; state.blockMessage = '';
    }
    if (readyInFlight?.uid === uid) return readyInFlight.promise;
    if (state.uid === uid) return uid;
    state.uid = uid;
    const promise = initialize(uid).finally(function () {
      if (readyInFlight?.promise === promise) readyInFlight = null;
    });
    readyInFlight = { uid, promise };
    return promise;
  }

  async function initialize(uid) {
    const prefs = loadPrefs(uid);
    var today = todayStr();
    // 断网时 daily_task 读不到：用上次缓存的「第几天 / 难度」，没有就用第 0 天，不阻塞离线查看
    try {
      var first = await window.DB.select('daily_task', { user_id: uid, order: 'study_date.asc', limit: 1 });
      var firstDate = (first && first.length) ? first[0].study_date : today;
      state.dayIndex = Math.max(0, daysBetween(firstDate, today));
      var base = baseLevel(state.dayIndex);
      state.level = await accuracyAdjust(uid, base);
      if (window.OfflineCache) window.OfflineCache.putMeta(uid, { dayIndex: state.dayIndex, level: state.level, date: today });
    } catch (e) {
      var meta = window.OfflineCache ? window.OfflineCache.getMeta(uid) : null;
      if (meta && typeof meta.dayIndex === 'number') {
        state.dayIndex = Math.max(0, Number(meta.dayIndex) || 0);
        state.level = Number(meta.level) || baseLevel(state.dayIndex);
      } else {
        state.dayIndex = 0;
        state.level = 1;
      }
      state.offline = true;
    }
    await prefs;
    return uid;
  }

  async function loadPrefs(uid) {
    const modern = window.Difficulty && await window.Difficulty.read();
    if (state.uid && state.uid !== uid) return state.prefs;
    state.difficultyReady = modern?.ok === true;
    state.difficultyOffline = state.difficultyReady || navigator.onLine !== false
      ? null : window.OfflineCache?.getMeta(uid)?.difficulty || null;
    if (!state.difficultyReady) {
      if (state.difficultyOffline) return state.prefs;
      try {
        const rows = await window.DB.select('profiles', { id: uid, limit: 1 });
        if (state.uid === uid) state.prefs = rows[0]?.study_prefs || {};
      } catch { /* keep the authenticated user's legacy defaults */ }
    }
    return state.prefs;
  }

  function moduleLevel(module) {
    if (hasVariantSupport()) {
      return window.LumiDifficulty.preference(state.difficultyOffline || window.Difficulty.current(), module).level;
    }
    const legacy = Number(state.prefs['level_' + module]);
    return [1, 2, 3].includes(legacy) ? legacy : state.level;
  }

  function difficultyOf(row, module) {
    return window.LumiDifficulty.fromVariant(row?.difficulty_variant) ||
      window.LumiDifficulty.legacy(Number(row?.content?.level) || state.level);
  }

  function levels() {
    return { adaptive: window.LumiDifficulty.legacy(state.level),
      listening: moduleLevel('listening'), reading: moduleLevel('reading') };
  }

  function offlineKey(module, variant) { return variant === 'legacy' ? module : module + ':' + variant; }
  function hasVariantSupport() { return state.difficultyReady || Boolean(state.difficultyOffline); }
  function cacheVariant(module) { return hasVariantSupport() ? window.LumiDifficulty.variant(moduleLevel(module)) : 'legacy'; }
  function contentQuery(uid, module, variant) {
    const query = { user_id: uid, lesson_date: todayStr(), module, limit: 1 };
    if (hasVariantSupport()) query.difficulty_variant = variant;
    return query;
  }

  function ready() { return ensureReady(); }

  function info() {
    return { dayIndex: state.dayIndex, level: state.level, domain: domainFor(state.dayIndex), aiBlocked: state.aiBlocked, blockMessage: state.blockMessage };
  }

  // ---------- 内容获取（三级降级） ----------
  function pickBuiltin(module, level, dayIdx) {
    var arr = (window.BUILTIN_LESSONS && window.BUILTIN_LESSONS[module]) || [];
    if (!arr.length) throw new Error('内置内容库为空：' + module);
    // 内置库仍保留历史内容，但默认选题仅使用通用主题（语法不带领域）。
    var general = arr.filter(function (it) { return !it.domain || it.domain === 'gen'; });
    if (!general.length) throw new Error('缺少通用内置内容：' + module);
    var fit = general.filter(function (it) { return it.level <= level; });
    if (!fit.length) fit = general;
    var idx = (Math.max(0, dayIdx) + MODULE_INDEX[module]) % fit.length;
    return JSON.parse(JSON.stringify(fit[idx]));
  }

  function isConflict(err) {
    var m = String((err && err.message) || '');
    return m.indexOf('duplicate key') !== -1 || m.indexOf('23505') !== -1 || m.indexOf('已存在') !== -1;
  }

  async function prevGrammarPoint(uid) {
    try {
      var rows = await window.DB.select('lesson_content', { user_id: uid, module: 'grammar', order: 'lesson_date.desc', limit: 1 });
      if (!rows || !rows.length) return '';
      var rs = rows[0].result || {};
      return String(rs.next_point || '').slice(0, 60);
    } catch (e) { return ''; }
  }

  async function saveRow(uid, module, variant, source, requestId, content) {
    var row = {
      user_id: uid,
      lesson_date: todayStr(),
      module: module,
      source: source,
      request_id: requestId || null,
      content: content,
      result: {}
    };
    if (variant !== 'legacy') row.difficulty_variant = variant;
    try {
      var ins = await window.DB.insert('lesson_content', row);
      var savedRow = (ins && ins[0]) ? ins[0] : null;
      if (savedRow && window.OfflineCache) window.OfflineCache.putLesson(uid, offlineKey(module, variant), savedRow);
      return savedRow;
    } catch (e) {
      if (!isConflict(e)) throw e;
      // 另一台设备同时生成了：读回来用已有的那条（后写覆盖内容没必要，保持先到者）
      var rows = await window.DB.select('lesson_content', contentQuery(uid, module, variant));
      return (rows && rows.length) ? rows[0] : null;
    }
  }

  // AI 内容本地修补：选项去重 + answer_index 重映射 + 坏题剔除（见 content-repair.js）
  function repairRow(module, row) {
    if (!row || !window.ContentRepair) return row;
    var fixed = window.ContentRepair.repair(module, row.content);
    var copy = {};
    for (var k in row) { if (Object.prototype.hasOwnProperty.call(row, k)) copy[k] = row[k]; }
    copy.content = fixed;
    return copy;
  }

  async function get(module, opts) {
    opts = opts || {};
    if (MODULES.indexOf(module) === -1) throw new Error('未知模块：' + module);
    var uid = await ensureReady();
    if (state.difficultyOffline && navigator.onLine === true) await loadPrefs(uid);
    if (module === 'writing' && !hasVariantSupport()) throw new Error('写作课程需要先同步难度设置。');
    const selected = moduleLevel(module);
    const variant = hasVariantSupport() ? window.LumiDifficulty.variant(selected) : 'legacy';
    var stored = state.cache[module];
    if (stored && stored.lesson_date === todayStr() && (stored.difficulty_variant || 'legacy') === variant && !opts.refresh) return stored;

    // 本机快照：断网时唯一的可用内容来源
    var snap = (window.OfflineCache && window.OfflineCache.getLesson(uid, offlineKey(module, variant))) || null;
    function useSnap() {
      if (!snap || !snap.row) return null;
      var r = repairRow(module, snap.row);
      r.offline = true;
      r.cached_date = snap.date || '';
      if (r.result && r.result.done) r.degraded = false;
      state.cache[module] = r;
      return r;
    }
    var offlineNow = (typeof navigator !== 'undefined' && navigator.onLine === false);

    // ① 当天已有 → 直接用（多端复用，不再花钱）
    try {
      var rows = await window.DB.select('lesson_content', contentQuery(uid, module, variant));
      if (rows && rows.length) {
        state.cache[module] = repairRow(module, rows[0]);
        if (window.OfflineCache) window.OfflineCache.putLesson(uid, offlineKey(module, variant), state.cache[module]);
        return state.cache[module];
      }
    } catch (e) {
      // 读失败（多半是断网）：有本机快照就先让用户看，记录稍后补交
      var gotSnap = useSnap();
      if (gotSnap) return gotSnap;
    }

    // ② 调 AI 生成（402/断网/未登录都降级，不抛到页面）
    var source = 'ai', reqId = null;
    var aiOn = !!(window.APP_CONFIG && window.APP_CONFIG.FEATURES && window.APP_CONFIG.FEATURES.AI_GENERATE === true);
    if (module !== 'writing' && aiOn && !state.aiBlocked && window.AI && !offlineNow) {
      var payload = variant === 'legacy' ? { level: selected } : window.Difficulty.contentParams(selected);
      if (module === 'grammar') {
        payload.point = await prevGrammarPoint(uid);
      } else {
        payload.domain = domainFor(state.dayIndex);
      }
      reqId = window.AI.newRequestId('lesson-' + module);
      // 跨模块联动：用本地规则挑 3-8 个目标词（未掌握优先），塞进生成上下文，不额外调模型
      try {
        if (window.LumiPlan && module !== 'speaking') {
          var focus = window.LumiPlan.focusWords(module, selected, module === 'reading' ? 6 : 4);
          if (focus && focus.length) payload.focus_words = focus;
        }
      } catch (e) { /* 联动失败不影响生成 */ }
      var res = await window.AI.invoke(module, payload, { requestId: reqId });
      var fixed = (res && res.ok && res.data && window.ContentRepair)
        ? window.ContentRepair.repair(module, res.data)
        : (res && res.data);
      // 修补后连 2 道题都不够（模型输出质量太差）→ 不用它，走内置库
      var enough = module === 'speaking' ? Boolean(fixed?.topic && fixed?.prompts_zh?.length) :
        !window.ContentRepair || window.ContentRepair.questionCount(module, fixed) >= 2;
      if (res && res.ok && res.data && enough) {
        var row = await saveRow(uid, module, variant, 'ai', reqId, fixed);
        if (row) {
          row.cached = false; row.degraded = false;
          state.cache[module] = row;
          return row;
        }
      } else if (res && res.ok && res.data) {
        state.lastError = 'ai_content_repair_failed';
      } else if (res && res.budgetBlocked) {
        state.aiBlocked = true;
        state.blockMessage = res.message || '本月 AI 预算已用完，先用内置内容继续学';
      } else {
        state.lastError = (res && (res.code || res.message)) || 'ai_failed';
      }
    }

    // ③ 内置库兜底
    source = 'builtin';
    const band = variant === 'legacy' ? selected : Math.ceil(selected / 3);
    var builtin = module === 'writing' ? { title: '写作练习', prompt: window.LumiDifficulty.level(selected).writing,
      target_words: 25 + selected * 15 } : pickBuiltin(module, band, state.dayIndex);
    if (window.ContentRepair && module !== 'writing') builtin = window.ContentRepair.repair(module, builtin);
    if (variant !== 'legacy' && module !== 'writing') builtin.lumi_fallback_band = band;
    var saved = null;
    try {
      saved = await saveRow(uid, module, variant, 'builtin', null, builtin);
    } catch (e) {
      var fallbackSnap = useSnap();
      if (fallbackSnap) return fallbackSnap;
      throw new Error('现在没有网络，这个模块今天的内容还没缓存到本机；联网后再打开就好，其他模块不受影响。');
    }
    if (!saved) {
      var nullSnap = useSnap();
      if (nullSnap) return nullSnap;
      throw new Error('内容保存失败，请刷新重试');
    }
    saved.cached = false;
    saved.degraded = aiOn && module !== 'writing'; // 只有本应调用 AI 却失败时才提示降级
    state.cache[module] = saved;
    return saved;
  }

  // ---------- 结果读写 ----------
  // 进度写入走离线队列：断网时先排在本机，联网后自动补交（同一课程行只保留最新一份）
  async function saveResult(module, patch) {
    var uid = await ensureReady();
    var row = state.cache[module];
    if (!row) throw new Error('还没加载这个模块的内容');
    var merged = Object.assign({}, row.result || {}, patch || {});
    merged.updated_at = new Date().toISOString();
    var out = await window.Learn.saveLessonResult(row.id, merged);
    if (out.status === 'failed' || out.status === 'dead') throw new Error(out.message || '内容保存失败');
    row.result = merged;
    row.offline = out.status === 'queued';
    try { if (window.OfflineCache) window.OfflineCache.patchLessonResult(uid, offlineKey(module, row.difficulty_variant || 'legacy'), merged); } catch (e) {}
    if (out.status === 'queued' && !state.warnedOffline) {
      state.warnedOffline = true;
      if (typeof toast === 'function') toast('网络不太好：进度已存在本机，联网后自动补交');
    }
    return merged;
  }
  function done(module) { return !!(state.cache[module] && state.cache[module].result && state.cache[module].result.done); }
  function finish(module, extra) {
    var patch = Object.assign({ done: true, done_at: new Date().toISOString() }, extra || {});
    return saveResult(module, patch);
  }

  // ---------- 错题 ----------
  async function saveMistake(module, payload) {
    var uid = await ensureReady();
    payload = payload || {};
    var row = state.cache[module];
    var refId = payload.ref_id || (row && row.id) || null;
    var q = String(payload.question || '').slice(0, 500);
    if (!q) return false;
    try {
      // id 由「模块+来源+题面」确定：同一题重复记录会落到同一行，离线补交也不会产生重复
      var out = await window.Learn.saveMistakeRow({
        id: window.Learn.mistakeId(uid, module, refId, q),
        user_id: uid,
        kind: module,
        ref_id: refId,
        question: q,
        user_answer: String(payload.user_answer == null ? '' : payload.user_answer).slice(0, 300),
        correct_answer: String(payload.correct_answer == null ? '' : payload.correct_answer).slice(0, 300),
        explain_zh: String(payload.explain_zh || '').slice(0, 500),
        // 阶段 2：把当时那道题的白名单上下文一起存下来（旧调用方没传就是 null，向后兼容）
        context: payload.context || null
      });
      if (out.status === 'failed' || out.status === 'dead') { state.lastError = out.message; return false; }
      return true;
    } catch (e) {
      state.lastError = e.message;
      return false;
    }
  }

  // ---------- 今日四模块总览（给首页/顶栏用） ----------
  async function progress() {
    var uid = await ensureReady();
    var out = { grammar: false, listening: false, reading: false, writing: false, speaking: false };
    try {
      var rows = await window.DB.select('lesson_content', { user_id: uid, lesson_date: todayStr() });
      for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        if (Object.prototype.hasOwnProperty.call(out, r.module) && r.result?.done) out[r.module] = true;
        if ((r.difficulty_variant || 'legacy') !== cacheVariant(r.module)) continue;
        // 首页总览预读也走修补：否则 get() 命中未修补的缓存会跳过 ContentRepair
        state.cache[r.module] = state.cache[r.module] || repairRow(r.module, r);
        if (window.OfflineCache) window.OfflineCache.putLesson(uid, offlineKey(r.module, r.difficulty_variant || 'legacy'), r);
      }
    } catch (e) {
      // 断网：用本机快照算四模块完成情况
      if (window.OfflineCache) {
        for (var mi = 0; mi < MODULES.length; mi++) {
          var gm = window.OfflineCache.getLesson(uid, offlineKey(MODULES[mi], cacheVariant(MODULES[mi])));
          if (!gm || !gm.row) continue;
          var gr = gm.row;
          if (gr.result && gr.result.done) out[MODULES[mi]] = true;
          state.cache[MODULES[mi]] = state.cache[MODULES[mi]] || repairRow(MODULES[mi], gr);
        }
      }
    }
    var n = 0; for (var k in out) if (out[k]) n++;
    out.done_count = n;
    out.total = MODULES.length;
    return out;
  }

  window.Lesson = {
    MODULES: MODULES,
    MODULE_LABEL: MODULE_LABEL,
    ready: ready,
    todayStr: todayStr,
    info: info,
    domainFor: domainFor,
    levelFor: function () { return state.level; },
    levels: levels,
    difficultyOf: difficultyOf,
    loadPrefs: loadPrefs,
    get: get,
    saveResult: saveResult,
    finish: finish,
    done: done,
    saveMistake: saveMistake,
    progress: progress,
    state: state
  };
})();
