/* ============================================================
 * assets/core/goals.js —— 用户自定义学习目标（STAGE 08）
 * 设计约束：
 *   1) 不改服务端表结构、不加迁移；目标只存本机（按账号隔离）。
 *   2) 目标与首页进度环、统计、提醒读同一份配置，避免三处不一致。
 *   3) 跨日按“用户设置时的时区偏移”结算；偏移变化只结算一次，不重复扣减。
 * 键：lumi.goals.v1.<uid>
 * 结构：{ v:1, newWords:10, review:20, listening:1, reading:1, minutes:0,
 *        tz: -480, day:"YYYY-MM-DD", settledAt:ms, unlimited:{...} }
 * ============================================================ */
window.LumiGoals = (function () {
  'use strict';
  var PREFIX = 'lumi.goals.v1.';
  var DEFAULTS = { v: 1, newWords: 10, review: 20, listening: 1, reading: 1, minutes: 0 };
  var CHOICES = {
    newWords: [5, 10, 15, 20],
    review: [10, 20, 30, 0],
    listening: [0, 1, 2],
    reading: [0, 1, 2],
    minutes: [0, 15, 30, 45]
  };
  var LABELS = {
    newWords: '今日新词', review: '今日复习', listening: '听力篇数',
    reading: '阅读篇数', minutes: '学习时长'
  };

  function uid() {
    try { if (window.DB && window.DB.auth && window.DB.auth.peekUser) { var u = window.DB.auth.peekUser(); if (u && u.id) return u.id; } } catch (e) { }
    try { var raw = localStorage.getItem('eng45.user'); if (raw) { var o = JSON.parse(raw); if (o && o.id) return o.id; } } catch (e) { }
    return 'anon';
  }
  function key(id) { return PREFIX + String(id || uid()); }
  function tzNow() { return new Date().getTimezoneOffset(); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dayAt(offset, at) {
    var d = new Date((at || Date.now()) - (Number(offset) || 0) * 60000);
    return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate());
  }
  function read(id) {
    try {
      var raw = localStorage.getItem(key(id));
      if (!raw) return null;
      var o = JSON.parse(raw);
      return (o && typeof o === 'object') ? o : null;
    } catch (e) { return null; }
  }
  function normalize(o) {
    var out = { v: 1 };
    Object.keys(DEFAULTS).forEach(function (k) {
      if (k === 'v') return;
      var has = !!(o && Object.prototype.hasOwnProperty.call(o, k));
      var v = has ? Number(o[k]) : NaN;
      out[k] = (CHOICES[k].indexOf(v) >= 0) ? v : DEFAULTS[k];
    });
    out.tz = (o && typeof o.tz === 'number') ? o.tz : tzNow();
    out.day = (o && o.day) || dayAt(out.tz);
    out.settledAt = (o && o.settledAt) || Date.now();
    return out;
  }
  function get(id) {
    var o = read(id);
    if (!o) return normalize(null);
    var n = normalize(o);
    // 跨日结算：只有 day 变化才写回一次，避免同一天反复写
    var today = dayAt(n.tz);
    if (n.day !== today) {
      n.prevDay = n.day;
      n.day = today;
      n.settledAt = Date.now();
      save(n, id);
    }
    return n;
  }
  function save(o, id) {
    var n = normalize(o);
    n.day = dayAt(n.tz);
    n.settledAt = Date.now();
    try { localStorage.setItem(key(id), JSON.stringify(n)); } catch (e) { }
    try { window.dispatchEvent(new CustomEvent('lumi:goals', { detail: n })); } catch (e) { }
    return n;
  }
  function set(patch, id) {
    var cur = get(id);
    Object.keys(patch || {}).forEach(function (k) {
      if (k === 'tz') { cur.tz = Number(patch.tz); return; }
      if (CHOICES[k] && CHOICES[k].indexOf(Number(patch[k])) >= 0) cur[k] = Number(patch[k]);
    });
    return save(cur, id);
  }
  function label(k, v) {
    var n = Number(v);
    if (k === 'minutes') return n > 0 ? n + ' 分钟' : '不限时长';
    if (k === 'review' && n === 0) return '不限篇数'.replace('篇数', '数量');
    if (n === 0) return '不安排';
    return n + (k === 'newWords' ? ' 个' : (k === 'review' ? ' 个' : ' 篇'));
  }
  function summary(id) {
    var g = get(id);
    return '新词 ' + label('newWords', g.newWords) + ' · 复习 ' + label('review', g.review) +
      ' · 听力 ' + label('listening', g.listening) + ' · 阅读 ' + label('reading', g.reading) +
      ' · ' + label('minutes', g.minutes);
  }
  function tzLabel(id) {
    var g = get(id);
    var off = -Number(g.tz) / 60;
    var sign = off >= 0 ? '+' : '-';
    var a = Math.abs(off);
    return 'UTC' + sign + Math.floor(a) + (a % 1 ? ':' + pad(Math.round((a % 1) * 60)) : '');
  }
  return {
    DEFAULT: DEFAULTS, CHOICES: CHOICES, LABELS: LABELS,
    get: get, set: set, save: save, summary: summary, label: label, tzLabel: tzLabel,
    dayKey: function (id) { return get(id).day; }, key: key,
    _dayAt: dayAt, _norm: normalize
  };
})();
