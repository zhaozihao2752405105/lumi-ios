/* ============================================================
 * assets/core/launch.js —— 启动动画接口（方案 C：只留接口，不含素材）
 * 与初始化并行：动画层监听 phase，页面初始化完成即 handoff；
 * 最多 1–2s，可被用户点击/减少动效快速结束；后台恢复不重播。
 * 对外：window.LumiLaunch
 * ============================================================ */
window.LumiLaunch = (function () {
  'use strict';

  var KEY = 'lumi.launch.v1';
  var MAX_MS = 1600;
  var state = 'idle';
  var startedAt = 0;
  var timer = null;
  var waiters = [];
  var listeners = [];
  var cfg = { maxMs: MAX_MS, reduced: false };

  function reducedMotion() {
    try { return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; }
  }
  function played() {
    try { return window.sessionStorage.getItem(KEY) === '1'; } catch (e) { return false; }
  }
  function markPlayed() {
    try { window.sessionStorage.setItem(KEY, '1'); } catch (e) { /* 忽略 */ }
  }
  function emitPhase(phase, detail) {
    var payload = { phase: phase, detail: detail === undefined ? null : detail, elapsed: state === 'idle' ? 0 : Date.now() - startedAt };
    for (var i = 0; i < listeners.length; i++) {
      try { listeners[i](payload); } catch (e) { /* 动画层出错不影响启动 */ }
    }
    return payload;
  }
  function settle(phase, detail) {
    if (state === 'handoff' || state === 'cancelled') return false;
    state = phase;
    if (timer) { clearTimeout(timer); timer = null; }
    markPlayed();
    emitPhase(phase, detail);
    var list = waiters; waiters = [];
    for (var i = 0; i < list.length; i++) {
      try { list[i]({ ok: true, phase: phase, elapsed: Date.now() - startedAt }); } catch (e) { }
    }
    return true;
  }

  return {
    // 是否应该播放：后台恢复、已播过、减少动效 → 不播
    shouldPlay: function () {
      if (played()) return false;
      if (reducedMotion()) return false;
      if (document.visibilityState === 'hidden') return false;
      return true;
    },
    // 启动：与页面初始化并行，返回 Promise（handoff/skip/超时都会 resolve）
    boot: function (options) {
      cfg.maxMs = Math.max(400, Math.min(2000, (options && options.maxMs) || MAX_MS));
      if (!this.shouldPlay()) { state = 'cancelled'; emitPhase('cancelled', 'skipped'); return Promise.resolve({ ok: true, phase: 'cancelled', elapsed: 0 }); }
      state = 'playing'; startedAt = Date.now(); markPlayed();
      emitPhase('playing');
      var self = this;
      return new Promise(function (resolve) {
        waiters.push(resolve);
        timer = setTimeout(function () { self.handoff('timeout'); }, cfg.maxMs);
      });
    },
    handoff: function (reason) { return settle('handoff', reason || 'ready'); },
    skip: function () { return settle('cancelled', 'skip'); },
    cancel: function () { return settle('cancelled', 'cancel'); },
    state: function () { return { state: state, elapsed: state === 'idle' ? 0 : Date.now() - startedAt, maxMs: cfg.maxMs, played: played(), reduced: reducedMotion() }; },
    on: function (fn) { if (typeof fn === 'function') listeners.push(fn); },
    off: function (fn) { listeners = listeners.filter(function (x) { return x !== fn; }); },
    _reset: function () { try { window.sessionStorage.removeItem(KEY); } catch (e) { } state = 'idle'; startedAt = 0; if (timer) { clearTimeout(timer); timer = null; } waiters = []; }
  };
})();
