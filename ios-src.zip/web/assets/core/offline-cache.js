/* ============================================================
 * assets/core/offline-cache.js —— 离线内容缓存（localStorage）
 * 目的：断网时打开 today / review / lesson 不再只看到「加载失败」，
 *       而是显示上一次同步下来的内容，本机记录照常排队补交。
 * 只存「公共内容 + 当天任务快照」，不存密码、不存 token。
 * 键：eng45.off.v1.<userId>
 * 结构：{ date:"YYYY-MM-DD", task:{...}, lessons:{grammar:row,...},
 *         meta:{dayIndex,level}, savedAt:ms }
 * ============================================================ */
window.OfflineCache = (function () {
  'use strict';
  var PREFIX = 'eng45.off.v1.';

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function today() {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function key(uid) { return PREFIX + String(uid || 'anon'); }

  function read(uid) {
    try {
      var raw = window.localStorage.getItem(key(uid));
      if (!raw) return {};
      var o = JSON.parse(raw);
      return (o && typeof o === 'object') ? o : {};
    } catch (e) { return {}; }
  }
  function write(uid, o) {
    try {
      o.savedAt = Date.now();
      window.localStorage.setItem(key(uid), JSON.stringify(o));
      return true;
    } catch (e) {
      // 容量满：先丢掉模块内容，只保任务快照
      try {
        var slim = { date: o.date, task: o.task, meta: o.meta, savedAt: Date.now() };
        window.localStorage.setItem(key(uid), JSON.stringify(slim));
        return true;
      } catch (e2) { return false; }
    }
  }
  function clone(o) {
    try { return JSON.parse(JSON.stringify(o)); } catch (e) { return o; }
  }

  // ---------- 今日任务快照 ----------
  function putTask(uid, task) {
    if (!uid || !task) return false;
    var o = read(uid);
    o.date = today();
    o.task = clone(task);
    return write(uid, o);
  }
  function getTask(uid) {
    if (!uid) return null;
    var o = read(uid);
    if (!o.task) return null;
    return { task: clone(o.task), date: o.date || '', savedAt: o.savedAt || 0, stale: (o.date || '') !== today() };
  }
  // 本机完成/跳过后同步快照状态，下次离线进入进度是对的
  function patchTaskItem(uid, itemId, status, finalResult) {
    if (!uid || !itemId) return false;
    var o = read(uid);
    var items = (o.task && o.task.items) || [];
    var hit = false;
    for (var i = 0; i < items.length; i++) {
      if (items[i].item_id === itemId || items[i].id === itemId) {
        items[i].status = status;
        if (finalResult) items[i].final_result = finalResult;
        hit = true;
        break;
      }
    }
    if (!hit) return false;
    return write(uid, o);
  }
  function removeTaskItem(uid, itemId) {
    if (!uid || !itemId) return false;
    var o = read(uid);
    var items = (o.task && o.task.items) || [];
    var next = [];
    for (var i = 0; i < items.length; i++) {
      if (items[i].item_id === itemId || items[i].id === itemId) continue;
      next.push(items[i]);
    }
    if (next.length === items.length) return false;
    o.task.items = next;
    return write(uid, o);
  }

  // ---------- 四模块内容快照 ----------
  function putLesson(uid, module, row) {
    if (!uid || !module || !row) return false;
    var o = read(uid);
    o.lessons = o.lessons || {};
    o.lessons[module] = { date: today(), row: clone(row) };
    return write(uid, o);
  }
  function getLesson(uid, module) {
    if (!uid || !module) return null;
    var o = read(uid);
    var hit = o.lessons && o.lessons[module];
    if (!hit || !hit.row) return null;
    return { row: clone(hit.row), date: hit.date || '', stale: (hit.date || '') !== today() };
  }
  function patchLessonResult(uid, module, result) {
    var got = getLesson(uid, module);
    if (!got) return false;
    var row = got.row;
    row.result = Object.assign({}, row.result || {}, result || {});
    var o = read(uid);
    o.lessons = o.lessons || {};
    o.lessons[module] = { date: got.date, row: clone(row) };
    return write(uid, o);
  }

  // ---------- 难度/第几天元数据 ----------
  function putMeta(uid, meta) {
    if (!uid || !meta) return false;
    var o = read(uid);
    o.meta = Object.assign({}, o.meta || {}, meta);
    return write(uid, o);
  }
  function getMeta(uid) {
    if (!uid) return null;
    var o = read(uid);
    return o.meta ? clone(o.meta) : null;
  }

  function stats(uid) {
    var o = read(uid);
    var n = 0;
    for (var k in (o.lessons || {})) { if (Object.prototype.hasOwnProperty.call(o.lessons, k)) n++; }
    return {
      date: o.date || '',
      hasTask: !!o.task,
      items: (o.task && o.task.items) ? o.task.items.length : 0,
      lessons: n,
      savedAt: o.savedAt || 0
    };
  }
  function clear(uid) {
    try { window.localStorage.removeItem(key(uid)); return true; } catch (e) { return false; }
  }

  return {
    today: today,
    putTask: putTask, getTask: getTask, patchTaskItem: patchTaskItem, removeTaskItem: removeTaskItem,
    putLesson: putLesson, getLesson: getLesson, patchLessonResult: patchLessonResult,
    putMeta: putMeta, getMeta: getMeta,
    stats: stats, clear: clear
  };
})();
