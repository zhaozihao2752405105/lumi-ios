/* Lumi A3 免提连续对话（第一版）
 *
 * 目标：让语音对话像 ChatGPT 语音模式一样——不用每轮点麦克风；
 * AI 正在说话时用户直接开口就能打断。
 *
 * 设计约束（与项目既有约定一致）：
 * - 只用浏览器本机能力（getUserMedia + AnalyserNode），不新增付费接口、不上传音频；
 * - 只在「AI 正在朗读」时占用麦克风，AI 停下来就释放，避免两路麦克风同时开；
 * - 任何异常都静默降级：本模块失败不影响原有的点按麦克风流程。
 *
 * 开关：localStorage['lumi_rtv'] === '1'（或地址栏加 ?rtv=1）
 */
(function () {
  'use strict';

  var AC = window.AudioContext || window.webkitAudioContext;
  var ST = {
    ctx: null, stream: null, src: null, an: null, timer: null,
    active: false, armedAt: 0, loudMs: 0, lastLoud: 0, fired: false,
    opts: null
  };
  var M = {
    turns: 0, firstAudio: [], barge: [],
    userEndAt: 0, speakStartAt: 0, bargeStartAt: 0
  };

  function now() { return Date.now(); }

  function enabled() {
    try {
      if (/[?&]rtv=1\b/.test(location.search)) return true;
      return localStorage.getItem('lumi_rtv') === '1';
    } catch (e) { return false; }
  }

  function setEnabled(on) {
    try { localStorage.setItem('lumi_rtv', on ? '1' : '0'); } catch (e) { }
    if (!on) disarm();
  }

  function supported() {
    return !!(AC && navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  }

  function pct(arr, p) {
    if (!arr.length) return 0;
    var a = arr.slice().sort(function (x, y) { return x - y; });
    var i = Math.min(a.length - 1, Math.max(0, Math.round((a.length - 1) * p)));
    return a[i];
  }

  function release() {
    if (ST.timer) { clearInterval(ST.timer); ST.timer = null; }
    try { if (ST.src) ST.src.disconnect(); } catch (e) { }
    try { if (ST.an) ST.an.disconnect(); } catch (e) { }
    try { if (ST.stream) ST.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) { }
    try { if (ST.ctx && ST.ctx.state !== 'closed') ST.ctx.close(); } catch (e) { }
    ST.ctx = null; ST.stream = null; ST.src = null; ST.an = null;
    ST.active = false; ST.loudMs = 0; ST.lastLoud = 0; ST.fired = false;
  }

  function disarm() {
    if (!ST.active) { release(); return; }
    release();
  }

  /* 只在 AI 朗读期间挂麦克风监听；检测到用户开口就回调 onBarge。 */
  function arm(opts) {
    if (!supported() || ST.active) return false;
    ST.opts = opts || {};
    var threshold = ST.opts.threshold || 0.022;
    var needMs = ST.opts.needMs || 260;
    var guardMs = ST.opts.guardMs || 420;
    ST.armedAt = now(); ST.loudMs = 0; ST.lastLoud = 0; ST.fired = false;
    navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }
    }).then(function (stream) {
      if (ST.fired) { try { stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) { } return; }
      ST.stream = stream;
      try {
        ST.ctx = new AC();
        ST.ctx.resume();
        ST.src = ST.ctx.createMediaStreamSource(stream);
        ST.an = ST.ctx.createAnalyser();
        ST.an.fftSize = 1024;
        ST.an.smoothingTimeConstant = 0.5;
        ST.src.connect(ST.an);
      } catch (e) { release(); return; }
      ST.active = true;
      var buf = new Float32Array(ST.an.fftSize);
      ST.timer = setInterval(function () {
        if (!ST.active || !ST.an) return;
        var t = now();
        if (t - ST.armedAt < guardMs) return;   // 刚开口朗读的前 0.4 秒不判定，避免把自己声音当用户
        var sum = 0, i;
        try { ST.an.getFloatTimeDomainData(buf); } catch (e) { return; }
        for (i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
        var rms = Math.sqrt(sum / buf.length);
        if (rms > threshold) {
          ST.loudMs += 80;
          ST.lastLoud = t;
        } else if (t - ST.lastLoud > 400) {
          ST.loudMs = 0;                        // 静音超过 0.4 秒就重新计数，噪声不会累积
        }
        if (ST.loudMs >= needMs && !ST.fired) {
          ST.fired = true;
          M.bargeStartAt = t;
          var cb = ST.opts.onBarge;
          release();
          if (typeof cb === 'function') { try { cb({ at: t }); } catch (e) { } }
        }
      }, 80);
    }).catch(function () { release(); });
    return true;
  }

  /* ---------- 延迟埋点（用于验收报告：首响 P50、打断 P95） ---------- */
  function noteUserSpeechEnd() { M.userEndAt = now(); M.turns++; }
  function noteSpeakStart() {
    M.speakStartAt = now();
    if (M.userEndAt) {
      var d = M.speakStartAt - M.userEndAt;
      if (d >= 0 && d < 30000) M.firstAudio.push(d);
      M.userEndAt = 0;
    }
  }
  function noteBargeDone() {
    if (!M.bargeStartAt) return;
    var d = now() - M.bargeStartAt;
    if (d >= 0 && d < 5000) M.barge.push(d);
    M.bargeStartAt = 0;
  }

  function stats() {
    return {
      turns: M.turns,
      firstAudioN: M.firstAudio.length,
      firstAudioP50: pct(M.firstAudio, 0.5),
      firstAudioP95: pct(M.firstAudio, 0.95),
      bargeN: M.barge.length,
      bargeP95: pct(M.barge, 0.95),
      samples: { firstAudio: M.firstAudio.slice(-30), barge: M.barge.slice(-30) }
    };
  }

  function reset() {
    M = { turns: 0, firstAudio: [], barge: [], userEndAt: 0, speakStartAt: 0, bargeStartAt: 0 };
  }

  window.VoiceLoop = {
    supported: supported,
    enabled: enabled,
    setEnabled: setEnabled,
    arm: arm,
    disarm: disarm,
    noteUserSpeechEnd: noteUserSpeechEnd,
    noteSpeakStart: noteSpeakStart,
    noteBargeDone: noteBargeDone,
    stats: stats,
    reset: reset,
    active: function () { return ST.active; }
  };
})();