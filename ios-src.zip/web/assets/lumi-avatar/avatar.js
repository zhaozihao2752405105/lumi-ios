(function () {
  'use strict';

  var stage = document.getElementById('lumiAvatar');
  if (!stage) return;
  var media = 'assets/lumi-avatar/media/';
  var clips = {
    idle: '01_idle', shy: '02_shy', playful: '03_playful', happy: '04_happy',
    wink: '05_wink', pout: '06_pout', surprised: '07_surprised',
    thinking: '08_thinking', listening: '09_listening', speaking: '10_speaking',
    tsundere: '11_tsundere', angry: '12_angry'
  };
  var slots = Array.from(stage.querySelectorAll('video'));
  var canvas = stage.querySelector('canvas');
  var renderer;
  var renderedVideo;
  var renderFrame;
  function setupRenderer() {
    try { renderer = window.LumiAvatarMatte.create(canvas); } catch (error) { renderer = null; }
  }
  setupRenderer();
  var active = null;
  var pending = null;
  var wanted = 'idle';
  var cooldown = Object.create(null);
  var lastReaction = 0;
  var warmTimer;
  var listeningTimer;
  var parked = false;
  var motion = window.matchMedia('(prefers-reduced-motion: reduce)');

  function load(video, name) {
    if (video.dataset.clip === name && !video.error) return;
    video.preload = 'auto';
    video.muted = true;
    video.dataset.clip = name;
    video.src = media + clips[name] + '.matte.mp4?v=20261129perf14';
    video.load();
  }

  function cancelPending() {
    if (!pending) return;
    pending.cleanup();
    pending.video.pause();
    pending = null;
  }

  function stopDrawing() {
    if (!renderedVideo) return;
    if (renderedVideo.cancelVideoFrameCallback) renderedVideo.cancelVideoFrameCallback(renderFrame);
    else cancelAnimationFrame(renderFrame);
    renderedVideo = null;
  }

  function drawContinuously(video) {
    stopDrawing();
    renderedVideo = video;
    var lastTime = -1;
    function update() {
      if (renderedVideo !== video || document.hidden || motion.matches || !renderer) return;
      if (video.currentTime !== lastTime && video.readyState >= 2) {
        if (!renderer.draw(video)) { poster(); return; }
        lastTime = video.currentTime;
      }
      renderFrame = video.requestVideoFrameCallback ? video.requestVideoFrameCallback(update) : requestAnimationFrame(update);
    }
    renderFrame = video.requestVideoFrameCallback ? video.requestVideoFrameCallback(update) : requestAnimationFrame(update);
  }

  function poster() {
    stopDrawing();
    stage.dataset.action = 'idle';
    delete stage.dataset.videoReady;
    if (active) {
      active.pause();
      active.classList.remove('is-visible');
      active = null;
    }
  }

  function play(name) {
    if (!clips[name]) return;
    wanted = name;
    clearTimeout(warmTimer);
    if (!renderer || parked || document.hidden || motion.matches) return;
    if (pending && pending.name === name) return;
    cancelPending();
    if (active && active.dataset.clip === name && !active.ended && !active.error) {
      var current = active;
      current.play().catch(function () { if (active === current && !pending) poster(); });
      drawContinuously(current);
      return;
    }

    var next = slots[active === slots[0] ? 1 : 0];
    var deadline;
    var frame;
    var painting;
    var frameFallback;
    function cleanup() {
      clearTimeout(deadline);
      clearTimeout(frameFallback);
      cancelAnimationFrame(painting);
      if (frame != null) next.cancelVideoFrameCallback(frame);
      next.removeEventListener('playing', ready);
      next.removeEventListener('error', failed);
    }
    function failed() {
      if (!pending || pending.cleanup !== cleanup) return;
      cancelPending();
      if (wanted === 'idle') poster();
      else play('idle');
    }
    function show() {
      if (!pending || pending.cleanup !== cleanup || next.readyState < 2) return;
      if (!renderer.draw(next)) { failed(); return; }
      cleanup();
      pending = null;
      if (active) {
        active.pause();
        active.classList.remove('is-visible');
      }
      next.classList.add('is-visible');
      active = next;
      stage.dataset.action = name;
      stage.dataset.videoReady = 'true';
      drawContinuously(next);
      warmTimer = setTimeout(function () {
        if (document.hidden || motion.matches || pending || active !== next ||
            (navigator.connection && navigator.connection.saveData)) return;
        var neighbor = slots[next === slots[0] ? 1 : 0];
        if (name === 'listening' || name === 'thinking' || (name === 'idle' && (waiting || voice === 'speaking'))) {
          load(neighbor, 'speaking');
        } else if (name === 'idle') {
          load(neighbor, 'listening');
        } else {
          load(neighbor, 'idle');
        }
      }, name === 'thinking' ? 100 : 400);
    }
    function ready() {
      if (next.requestVideoFrameCallback && next.cancelVideoFrameCallback) {
        frame = next.requestVideoFrameCallback(show);
        // Some iOS WebViews throttle callbacks for covered video layers.
        frameFallback = setTimeout(function () {
          if (!next.paused && next.currentTime > 0) show();
        }, 180);
        return;
      }
      painting = requestAnimationFrame(function () {
        painting = requestAnimationFrame(show);
      });
    }

    pending = { name: name, video: next, cleanup: cleanup };
    load(next, name);
    next.loop = name === 'idle';
    next.playbackRate = name === 'speaking' ? 0.97 + Math.random() * 0.06 : 1;
    if (next.currentTime > 0) next.currentTime = 0;
    next.addEventListener('playing', ready, { once: true });
    next.addEventListener('error', failed, { once: true });
    deadline = setTimeout(failed, 3200);
    // Keep the visible frame until the next slot has a decoded frame.
    if (active && active.dataset.clip === 'speaking' && name !== 'speaking') active.pause();
    next.play().catch(failed);
  }

  slots.forEach(function (video) {
    video.addEventListener('ended', function () {
      if (active !== video || pending) return;
      var name = video.dataset.clip;
      if (name === 'speaking' && voice === 'speaking') betweenGestures = true;
      play('idle');
      if (name === 'listening' && voice === 'listening') scheduleListening();
    });
    video.addEventListener('error', function () {
      if (active === video && !pending) {
        poster();
        if (wanted !== 'idle') play('idle');
      }
    });
  });
  window.addEventListener('online', function () { play(wanted); });
  function syncVisibility() {
    cancelPending();
    clearTimeout(warmTimer);
    if (document.hidden) {
      clearTimeout(listeningTimer);
      stopDrawing();
      if (active) active.pause();
    } else if (motion.matches) {
      poster();
    } else {
      play(wanted);
      if (voice === 'listening' && wanted === 'idle') scheduleListening();
    }
  }
  document.addEventListener('visibilitychange', syncVisibility);
  window.addEventListener('pagehide', function () {
    parked = true;
    cancelPending();
    clearTimeout(warmTimer);
    clearTimeout(listeningTimer);
    poster();
    slots.forEach(function (video) {
      video.removeAttribute('src');
      delete video.dataset.clip;
      video.load();
    });
  });
  window.addEventListener('pageshow', function (event) {
    if (!event.persisted) return;
    parked = false;
    play(wanted);
  });
  if (motion.addEventListener) motion.addEventListener('change', syncVisibility);
  canvas.addEventListener('webglcontextlost', function (event) {
    event.preventDefault();
    renderer = null;
    cancelPending();
    poster();
  });
  canvas.addEventListener('webglcontextrestored', function () {
    setupRenderer();
    play(wanted);
  });
  var still = stage.querySelector('img');
  function posterMissing() { stage.dataset.posterMissing = 'true'; }
  still.addEventListener('error', posterMissing);
  if (still.complete && !still.naturalWidth) posterMissing();

  function reaction(name) {
    var now = Date.now();
    if (wanted !== 'idle' || voice !== 'idle' || waiting || !name || !clips[name] || document.hidden ||
        (lastReaction && now - lastReaction < 6500) ||
        (cooldown[name] && now - cooldown[name] < 24000)) return;
    cooldown[name] = lastReaction = now;
    play(name);
  }

  var voice;
  var audioContext;
  var analyser;
  var input;
  var waveform;
  var sampleTimer;
  var thinkTimer;
  var silenceTimer;
  var waitingTimer;
  var responseId;
  var inputTurn;
  var candidate;
  var lastHeard;
  var loudSamples;
  var interrupted;
  var waiting;
  var reactionAfterVoice;
  var betweenGestures = false;

  function scheduleListening() {
    clearTimeout(listeningTimer);
    listeningTimer = setTimeout(function () {
      if (voice === 'listening' && !document.hidden) play('listening');
    }, 10000 + Math.random() * 7000);
  }

  function phase(next) {
    voice = next;
    betweenGestures = false;
    clearTimeout(thinkTimer);
    clearTimeout(silenceTimer);
    clearTimeout(listeningTimer);
    play(next);
  }

  function finishSpeech() {
    if (voice !== 'speaking' && voice !== 'thinking' && !waiting) return;
    clearTimeout(waitingTimer);
    var queued = reactionAfterVoice;
    responseId = null;
    waiting = false;
    reactionAfterVoice = null;
    phase('idle');
    reaction(queued);
  }

  function heardAudio() {
    if (interrupted || voice === 'listening') return;
    waiting = false;
    clearTimeout(waitingTimer);
    var now = performance.now();
    var pause = now - lastHeard;
    lastHeard = now;
    if (voice !== 'speaking') phase('speaking');
    else if (betweenGestures && pause >= 185 && pause < 480) {
      betweenGestures = false;
      play('speaking');
    }
    clearTimeout(silenceTimer);
    silenceTimer = setTimeout(finishSpeech, 1300);
  }

  function sample() {
    if (!input || !audioContext || audioContext.state !== 'running' || document.hidden) return;
    analyser.getByteTimeDomainData(waveform);
    var power = 0;
    for (var i = 0; i < waveform.length; i++) {
      var level = (waveform[i] - 128) / 128;
      power += level * level;
    }
    if (power / waveform.length > 0.000045) loudSamples++;
    else loudSamples = 0;
    if (loudSamples >= 2) heardAudio();
    if (voice === 'speaking' && performance.now() - lastHeard > 480) finishSpeech();
  }

  function arm() {
    var Audio = window.AudioContext || window.webkitAudioContext;
    if (!Audio) return;
    try {
      if (!audioContext) audioContext = new Audio();
      audioContext.resume().catch(function () {});
    } catch (error) {}
  }

  function attach(stream) {
    if (!audioContext) return;
    try {
      if (input) input.disconnect();
      clearInterval(sampleTimer);
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 1024;
      waveform = new Uint8Array(analyser.fftSize);
      input = audioContext.createMediaStreamSource(stream);
      input.connect(analyser);
      sampleTimer = setInterval(sample, 45);
    } catch (error) {
      input = null;
    }
  }

  function classify(text) {
    if (/假装生气|开玩笑.{0,6}生气|pretend to be mad/i.test(text)) return 'angry';
    if (/吓我一跳|没想到|太意外|what a surprise|no way!/i.test(text)) return 'surprised';
    if (/你真棒|你真可爱|你太可爱|你教得真好|you(?:'re| are) (?:so cute|amazing|a great teacher)/i.test(text)) return 'shy';
    if (/眨个眼|wink (?:at me|please)/i.test(text)) return 'wink';
    if (/撒个娇|撒娇|show me a pout/i.test(text)) return 'pout';
    if (/傲娇一下|你真傲娇|tsundere/i.test(text)) return 'tsundere';
    if (/讲个笑话|逗我笑|聊点轻松的|tell me a joke|just kidding/i.test(text)) return 'playful';
    return null;
  }

  function event(message) {
    var type = message.type;
    if (type === 'input_audio_buffer.speech_started') {
      interrupted = true;
      waiting = false;
      loudSamples = 0;
      clearTimeout(waitingTimer);
      inputTurn = message.item_id || null;
      responseId = null;
      candidate = reactionAfterVoice = null;
      phase('listening');
    } else if (type === 'input_audio_buffer.speech_stopped') {
      waiting = true;
      candidate = message.item_id || inputTurn || true;
      phase('idle');
      thinkTimer = setTimeout(function () {
        if (waiting) phase('thinking');
      }, 650);
      clearTimeout(waitingTimer);
      waitingTimer = setTimeout(finishSpeech, 12000);
    } else if (type === 'conversation.item.input_audio_transcription.completed') {
      if (candidate && (candidate === true || !message.item_id || candidate === message.item_id)) {
        reactionAfterVoice = classify(String(message.transcript || '')) || reactionAfterVoice;
        candidate = null;
      }
    } else if (type === 'response.created') {
      if (voice === 'listening') return;
      responseId = message.response && message.response.id;
      interrupted = false;
    } else if (type === 'output_audio_buffer.started') {
      if (!interrupted && voice !== 'listening') heardAudio();
    } else if (type === 'response.audio.delta' || type === 'response.output_audio.delta') {
      if ((!input || audioContext.state !== 'running') &&
          (!message.response_id || !responseId || message.response_id === responseId)) heardAudio();
    } else if (type === 'output_audio_buffer.stopped' || type === 'output_audio_buffer.cleared') {
      if (!interrupted && (!message.response_id || !responseId || message.response_id === responseId)) finishSpeech();
    } else if (type === 'response.done') {
      var result = message.response || {};
      if (responseId && result.id && responseId !== result.id) return;
      if (result.status === 'cancelled' || result.status === 'failed') finishSpeech();
      else if ((!input || audioContext.state !== 'running') && voice === 'speaking') {
        clearTimeout(silenceTimer);
        silenceTimer = setTimeout(finishSpeech, 450);
      }
    }
  }

  function reset() {
    clearInterval(sampleTimer);
    clearTimeout(waitingTimer);
    if (input) input.disconnect();
    if (audioContext) audioContext.close().catch(function () {});
    audioContext = input = null;
    candidate = responseId = inputTurn = reactionAfterVoice = null;
    waiting = false;
    interrupted = false;
    loudSamples = 0;
    phase('idle');
  }

  function consumeAnswer() {
    try {
      var at = Number(sessionStorage.getItem('lumi-avatar-correct') || 0);
      sessionStorage.removeItem('lumi-avatar-correct');
      if (at > 0 && Date.now() - at < 15000) reaction('happy');
    } catch (error) {}
  }
  window.addEventListener('pageshow', consumeAnswer);

  loudSamples = 0;
  interrupted = false;
  phase('idle');
  window.LumiAvatar = { arm: arm, attach: attach, event: event, reset: reset };
}());
