/* ============================================================
 * practice.js — 自由练习（跟写 / 听写 / 默写）
 * 与正式学习隔离：这里不写 study_event、不改 SM-2 复习安排。
 * 只有「写错了」会进错词本（record_word_miss），和复习算法无关。
 * ============================================================ */
(function () {
  'use strict';

  var S = {
    source: 'mistakes',   // mistakes | favs | book | personal
    mode: 'follow',       // follow | dictate | recall
    items: [],
    idx: 0,
    typed: '',
    hint: false,
    ok: 0,
    answered: 0,
    feedback: null,       // {ok, answer}
    busy: false,
    books: [],
    bookId: '',
    personalBooks: [],
    personalId: '',
    finished: false
  };

  var SOURCES = [
    { key: 'mistakes', name: '错词本' },
    { key: 'favs', name: '收藏' },
    { key: 'book', name: '当前词书' },
    { key: 'personal', name: '我的词书' }
  ];
  var MODES = [
    { key: 'follow', name: '跟写', tip: '看着单词敲一遍，敲错的字母会标红。' },
    { key: 'dictate', name: '听写', tip: '只给发音，把听到的词写出来。' },
    { key: 'recall', name: '默写', tip: '只给中文意思，凭记忆写英文。' }
  ];

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function toast(msg, ms) {
    var t = el('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, ms || 2200);
  }
  function rpc(name, args) {
    if (!window.DB || typeof window.DB.rpc !== 'function') return Promise.reject(new Error('数据库未就绪'));
    return window.DB.rpc(name, args || {});
  }
  function cur() { return S.items[S.idx] || null; }
  function modeInfo() {
    for (var i = 0; i < MODES.length; i++) if (MODES[i].key === S.mode) return MODES[i];
    return MODES[0];
  }

  function say(word, btn) {
    if (!window.Speech || typeof window.Speech.say !== 'function') { toast('这个浏览器不支持朗读'); return; }
    try { window.Speech.say(word, { lang: 'en-US', force: true }); } catch (e) { /* 忽略 */ }
    if (btn) { btn.classList.add('on'); setTimeout(function () { btn.classList.remove('on'); }, 600); }
  }

  /* ---------- 渲染 ---------- */
  function chipsHtml(list, curKey, act) {
    return '<div class="v2-seg">' + list.map(function (o) {
      return '<button class="v2-seg-btn" data-act="' + act + '" data-key="' + o.key + '" aria-pressed="' + (curKey === o.key ? 'true' : 'false') + '">' + esc(o.name) + '</button>';
    }).join('') + '</div>';
  }

  function followHtml(word) {
    var w = String(word || ''), t = String(S.typed || '');
    var h = '<div class="fw-word" id="fwWord" aria-live="polite">';
    for (var i = 0; i < w.length; i++) {
      var ch = w.charAt(i);
      var cls = 'fw-ch';
      if (i < t.length) cls += (t.charAt(i).toLowerCase() === ch.toLowerCase() ? ' ok' : ' bad');
      else if (i === t.length) cls += ' cur';
      h += '<span class="' + cls + '">' + esc(ch) + '</span>';
    }
    return h + '</div>';
  }

  function personalPickHtml() {
    if (!S.personalBooks.length) {
      return '<p class="small muted mt8">还没有个人词书。' +
        '<a href="my-words.html">上传自己的资料生成一本 →</a></p>';
    }
    return '<div class="v2-seg mt8">' + S.personalBooks.map(function (b) {
      return '<button class="v2-seg-btn" data-act="pbook" data-key="' + esc(b.id) +
        '" aria-pressed="' + (S.personalId === b.id ? 'true' : 'false') + '">' + esc(b.title) + '</button>';
    }).join('') + '</div>';
  }

  function headHtml() {
    var n = S.items.length;
    var pos = Math.min(S.idx + 1, n);
    return '<div class="card tight">' +
      '<p class="small muted">从哪儿练</p>' + chipsHtml(SOURCES, S.source, 'src') +
      (S.source === 'personal' ? personalPickHtml() : '') +
      '<p class="small muted mt12">怎么练</p>' + chipsHtml(MODES, S.mode, 'mode') +
      '<p class="small muted mt8">' + esc(modeInfo().tip) + ' 自由练习不会改动复习安排。</p>' +
      (n ? '<p class="small muted mt8">进度 ' + pos + ' / ' + n + ' · 独立写对 ' + S.ok + '</p>' : '') +
      '</div>';
  }

  function bodyHtml() {
    if (S.busy) return '<div class="card"><p class="muted">正在准备…</p></div>';
    if (!S.items.length) {
      return '<div class="card"><p class="muted">这里还没有可以练的词。</p>' +
        '<p class="muted small">换个来源，或者先去背几个词、写错几个词。</p>' +
        '<div class="row mt8"><a class="btn ghost block" href="study.html">去背单词</a></div></div>';
    }
    if (S.finished) {
      return '<div class="card"><h3>这一轮练完了</h3>' +
        '<p class="muted">共 ' + S.answered + ' 个词，第一遍就写对 ' + S.ok + ' 个。</p>' +
        '<p class="muted small">自由练习的记录不参与复习安排，写错的词已经进了错词本。</p>' +
        '<div class="row mt12"><button class="btn block" data-act="again">再来一轮</button></div>' +
        '<div class="row mt8"><a class="btn ghost block" href="word-mistakes.html">回到错词本</a></div></div>';
    }
    var it = cur();
    if (!it) return '';
    var h = '<div class="card tight">';
    var fb = S.feedback;
    if (S.mode === 'follow') {
      h += '<p class="small muted">照着敲一遍</p>' + followHtml(it.word);
      h += '<div class="word-cn">' + esc(it.meaning || '') + '</div>';
    } else if (S.mode === 'dictate') {
      h += '<p class="small muted">听发音，写出你听到的单词</p>';
      h += '<div class="row mt8"><button class="btn ghost sm" data-act="say">听发音</button></div>';
      if (fb) h += '<div class="word-en">' + esc(it.word) + '</div><div class="word-ipa">' + esc(it.ipa || '') + '</div>';
      else if (S.hint) h += '<p class="muted small mt8">首字母 ' + esc(String(it.word).charAt(0)) + '，共 ' + String(it.word).length + ' 个字母</p>';
    } else {
      h += '<p class="small muted">看中文，写出英文</p>';
      h += '<div class="word-cn">' + esc(it.meaning || '') + '</div>';
      if (fb) h += '<div class="word-en">' + esc(it.word) + '</div><div class="word-ipa">' + esc(it.ipa || '') + '</div>';
      else if (S.hint) h += '<p class="muted small mt8">首字母 ' + esc(String(it.word).charAt(0)) + '，共 ' + String(it.word).length + ' 个字母</p>';
    }

    if (!fb) {
      h += '<input id="pvInput" class="wm-search mt12" type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="写出这个单词" value="' + esc(S.typed) + '">';
      if (S.mode !== 'follow' && !S.hint) h += '<div class="mt8"><button class="btn ghost sm" data-act="hint">给一点提示</button></div>';
      h += '<div class="row mt8"><button class="btn block" data-act="submit">提交</button></div>';
    } else {
      h += '<div class="note mt12">' + (fb.ok ? '写对了。' : '写错了，正确拼写见上面。这个词已记进错词本。') + '</div>';
      h += '<div class="row mt8"><button class="btn block" data-act="next">下一个</button></div>';
    }
    h += '</div>';
    return h;
  }

  function render() {
    el('view').innerHTML = headHtml() + bodyHtml();
    var inp = el('pvInput');
    if (inp) {
      inp.focus();
      try { inp.setSelectionRange(inp.value.length, inp.value.length); } catch (e) { }
    }
  }

  /* ---------- 数据 ---------- */
  async function loadBooks() {
    try {
      var res = await rpc('list_wordbooks', {});
      var list = (res && (res.wordbooks || res.books)) || [];
      S.books = list;
      var curBook = null;
      for (var i = 0; i < list.length; i++) if (list[i].is_current) { curBook = list[i]; break; }
      S.bookId = (curBook || list[0] || {}).id || '';
    } catch (e) { S.books = []; }
  }

  async function loadPersonalBooks() {
    try {
      var r = await rpc('list_personal_wordbooks', {});
      S.personalBooks = (r && r.books) || [];
      var has = false;
      for (var i = 0; i < S.personalBooks.length; i++) if (S.personalBooks[i].id === S.personalId) has = true;
      if (!has) S.personalId = (S.personalBooks[0] || {}).id || '';
    } catch (e) { S.personalBooks = []; }
  }

  async function loadItems() {
    S.busy = true; S.finished = false; S.idx = 0; S.ok = 0; S.answered = 0; S.feedback = null; S.typed = ''; S.hint = false;
    render();
    try {
      var words = [];
      if (S.source === 'mistakes') {
        var r = await rpc('list_word_mistakes', { p_limit: 40, p_include_mastered: false });
        words = (r && r.items) || [];
      } else if (S.source === 'favs') {
        var f = await rpc('list_word_favorites', { p_limit: 40 });
        words = (f && f.items) || [];
      } else if (S.source === 'personal') {
        if (!S.personalBooks.length) await loadPersonalBooks();
        if (S.personalId) {
          var pb = await rpc('personal_book_words_sample', { p_book_id: S.personalId, p_limit: 20 });
          words = (pb && pb.words) || [];
        }
      } else {
        if (!S.bookId) await loadBooks();
        if (S.bookId) {
          var b = await rpc('wordbook_words_sample', { p_book_id: S.bookId, p_limit: 20 });
          words = (b && b.words) || [];
        }
      }
      S.items = words.map(function (w) {
        return { word_id: w.word_id, word: w.word, ipa: w.ipa, meaning: w.meaning };
      });
    } catch (e) {
      S.items = [];
      toast('读取失败：' + ((e && e.message) || e));
    }
    S.busy = false;
    render();
  }

  function noteMiss(wordId, typed) {
    if (!wordId || !window.DB || typeof window.DB.rpc !== 'function') return;
    try {
      window.DB.rpc('record_word_miss', { p_word_id: wordId, p_typed: String(typed || '').slice(0, 60), p_mode: 'practice' })
        .catch(function () { });
    } catch (e) { /* 忽略 */ }
  }

  function submit() {
    var it = cur();
    if (!it || S.feedback) return;
    var typed = String(S.typed || '').trim();
    if (!typed) { toast('先写点什么'); return; }
    var ok = typed.toLowerCase() === String(it.word).toLowerCase();
    S.answered += 1;
    if (ok) S.ok += 1; else noteMiss(it.word_id, typed);
    S.feedback = { ok: ok, answer: it.word };
    render();
  }

  function next() {
    S.feedback = null; S.typed = ''; S.hint = false;
    S.idx += 1;
    if (S.idx >= S.items.length) { S.finished = true; }
    render();
  }

  /* ---------- 事件 ---------- */
  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    if (act === 'src') {
      var k = t.getAttribute('data-key');
      if (k === S.source) return;
      S.source = k;
      return loadItems();
    }
    if (act === 'pbook') {
      var pid = t.getAttribute('data-key');
      if (pid === S.personalId) return;
      S.personalId = pid;
      return loadItems();
    }
    if (act === 'mode') {
      var m = t.getAttribute('data-key');
      if (m === S.mode) return;
      S.mode = m; S.feedback = null; S.typed = ''; S.hint = false;
      return render();
    }
    if (act === 'say') return say((cur() || {}).word || '', t);
    if (act === 'hint') { S.hint = true; return render(); }
    if (act === 'submit') return submit();
    if (act === 'next') return next();
    if (act === 'again') return loadItems();
  });

  document.addEventListener('input', function (ev) {
    if (!ev.target || ev.target.id !== 'pvInput') return;
    S.typed = ev.target.value || '';
    if (S.mode !== 'follow') return;
    var box = el('fwWord');
    var it = cur();
    if (!box || !it) return;
    box.innerHTML = followHtml(it.word).replace(/^<div class="fw-word" id="fwWord"[^>]*>/, '').replace(/<\/div>$/, '');
  });

  document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter') return;
    if (S.feedback) { ev.preventDefault(); next(); return; }
    if (document.activeElement && document.activeElement.id === 'pvInput') { ev.preventDefault(); submit(); }
  });

  /* ---------- 启动 ---------- */
  (async function boot() {
    el('view').innerHTML = '<div class="card"><p class="muted">正在准备…</p></div>';
    var user = null;
    try { user = await window.AppAuth.requireLogin(); } catch (e) { user = null; }
    if (!user) return;
    var name = '';
    try { name = window.AppAuth.displayName(user) || ''; } catch (e) { name = ''; }
    var u = el('userName');
    if (u) u.textContent = (name ? name + ' · ' : '') + '已登录';
    try {
      var qs = new URLSearchParams(location.search);
      var qsrc = qs.get('src');
      if (qsrc === 'personal' || qsrc === 'favs') S.source = qsrc;
      var qbook = qs.get('book');
      if (qbook) S.personalId = qbook;
    } catch (e) { /* 忽略 */ }
    await loadBooks();
    if (S.source === 'personal') await loadPersonalBooks();
    await loadItems();
  })();
})();
